(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desecrate')">desecrate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desolate')">desolate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* Ezra 09:1-2
* Genesis 46:33-34
* Isaiah 01:12-13
* Matthew 24:15-18
* Proverbs 26:24-26
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/heir')">heir</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/inherit')">inherit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* Ephesians 01:5-6
* Galatians 04:3-5
* Romans 08:14-15
* Romans 08:23-25
* Romans 09:3-5
* Some languages may have an indirect way of talking about adultery, such as "sleeping with someone else's spouse" or "being unfaithful to one's wife." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">euphemism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/commit')">commit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fornication')">sexual immorality</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sex')">sleep with</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>)
* Exodus 20:12-14
* Hosea 04:1-2
* Luke 16:18
* Matthew 05:27-28
* Matthew 12:38-40
* Revelation 02:22-23
* __Open Bible Stories - 13:06__ "Do not commit __adultery__."
* __Open Bible Stories - 28:02__ Do not commit __adultery__.
* __Open Bible Stories - 34:07__ "The religious leader prayed like this, 'Thank you, God, that I am not a sinner like other men-such as robbers, unjust men, __adulterers__, or even like that tax collector.'"
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>)
* Exodus 06:2-5
* Genesis 17:1-2
* Genesis 35:11-13
* Job 08:1-3
* Numbers 24:15-16
* Revelation 01:7-8
* Ruth 01:19-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/altarofincense')">altar of incense</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grainoffering')">grain offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* Genesis 08:20-22
* Genesis 22:9-10
* James 02:21-24
* Luke 11:49-51
* Matthew 05:23-24
* Matthew 23:18-19
* __Open Bible Stories - 03:14__ After Noah got off the boat, he built an __altar__  and sacrificed some of each kind of animal which could be used for a sacrifice.
* __Open Bible Stories - 05:08__ When they reached the place of sacrifice, Abraham tied up his son Isaac and laid him on an __altar__.
* __Open Bible Stories - 13:09__ A priest would kill the animal and burn it on the __altar__.
* __Open Bible Stories - 16:06__ He (Gideon) built a new altar dedicated to God near where the __altar__  to the idol used to be and made a sacrifice to God on it.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fulfill')">fulfill</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* Deuteronomy 27:15
* John 05:19-20
* Jude 01:24-25
* Matthew 26:33-35
* Philemon 01:23-25
* Revelation 22:20-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/chief')">chief</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/head')">head</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/messenger')">messenger</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/michael')">Michael</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>)
* 2 Samuel 24:15-16
* Acts 10:3-6
* Acts 12:22-23
* Colossians 02:18-19
* Genesis 48:14-16
* Luke 02:13-14
* Mark 08:38
* Matthew 13:49-50
* Revelation 01:19-20
* Zechariah 01:7-9
* __Open Bible Stories - 02:12__ God placed large, powerful __angels__  at the entrance to the garden to keep anyone from eating the fruit of the tree of life.
* __Open Bible Stories - 22:03__ The __angel__  responded to Zechariah,"I was sent by God to bring you this good news."
* __Open Bible Stories - 23:06__ Suddenly, a shining __angel__  appeared to them (the shepherds), and they were terrified. The __angel__  said, "Do not be afraid, because I have some good news for you."
* __Open Bible Stories - 23:07__ Suddenly, the skies were filled with __angels__  praising Godâ€¦
* __Open Bible Stories - 25:08__ Then __angels__  came and took care of Jesus.
* __Open Bible Stories - 38:12__ Jesus was very troubled and his sweat was like drops of blood. God sent an __angel__  to strengthen him.
* __Open Bible Stories - 38:15__ "I could ask the Father for an army of __angels__  to defend me."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/consecrate')">consecrate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingofthejews')">King of the Jews</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>  )
* 1 John 02:20-21
* 1 John 02:27-29
* 1 Samuel 16:2-3
* Acts 04:27-28
* Amos 06:5-6
* Exodus 29:5-7
* James 05:13-15
* Also consider how this term is translated in a Bible translation in a local or national language. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/reveal')">reveal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tribulation')">tribulation</a>)
* 1 John 02:18-19
* 1 John 04:1-3
* 2 John 01:7-8
* Also consider how this term was translated in a Bible translation in a local or national language. (See <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamessonofzebedee')">James (son of Zebedee)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* Jude 01:17-19
* Luke 09:12-14
* __Open Bible Stories - 26:10__ Then Jesus chose twelve men who were called his __apostles__. The __apostles__  traveled with Jesus and learned from him.
* __Open Bible Stories - 30:01__ Jesus sent his __apostles__  to preach and to teach people in many different villages.
* __Open Bible Stories - 38:02__ Judas was one of Jesus' __apostles__. He was in charge of the __apostles'__  money bag, but he loved money and often stole from the bag.
* __Open Bible Stories - 43:13__ The disciples devoted themselves to the __apostles'__  teaching, fellowship, eating together, and prayer.
* __Open Bible Stories - 46:08__ Then a believer named Barnabas took Saul to the __apostles__  and told them how Saul had preached boldly in Damascus.
* 1 Samuel 08:10-12
* Acts 03:19-20
* Acts 06:2-4
* Acts 13:48-49
* Genesis 41:33-34
* Numbers 03:9-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/basket')">basket</a>)
* 1 Peter 03:18-20
* Exodus 16:33-36
* Exodus 30:5-6
* Genesis 08:4-5
* Luke 17:25-27
* Matthew 24:37-39
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/atonement')">atonement</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyplace')">holy place</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/testimony')">testimony</a>)
* 1 Samuel 06:14-15
* Exodus 25:10-11
* Hebrews 09:3-5
* Judges 20:27-28
* Numbers 07:89
* Revelation 11:19
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/atonementlid')">atonement lid</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/propitiation')">propitiation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/reconcile')">reconcile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/redeem')">redeem</a>)
* Ezekiel 43:25-27
* Ezekiel 45:18-20
* Leviticus 04:20-21
* Numbers 05:8-10
* Numbers 28:19-22
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/atonement')">atonement</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cherubim')">cherubim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/propitiation')">propitiation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/redeem')">redeem</a>)
* Exodus 25:15-18
* Exodus 30:5-6
* Exodus 40:17-20
* Leviticus 16:1-2
* Numbers 07:89
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/citizen')">citizen</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>)
* Colossians 02:10-12
* Esther 09:29
* Genesis 41:35-36
* Jonah 03:6-7
* Luke 12:4-5
* Luke 20:1-2
* Mark 01:21-22
* Matthew 08:8-10
* Matthew 28:18-19
* Titus 03:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>)
* Acts 02:37-39
* Acts 08:36-38
* Acts 09:17-19
* Acts 10:46-48
* Luke 03:15-16
* Matthew 03:13-15
* Matthew 28:18-19
* __Open Bible Stories - 24:03__ When people heard John's message, many of them repented from their sins, and John __baptized__  them. Many religious leaders also came to be __baptized__  by John, but they did not repent or confess their sins.
* __Open Bible Stories - 24:06__ The next day, Jesus came to be __baptized__  by John.
* __Open Bible Stories - 24:07__ John said to Jesus, "I am not worthy to __baptize__  you. You should __baptize__  me instead."
* __Open Bible Stories - 42:10__ So go, make disciples of all people groups by __baptizing__  them in the name of the Father, the Son, and the Holy Spirit and by teaching them to obey everything I have commanded you."
* __Open Bible Stories - 43:11__ Peter answered them, "Every one of you should repent and be __baptized__  in the name of Jesus Christ so that God will forgive your sins."
* __Open Bible Stories - 43:12__ About 3,000 people believed what Peter said and became disciples of Jesus. They were __baptized__  and became part of the church at Jerusalem.
* __Open Bible Stories - 45:11__ As Philip and the Ethiopian traveled, they came to some water. The Ethiopian said, "Look! There is some water! May I be __baptized__?"
* __Open Bible Stories - 46:05__ Saul immediately was able to see again, and Ananias __baptized__  him.
* __Open Bible Stories - 49:14__ Jesus invites you to believe in him and be __baptized__.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christian')">Christian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/trust')">trust</a>)
* Genesis 15:6-8
* Genesis 45:24-26
* Job 09:16-18
* Habakkuk 01:5-7
* Mark 06:4-6
* Mark 01:14-15
* Luke 09:41-42
* John 01:12-13
* Acts 06:5-6
* Acts 09:40-43
* Acts 28:23-24
* Romans 03:3-4
* 1 Corinthians 06:1-3
* 1 Corinthians 09:3-6
* 2 Corinthians 06:14-16
* Hebrews 03:12-13
* 1 John 03:23-24
* __Open Bible Stories - 03:04__ Noah warned the people about the coming flood and told them to turn to God, but they did not __believe__  him.
* __Open Bible Stories - 04:08__ Abram __believed__  God's promise. God declared that Abram was righteous because he __believed__  God's promise.
* __Open Bible Stories - 11:02__ God provided a way to save the firstborn of anyone who __believed in__  him.
* __Open Bible Stories - 11:06__ But the Egyptians did not __believe__  God or obey his commands.
* __Open Bible Stories - 37:05__ Jesus replied, "I am the Resurrection and the Life. Whoever __believes in__  me will live, even though he dies. Everyone who __believes in__  me will never die. Do you __believe__  this?"
* __Open Bible Stories - 43:01__ After Jesus returned to heaven, the disciples stayed in Jerusalem as Jesus had commanded them to do. The __believers__  there constantly gathered together to pray.
* __Open Bible Stories - 43:03__ While the __believers__  were all together, suddenly the house where they were was filled with a sound like a strong wind. Then something that looked like flames of fire appeared over the heads of all the __believers__.
* __Open Bible Stories - 43:13__ Every day, more people became __believers__.
* __Open Bible Stories - 46:06__ That day many people in Jerusalem started persecuting the followers of Jesus, so the __believers__  fled to other places. But in spite of this, they preached about Jesus everywhere they went.
* __Open Bible Stories - 46:01__ Saul was the young man who guarded the robes of the men who killed Stephen. He did not believe in Jesus, so he persecuted the __believers__.
* __Open Bible Stories - 46:09__ Some __believers__  who fled from the persecution in Jerusalem went far away to the city of Antioch and preached about Jesusâ€¦It was at Antioch that __believers__  in Jesus were first called "Christians."
* __Open Bible Stories - 47:14__ They also wrote many letters to encourage and teach the __believers__  in the churches.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/love')">love</a>)
* 1 Corinthians 04:14-16
* 1 John 03:1-3
* 1 John 04:7-8
* Mark 01:9-11
* Mark 12:6-7
* Revelation 20:9-10
* Romans 16:6-8
* Song of Solomon 01:12-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/firstborn')">firstborn</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/inherit')">inherit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>)
* 1 Chronicles 05:1-3
* Genesis 25:31-34
* Genesis 43:32-34
* Hebrews 12:14-17
* 1 Thessalonians 02:10-12
* 1 Thessalonians 03:11-13
* 2 Peter 03:14-16
* Colossians 01:21-23
* Genesis 17:1-2
* Philippians 02:14-16
* Philippians 03:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/dishonor')">dishonor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/slander')">slander</a>)
* 1 Timothy 01:12-14
* Acts 06:10-11
* Acts 26:9-11
* James 02:5-7
* John 10:32-33
* Luke 12:8-10
* Mark 14:63-65
* Matthew 12:31-32
* Matthew 26:65-66
* Psalms 074:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/praise')">praise</a>)
* 1 Corinthians 10:14-17
* Acts 13:32-34
* Ephesians 01:3-4
* Genesis 14:19-20
* Isaiah 44:3-4
* James 01:22-25
* Luke 06:20-21
* Matthew 26:26
* Nehemiah 09:5-6
* Romans 04:9-10
* __Open Bible Stories - 01:07__ God saw that it was good and he __blessed__  them.
* __Open Bible Stories - 01:15__ God made Adam and Eve in his own image. He __blessed__  them and told them, "Have many children and grandchildren and fill the earth."
* __Open Bible Stories - 01:16__ So God rested from all he had been doing. He __blessed__  the seventh day and made it holy, because on this day he rested from his work.
* __Open Bible Stories - 04:04__ "I will make your name great. I will __bless__  those who __bless__  you and curse those who curse you. All families on earth will be __blessed__  because of you."
* __Open Bible Stories - 04:07__ Melchizedek __blessed__  Abram and said, "May God Most High who owns heaven and earth __bless__  Abram."
* __Open Bible Stories - 07:03__ Isaac wanted to give his __blessing__  to Esau.
* __Open Bible Stories - 08:05__ Even in prison, Joseph remained faithful to God, and God __blessed__  him.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/flesh')">flesh</a>)
* 1 John 01:5-7
* 1 Samuel 14:31-32
* Acts 02:20-21
* Acts 05:26-28
* Colossians 01:18-20
* Galatians 01:15-17
* Genesis 04:10-12
* Psalms 016:4
* Psalms 105:28-30
* __Open Bible Stories - 08:03__ Before Joseph's brothers returned home, they tore Joseph's robe and dipped it in goat's __blood__.
* __Open Bible Stories - 10:03__ God turned the Nile River into __blood__, but Pharaoh still would not let the Israelites go.
* __Open Bible Stories - 11:05__ All the houses of the Israelites had __blood__  around the doors, so God passed over those houses and everyone inside was safe. They were saved because of the lamb's __blood__.
* __Open Bible Stories - 13:09__ The __blood__  of the animal that was sacrificed covered the person's sin and made that person clean in God's sight.
* __Open Bible Stories - 38:05__ Then Jesus took a cup and said, "Drink this. It is my __blood__  of the New Covenant that is poured out for the forgiveness of sins.
* __Open Bible Stories - 48:10__ When anyone believes in Jesus, the __blood__  of Jesus takes away that person's sin, and God's punishment passes over him.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/proud')">proud</a>)
* 1 Kings 20:11-12
* 2 Timothy 03:1-4
* James 03:13-14
* James 04:15-17
* Psalms 044:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/head')">head</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 1 Chronicles 10:11-12
* 1 Corinthians 05:3-5
* Ephesians 04:4-6
* Judges 14:7-9
* Numbers 06:6-8
* Psalm 031:8-9
* Romans 12:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fulfill')">fulfill</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peace')">peace</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prison')">prison</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/vow')">vow</a>)
* Leviticus 08:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>)
* 1 John 03:9-10
* 1 Peter 01:3-5
* 1 Peter 01:22-23
* John 03:3-4
* John 03:7-8
* Titus 03:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godthefather')">God the Father</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sister')">sister</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* Acts 07:26-28
* Genesis 29:9-10
* Leviticus 19:17-18
* Nehemiah 03:1-2
* Philippians 04:21-23
* Revelation 01:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pray')">pray</a>)
* 1 Kings 18:22-24
* 1 Thessalonians 04:7-8
* 2 Timothy 01:8-11
* Ephesians 04:1-3
* Galatians 01:15-17
* Matthew 02:13-15
* Philippians 03:12-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Acts 10:1-2
* Acts 27:1-2
* Acts 27:42-44
* Luke 07:2-5
* Luke 23:46-47
* Mark 15:39-41
* Matthew 08:5-7
* Matthew 27:54-56
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promise')">promise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/son')">son</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/beloved')">beloved</a>)
* 1 John 02:27-29
* 3 John 01:1-4
* Galatians 04:19-20
* Genesis 45:9-11
* Joshua 08:34-35
* Nehemiah 05:4-5
* Many languages use a transliterated word that looks or sounds like "Christ" or "Messiah." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/anoint')">anoint</a>)
* 1 John 05:1-3
* Acts 02:34-36
* Acts 05:40-42
* John 01:40-42
* John 03:27-28
* John 04:25-26
* Luke 02:10-12
* Matthew 01:15-17
* __Open Bible Stories - 17:07__ The __Messiah__  was God's Chosen One who would save the people of the world from sin.
* __Open Bible Stories - 17:08__ As it happened, the Israelites would have to wait a long time before the __Messiah__  came, almost 1,000 years.
* __Open Bible Stories - 21:01__ From the very beginning, God planned to send the __Messiah__.
* __Open Bible Stories - 21:04__ God promised King David that the __Messiah__  would be one of David's own descendants.
* __Open Bible Stories - 21:05__ The __Messiah__  would start the New Covenant.
* __Open Bible Stories - 21:06__ God's prophets also said that the __Messiah__  would be a prophet, a priest, and a king.
* __Open Bible Stories - 21:09__ The prophet Isaiah prophesied that the __Messiah__  would be born from a virgin.
* __Open Bible Stories - 43:07__ "But God raised him to life again to fulfill the prophecy which says, 'You will not let your __Holy One__  rot in the grave.'"
* __Open Bible Stories - 43:09__ "But know for certain that God has caused Jesus to become both Lord and __Messiah__!"
* __Open Bible Stories - 43:11__ Peter answered them, "Every one of you should repent and be baptized in the name of Jesus __Christ__  so that God will forgive your sins."
* __Open Bible Stories - 46:06__ Saul reasoned with the Jews, proving that Jesus was the __Messiah__.
* Also consider how this term is translated in a Bible translation in a local or national language. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/antioch')">Antioch</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>)
* 1 Corinthians 06:7-8
* 1 Peter 04:15-16
* Acts 11:25-26
* Acts 26:27-29
* __Open Bible Stories - 46:09__ It was at Antioch that believers in Jesus were first called "__Christians__."
* __Open Bible Stories - 47:14__ ] Paul and other __Christian__  leaders traveled to many cities, preaching and teaching people the good news about Jesus.
* __Open Bible Stories - 49:15__ If you believe in Jesus and what he has done for you, you are a __Christian__!
* __Open Bible Stories - 49:16__ If you are a __Christian__, God has forgiven your sins because of what Jesus did.
* __Open Bible Stories - 49:17__ Even though you are a __Christian__, you will still be tempted to sin.
* __Open Bible Stories - 50:03__ Before he returned to heaven, Jesus told __Christians__  to proclaim the good news to people who have never heard it.
* __Open Bible Stories - 50:11__ When Jesus returns, every __Christian__  who has died will rise from the dead and meet him in the sky.
* Also consider how it is translated in a local or national Bible translation. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>.)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/assembly')">assembly</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christian')">Christian</a>)
* 1 Corinthians 05:11-13
* 1 Thessalonians 02:14-16
* 1 Timothy 03:4-5
* Acts 09:31-32
* Acts 14:23-26
* Acts 15:39-41
* Colossians 04:15-17
* Ephesians 05:22-24
* Matthew 16:17-18
* Philippians 04:14-17
* __Open Bible Stories - 43:12__ About 3,000 people believed what Peter said and became disciples of Jesus. They were baptized and became part of the __church__  at Jerusalem.
* __Open Bible Stories - 46:09__ Most of the people in Antioch were not Jews, but for the first time, very many of them also became believers. Barnabas and Saul went there to teach these new believers more about Jesus and to strengthen the __church__.
* __Open Bible Stories - 46:10__ So the __church__  in Antioch prayed for Barnabas and Saul and placed their hands on them. Then they sent them off to preach the good news of Jesus in many other places.
* __Open Bible Stories - 47:13__ The good news of Jesus kept spreading, and the __Church__  kept growing.
* __Open Bible Stories - 50:01__ For almost 2,000 years, more and more people around the world have been hearing the good news about Jesus the Messiah. The __Church__  has been growing.
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>)
* Genesis 17:9-11
* Genesis 17:12-14
* Exodus 12:47-48
* Leviticus 26:40-42
* Joshua 05:2-3
* Judges 15:17-18
* 2 Samuel 01:17-20
* Jeremiah 09:25-26
* Ezekiel 32:24-25
* Acts 10:44-45
* Acts 11:1-3
* Acts 15:1-2
* Acts 11:1-3
* Romans 02:25-27
* Galatians 05:3-4
* Ephesians 02:11-12
* Philippians 03:1-3
* Colossians 02:10-12
* Colossians 02:13-15
* __Open Bible Stories - 05:03__ "You must __circumcise__  every male in your family."
* __Open Bible Stories - 05:05__ That day Abraham __circumcised__  all the males in his household.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/defile')">defile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* Genesis 07:1-3
* Genesis 07:8-10
* Deuteronomy 12:15-16
* Psalms 051:7-9
* Proverbs 20:29-30
* Ezekiel 24:13
* Matthew 23:27-28
* Luke 05:12-13
* Acts 08:6-8
* Acts 10:27-29
* Colossians 03:5-8
* 1 Thessalonians 04:7-8
* James 04:8-10
(See <a style="cursor: pointer" onclick="return followLink('en/tw/other/decree')">decree</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/statute')">statute</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tencommandments')">Ten Commandments</a>)
* Luke 01:5-7
* Matthew 01:24-25
* Matthew 22:37-38
* Matthew 28:20
* Numbers 01:17-19
* Romans 07:7-8
* Daniel 01:8-10
* Hosea 13:14
* James 05:9-11
* Jonah 04:1-3
* Mark 01:40-42
* Romans 09:14-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>)
* 1 John 03:19-22
* Job 09:27-29
* John 05:24
* Luke 06:37
* Matthew 12:7-8
* Proverbs 17:15-16
* Psalms 034:21-22
* Romans 05:16-17
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/testimony')">testimony</a>)
* 1 John 01:8-10
* 2 John 01:7-8
* James 05:16-18
* Leviticus 05:5-6
* Matthew 03:4-6
* Nehemiah 01:6-7
* Philippians 02:9-11
* Psalms 038:17-18
* 1 Timothy 01:18-20
* 1 Timothy 03:8-10
* 2 Corinthians 05:11-12
* 2 Timothy 01:3-5
* Romans 09:1-2
* Titus 01:15-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/purify')">pure</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sanctify')">sanctify</a>)
* 1 Timothy 04:3-5
* 2 Chronicles 13:8-9
* Ezekiel 44:19
* Acts 04:11-12
* Ephesians 02:19-22
* Matthew 21:42
* Psalms 118:22-23
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promise')">promise</a>)
* Genesis 09:11-13
* Genesis 17:7-8
* Genesis 31:43-44
* Exodus 34:10-11
* Joshua 24:24-26
* 2 Samuel 23:5
* 2 Kings 18:11-12
* Mark 14:22-25
* Luke 01:72-75
* Luke 22:19-20
* Acts 07:6-8
* 1 Corinthians 11:25-26
* 2 Corinthians 03:4-6
* Galatians 03:17-18
* Hebrews 12:22-24
* __Open Bible Stories - 04:09__ Then God made a __covenant__  with Abram. A __covenant__  is an agreement between two parties.
* __Open Bible Stories - 05:04__ "I will make Ishmael a great nation, too, but my __covenant__  will be with Isaac."
* __Open Bible Stories - 06:04__ After a long time, Abraham died and all of the promises that God had made to him in the __covenant__  were passed on to Isaac.
* __Open Bible Stories - 07:10__ The __covenant__  promises God had promised to Abraham and then to Isaac now passed on to Jacob."
* __Open Bible Stories - 13:02__ God said to Moses and the people of Israel, "If you will obey my voice and keep my __covenant__, you will be my prized possession, a kingdom of priests, and a holy nation."
* __Open Bible Stories - 13:04__ Then God gave them the __covenant__  and said, "I am Yahweh, your God, who saved you from slavery in Egypt. Do not worship other gods."
* __Open Bible Stories - 15:13__ Then Joshua reminded the people of their obligation to obey the __covenant__  that God had made with the Israelites at Sinai.
* __Open Bible Stories - 21:05__ Through the prophet Jeremiah, God promised that he would make a __New Covenant__, but not like the covenant God made with Israel at Sinai. In the __New Covenant__, God would write his law on the people's hearts, the people would know God personally, they would be his people, and God would forgive their sins. The Messiah would start the __New Covenant__.
* __Open Bible Stories - 21:14__ Through the Messiah's death and resurrection, God would accomplish his plan to save sinners and start the __New Covenant__.
* __Open Bible Stories - 38:05__ Then Jesus took a cup and said, "Drink this. It is my blood of the __New Covenant__  that is poured out for the forgiveness of sins. Do this to remember me every time you drink it."
* __Open Bible Stories - 48:11__ But God has now made a __New Covenant__  that is available to everyone. Because of this __New Covenant__, anyone from any people group can become part of God's people by believing in Jesus.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/grace')">grace</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/peopleofgod')">people of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promise')">promise</a>)
* Ezra 03:10-11
* Numbers 14:17-19
* Also consider how this word is translated in a Bible translation in a local or national language. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/crucify')">crucify</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* 1 Corinthians 01:17
* Colossians 02:13-15
* Galatians 06:11-13
* John 19:17-18
* Luke 09:23-25
* Luke 23:26
* Matthew 10:37-39
* Philippians 02:5-8
* __Open Bible Stories - 40:01__ After the soldiers mocked Jesus, they led him away to crucify him. They made him carry the __cross__  on which he would die.
* __Open Bible Stories - 40:02__ The soldiers brought Jesus to a place called "the Skull" and nailed his arms and feet to the __cross__.
* __Open Bible Stories - 40:05__ The Jewish leaders and the other people in the crowd mocked Jesus. They said to him, "If you are the Son of God, come down from the __cross__  and save yourself! Then we will believe you."
* __Open Bible Stories - 49:10__ When Jesus died on the __cross__, he received your punishment.
* __Open Bible Stories - 49:12__ You must believe that Jesus is the Son of God, that he died on the __cross__  instead of you, and that God raised him to life again.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/cross')">cross</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Acts 02:22-24
* Galatians 02:20-21
* Luke 23:20-22
* Luke 23:33-34
* Matthew 20:17-19
* Matthew 27:23-24
* __Open Bible Stories - 39:11__ But the Jewish leaders and the crowd shouted, "__Crucify__ him (Jesus)!"
* __Open Bible Stories - 39:12__ Pilate became afraid that the crowd would begin to riot, so he ordered his soldiers to __crucify__ Jesus.played a major role in the crucifixion of Jesus Christ.
* __Open Bible Stories - 40:01__  After the soldiers mocked Jesus, they led him away to __crucify__ him. They made him carry the cross on which he would die.
* __Open Bible Stories - 40:04__ Jesus was __crucified__ between two robbers.
* __Open Bible Stories - 43:06__ "Men of Israel, Jesus was a man who did many mighty signs and wonders by the power of God, as you have seen and already know. But you __crucified__ him!" 
* __Open Bible Stories - 43:09__ "You __crucified__ this man, Jesus."
* __Open Bible Stories - 44:08__ Peter answered them, "This man stands before you healed by the power of Jesus the Messiah. You __crucified__ Jesus, but God raised him to life again!"
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bless')">bless</a>)
* 1 Samuel 14:24-26
* 2 Peter 02:12-14
* Galatians 03:10-12
* Galatians 03:13-14
* Genesis 03:14-15
* Genesis 03:17-19
* James 03:9-10
* Numbers 22:5-6
* Psalms 109:28-29
* __Open Bible Stories - 02:09__ God said to the snake, "You are __cursed__!"
* __Open Bible Stories - 02:11__ "Now the ground is __cursed__, and you will need to work hard to grow food."
* __Open Bible Stories - 04:04__ "I will bless those who bless you and __curse__  those who __curse__  you."
* __Open Bible Stories - 39:07__ Then Peter vowed, saying, "May God __curse__  me if I know this man!"
* __Open Bible Stories - 50:16__ Because Adam and Eve disobeyed God and brought sin into this world, God __cursed__  it and decided to destroy it.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/zion')">Zion</a>)
* Jeremiah 06:1-3
* John 12:14-15
* Matthew 21:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/biblicaltimeday')">day</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judgmentday')">judgment day</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">Lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/resurrection')">resurrection</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Corinthians 05:3-5
* 1 Thessalonians 05:1-3
* 2 Peter 03:10
* 2 Thessalonians 02:1-2
* Acts 02:20-21
* Philippians 01:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/minister')">minister</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>)
* 1 Timothy 03:8-10
* 1 Timothy 03:11-13
* Philippians 01:1-2
* Also consider how the term "demon" is translated in a local or national language. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demonpossessed')">demon-possessed</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>)
* James 02:18-20
* James 03:15-18
* Luke 04:35-37
* Mark 03:20-22
* Matthew 04:23-25
* __Open Bible Stories - 26:09__ Many people who had __demons__  in them were brought to Jesus. When Jesus commanded them, the __demons__  came out of the people, and often shouted, "You are the Son of God!"
* __Open Bible Stories - 32:08__ The __demons__  came out of the man and entered the pigs.
* __Open Bible Stories - 47:05__ Finally one day when the slave girl started yelling, Paul turned to her and said to the __demon__  that was in her, "In the name of Jesus, come out of her." Right away the __demon__  left her.
* __Open Bible Stories - 49:02__ He (Jesus) walked on water, calmed storms, healed many sick people, drove out __demons__, raised the dead to life, and turned five loaves of bread and two small fish into enough food for over 5,000 people.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>)
* Mark 01:32-34
* Matthew 04:23-25
* Matthew 08:16-17
* Matthew 08:33-34
* __Open Bible Stories - 26:09__ Many people who had __demons in them__  were brought to Jesus.
* __Open Bible Stories - 32:02__ When they reached the other side of the lake, a __demon-possessed__  man came running up to Jesus.
* __Open Bible Stories - 32:06__ The man __with the demon__  cried out in a loud voice, "What do you want with me, Jesus, Son of the Most High God? Please do not torture me!"
* __Open Bible Stories - 32:09__ The people from the town came and saw the man who used to __have the demons__.
* __Open Bible Stories - 47:03__ Every day as they (Paul and Silas) walked there, a slave girl __possessed by a demon__ followed them.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* Acts 06:1
* Acts 09:26-27
* Acts 11:25-26
* Acts 14:21-22
* John 13:23-25
* Luke 06:39-40
* Matthew 11:1-3
* Matthew 26:33-35
* Matthew 27:62-64
* __Open Bible Stories - 30:08__ He (Jesus) gave the pieces to his __disciples__ to give to the people. The __disciples__ kept passing out the food, and it never ran out!
* __Open Bible Stories - 38:01__ About three years after Jesus first began preaching and teaching publicly, Jesus told his __disciples__ that he wanted to celebrate this Passover with them in Jerusalem, and that he would be killed there.
* __Open Bible Stories - 38:11__ Then Jesus went with his __disciples__ to a place called Gethsemane. Jesus told his __disciples__ to pray that they would not enter into temptation.
* __Open Bible Stories - 42:10__ Jesus said to his __disciples__, "All authority in heaven and on earth has been given to me. So go, make __disciples__ of all people groups by baptizing them in the name of the Father, the Son, and the Holy Spirit, and by teaching them to obey everything I have commanded you."
* Ephesians 06:4
* Hebrews 12:4-6
* Proverbs 19:17-18
* Proverbs 23:13-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/glory')">glory</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>)
* 2 Corinthians 10:3-4
* 2 Peter 01:3-4
* Romans 01:20-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>)
* 1 Peter 05:10-11
* Colossians 01:13-14
* Jude 01:24-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/appoint')">appoint</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>)
* 2 John 01:1-3
* Colossians 03:12-14
* Ephesians 01:3-4
* Isaiah 65:22-23
* Luke 18:6-8
* Matthew 24:19-22
* Romans 08:33-34
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* 1 Samuel 02:18-19
* Exodus 28:4-5
* Hosea 03:4-5
* Judges 08:27-28
* Leviticus 08:6-7
* Also consider how this word is translated in a Bible translation in a local or national language. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/reign')">reign</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>)
* Genesis 17:7-8
* Genesis 48:3-4
* Exodus 15:17-18
* 2 Samuel 03:28-30
* 1 Kings 02:32-33
* Job 04:20-21
* Psalms 021:3-4
* Isaiah 09:6-7
* Isaiah 40:27-28
* Daniel 07:17-18
* Luke 18:18-21
* Acts 13:46-47
* Romans 05:20-21
* Hebrews 06:19-20
* Hebrews 10:11-14
* 1 John 01:1-2
* 1 John 05:11-12
* Revelation 01:4-6
* Revelation 22:3-5
* __Open Bible Stories - 27:01__ One day, an expert in the Jewish law came to Jesus to test him, saying, "Teacher, what must I do to inherit __eternal life__?"
* __Open Bible Stories - 28:01__ One day, a rich young ruler came up to Jesus and asked him, "Good Teacher, what must I do to have __eternal life__?" Jesus said to him, "Why do you ask me about what is good? There is only One who is good, and that is God. But if you want to have __eternal life__, obey God's laws."
* __Open Bible Stories - 28:10__ Jesus answered, "Everyone who has left houses, brothers, sisters, father, mother, children, or property for my name's sake, will receive 100 times more and will also receive __eternal life__."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/philip')">Philip</a>)
* Acts 08:26-28
* Acts 08:36-38
* Acts 08:39-40
* Isaiah 39:7-8
* Jeremiah 34:17-19
* Matthew 19:10-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gift')">gift</a>)
* 2 Timothy 04:3-5
* Ephesians 04:11-13
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/good')">good</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>)
* 1 Samuel 24:10-11
* 1 Timothy 06:9-10
* 3 John 01:9-10
* Genesis 02:15-17
* Genesis 06:5-6
* Job 01:1-3
* Job 08:19-20
* Judges 09:55-57
* Luke 06:22-23
* Matthew 07:11-12
* Proverbs 03:7-8
* Psalms 022:16-17
* __Open Bible Stories - 02:04__ "God just knows that as soon as you eat it, you will be like God and will understand good and __evil__  like he does."
* __Open Bible Stories - 03:01__ After a long time, many people were living in the world. They had become very __wicked__  and violent.
* __Open Bible Stories - 03:02__ But Noah found favor with God. He was a righteous man living among __wicked__  people.
* __Open Bible Stories - 04:02__ God saw that if they all kept working together to do __evil__, they could do many more sinful things.
* __Open Bible Stories - 08:12__ "You tried to do __evil__  when you sold me as a slave, but God used the __evil__  for good!"
* __Open Bible Stories - 14:02__ They (Canaanites) worshiped false gods and did many __evil__  things.
* __Open Bible Stories - 17:01__ But then he (Saul) became a __wicked__  man who did not obey God, so God chose a different man who would one day be king in his place.
* __Open Bible Stories - 18:11__ In the new kingdom of Israel, all the kings were __evil__.
* __Open Bible Stories - 29:08__ The king was so angry that he threw the __wicked__  servant into prison until he could pay back all of his debt.
* __Open Bible Stories - 45:02__ They said, "We heard him (Stephen) speak __evil__  things about Moses and God!"
* __Open Bible Stories - 50:17__ He (Jesus) will wipe away every tear and there will be no more suffering, sadness, crying, __evil__, pain, or death.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/praise')">praise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/glory')">glory</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/boast')">boast</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/proud')">proud</a>)
* 1 Peter 05:5-7
* 2 Samuel 22:47-49
* Acts 05:29-32
* Philippians 02:9-11
* Psalms 018:46-47
* 1 Thessalonians 02:3-4
* 1 Thessalonians 02:10-12
* 1 Timothy 05:1-2
* Luke 03:18-20
* For some languages these terms will be translated using forms of the verb "believe." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-abstractnouns')">abstractnouns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>)
* 2 Timothy 04:6-8
* Acts 06:7
* Galatians 02:20-21
* James 02:18-20
* __Open Bible Stories - 05:06__ When Isaac was a young man, God tested Abraham's __faith__  by saying, "Take Isaac, your only son, and kill him as a sacrifice to me."
* __Open Bible Stories - 31:07__ Then he (Jesus) said to Peter, "You man of little __faith__, why did you doubt?"
* __Open Bible Stories - 32:16__ Jesus said to her, "Your __faith__  has healed you. Go in peace."
* __Open Bible Stories - 38:09__ Then Jesus said to Peter, "Satan wants to have all of you, but I have prayed for you, Peter, that your __faith__  will not fail.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>)
* Genesis 24:49
* Leviticus 26:40-42
* Numbers 12:6-8
* Joshua 02:14
* Judges 02:16-17
* 1 Samuel 02:9
* Psalm 012:1
* Proverbs 11:12-13
* Isaiah 01:26
* Jeremiah 09:7-9
* Hosea 05:5-7
* Luke 12:45-46
* Luke 16:10-12
* Colossians 01:7-8
* 1 Thessalonians 05:23-24
* 3 John 01:5-8
* __Open Bible Stories - 08:05__ Even in prison, Joseph remained __faithful__  to God, and God blessed him.
* __Open Bible Stories - 14:12__ Even so, God was still __faithful__  to His promises to Abraham, Isaac, and Jacob.
* __Open Bible Stories - 15:13__ The people promised to remain __faithful__  to God and follow his laws.
* __Open Bible Stories - 17:09__ David ruled with justice and __faithfulness__  for many years, and God blessed him. However, toward the end of his life he sinned terribly against God.
* __Open Bible Stories - 18:04__ God was angry with Solomon and, as a punishment for Solomon's __unfaithfulness__, he promised to divide the nation of Israel into two kingdoms after Solomon's death.
* __Open Bible Stories - 35:12__ "The older son said to his father, 'All these years I have worked __faithfully__  for you!"
* __Open Bible Stories - 49:17__ But God is __faithful__  and says that if you confess your sins, he will forgive you.
* __Open Bible Stories - 50:04__ If you remain __faithful__  to me to the end, then God will save you."
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>)
* Ezekiel 43:6-8
* Ezra 09:1-2
* Jeremiah 02:18-19
* Proverbs 02:20-22
* Revelation 21:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/asherim')">Asherah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/molech')">Molech</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/image')">image</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* Genesis 35:1-3
* Exodus 32:1-2
* Psalms 031:5-7
* Psalms 081:8-10
* Isaiah 44:20
* Acts 07:41-42
* Acts 07:43
* Acts 15:19-21
* Acts 19:26-27
* Romans 02:21-22
* Galatians 04:8-9
* Galatians 05:19-21
* Colossians 03:5-8
* 1 Thessalonians 01:8-10
* __Open Bible Stories - 10:02__ Through these plagues, God showed Pharaoh that he is more powerful than Pharaoh and all of Egypt's __gods__.
* __Open Bible Stories - 13:04__ Then God gave them the covenant and said, "I am Yahweh, your God, who saved you from slavery in Egypt. Do not worship other __gods__."
* __Open Bible Stories - 14:02__ They (Canaanites) worshiped false __gods__  and did many evil things.
* __Open Bible Stories - 16:01__ The Israelites began to worship the Canaanite __gods__  instead of Yahweh, the true God.
* __Open Bible Stories - 18:13__ But most of Judah's kings were evil, corrupt, and they worshiped idols. Some of the kings even sacrificed their children to false __gods__.
* 1 Samuel 02:25-26
* 2 Chronicles 19:6-7
* 2 Corinthians 01:11
* Acts 24:26-27
* Genesis 41:14-16
* Genesis 47:25-26
* Genesis 50:4-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/amazed')">marvel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/awe')">awe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">Lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 John 04:17-18
* Acts 02:43-45
* Acts 19:15-17
* Genesis 50:18-21
* Isaiah 11:3-5
* Job 06:14-17
* Jonah 01:8-10
* Luke 12:4-5
* Matthew 10:28-31
* Proverbs 10:24-25
* 1 John 01:3-4
* Acts 02:40-42
* Philippians 01:3-6
* Philippians 02:1-2
* Philippians 03:8-11
* Psalms 055:12-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>)
* Acts 04:29-31
* Acts 05:17-18
* Acts 06:8-9
* Luke 01:14-15
* Luke 01:39-41
* Luke 04:1-2
* The expression "become one flesh" could be translated as "unite sexually" or "become as one body" or "become like one person in body and spirit." The translation of this expression should be checked to make sure it is acceptable in the project language and culture. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">euphemism</a>). It should also be understood that this is figurative, and does not mean that a man and a woman who "become one flesh" literally become one person. 
* 1 John 02:15-17
* 2 John 01:7-8
* Ephesians 06:12-13
* Galatians 01:15-17
* Genesis 02:24-25
* John 01:14-15
* Matthew 16:17-18
* Romans 08:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wise')">wise</a>)
* Ecclesiastes 01:16-18
* Ephesians 05:15-17
* Galatians 03:1-3
* Genesis 31:26-28
* Matthew 07:26-27
* Matthew 25:7-9
* Proverbs 13:15-16
* Psalms 049:12-13
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/guilt')">guilt</a>)
* Genesis 50:15-17
* Numbers 14:17-19
* Deuteronomy 29:20-21
* Joshua 24:19-20
* 2 Kings 05:17-19
* Psalms 025:10-11
* Psalms 025:17-19
* Isaiah 55:6-7
* Isaiah 40:1-2
* Luke 05:20-21
* Acts 08:20-23
* Ephesians 04:31-32
* Colossians 03:12-14
* 1 John 02:12-14
* __Open Bible Stories - 07:10__ But Esau had already __forgiven__  Jacob, and they were happy to see each other again.
* __Open Bible Stories - 13:15__ Then Moses climbed the mountain again and prayed that God would __forgive__  the people. God listened to Moses and __forgave__  them.
* __Open Bible Stories - 17:13__ David repented of his sin and God __forgave__  him.
* __Open Bible Stories - 21:05__ In the New Covenant, God would write his law on the people's hearts, the people would know God personally, they would be his people, and God would __forgive__  their sins.
* __Open Bible Stories - 29:01__ One day Peter asked Jesus, "Master, how many times should I __forgive__  my brother when he sins against me?"
* __Open Bible Stories - 29:08__ I __forgave__  your debt because you begged me.
* __Open Bible Stories - 38:05__ Then Jesus took a cup and said, "Drink this. It is my blood of the New Covenant that is poured out for the __forgiveness__  of sins.
* 1 Kings 06:11-13
* Daniel 11:29-30
* Genesis 24:26-27
* Joshua 24:16-18
* Matthew 27:45-47
* Proverbs 27:9-10
* Psalms 071:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/minister')">minister</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/call')">call</a>)
* 1 Kings 02:26-27
* Acts 03:17-18
* Leviticus 22:17-19
* Luke 04:20-22
* Matthew 01:22-23
* Matthew 05:17-18
* Psalms 116:12-15
* __Open Bible Stories - 24:04__ John __fulfilled__  what the prophets said, "See I send my messenger ahead of you, who will prepare your way."
* __Open Bible Stories - 40:03__ The soldiers gambled for Jesus' clothing. When they did this, they __fulfilled__  a prophecy that said, "They divided my garments among them, and gambled for my clothing."
* __Open Bible Stories - 42:07__ Jesus said, "I told you that everything written about me in God's word must be __fulfilled__."
* __Open Bible Stories - 43:05__ "This __fulfills__  the prophecy made by the prophet Joel in which God said, 'In the last days, I will pour out my Spirit.'"
* __Open Bible Stories - 43:07__ "This __fulfills__  the prophecy which says, 'You will not let your Holy One rot in the grave.'"
* __Open Bible Stories - 44:05__ "Although you did not understand what you were doing, God used your actions to __fulfill__  the prophecies that the Messiah would suffer and die."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>)
* Acts 09:13-16
* Acts 14:5-7
* Galatians 02:15-16
* Luke 02:30-32
* Matthew 05:46-48
* Matthew 06:5-7
* Romans 11:25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>)
* 1 Corinthians 12:1-3
* 2 Samuel 11:6-8
* Acts 08:20-23
* Acts 10:3-6
* Acts 11:17-18
* Acts 24:17-19
* James 01:17-18
* John 04:9-10
* Matthew 05:23-24
* Matthew 08:4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/exalt')">exalt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/praise')">praise</a>)
* Exodus 24:16-18
* Numbers 14:9-10
* Isaiah 35:1-2
* Luke 18:42-43
* Luke 02:8-9
* John 12:27-29
* Acts 03:13-14
* Acts 07:1-3
* Romans 08:16-17
* 1 Corinthians 06:19-20
* Philippians 02:14-16
* Philippians 04:18-20
* Colossians 03:1-4
* 1 Thessalonians 02:5-6
* James 02:1-4
* 1 Peter 04:15-16
* Revelation 15:3-4
* __Open Bible Stories - 23:07__ Suddenly, the skies were filled with angels praising God, saying, "__Glory__  to God in heaven and peace on earth to the people he favors!"
* __Open Bible Stories - 25:06__ Then Satan showed Jesus all the kingdoms of the world and all their __glory__  and said, "I will give you all this if you bow down and worship me."
* __Open Bible Stories - 37:01__ When Jesus heard this news, he said, "This sickness will not end in death, but it is for the __glory__  of God."
* __Open Bible Stories - 37:08__ Jesus responded, "Did I not tell you that you would see God's __glory__  if you believe in me?"
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/creation')">create</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godthefather')">God the Father</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 John 01:5-7
* 1 Samuel 10:7-8
* 1 Timothy 04:9-10
* Colossians 01:15-17
* Deuteronomy 29:14-16
* Ezra 03:1-2
* Genesis 01:1-2
* Hosea 04:11-12
* Isaiah 36:6-7
* James 02:18-20
* Jeremiah 05:4-6
* John 01:1-3
* Joshua 03:9-11
* Lamentations 03:40-43
* Micah 04:4-5
* Philippians 02:5-8
* Proverbs 24:11-12
* Psalms 047:8-9
* __Open Bible Stories - 01:01__ __God__  created the universe and everything in it in six days.
* __Open Bible Stories - 01:15__ __God__  made man and woman in his own image.
* __Open Bible Stories - 05:03__ "I am __God__  Almighty. I will make a covenant with you."
* __Open Bible Stories - 09:14__ __God__  said, "I AM WHO I AM. Tell them, 'I AM has sent me to you.' Also tell them, 'I am Yahweh, the __God__  of your ancestors Abraham, Isaac, and Jacob. This is my name forever.'"
* __Open Bible Stories - 10:02__ Through these plagues, __God__  showed Pharaoh that he is more powerful than Pharaoh and all of Egypt's gods.
* __Open Bible Stories - 16:01__ The Israelites began to worship the Canaanite gods instead of Yahweh, the true __God__.
* __Open Bible Stories - 22:07__ You, my son, will be called the prophet of the __Most High God__  who will prepare the people to receive the Messiah!"
* __Open Bible Stories - 24:09__ There is only one __God__. But John heard __God__  the Father speak, and saw Jesus the Son and the Holy Spirit when he baptized Jesus.
* __Open Bible Stories - 25:07__ "Worship only the Lord your __God__  and only serve him."
* __Open Bible Stories - 28:01__ "There is only one who is good, and that is __God__."
* __Open Bible Stories - 49:09__ But __God__  loved everyone in the world so much that he gave his only Son so that whoever believes in Jesus will not be punished for his sins, but will live with __God__  forever.
* __Open Bible Stories - 50:16__ But some day __God__  will create a new heaven and a new earth that will be perfect.
* The phrase "the godly" could be translated as "godly people" or "people who obey God." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-nominaladj')">nominaladj</a>)
(See also <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>)
* Job 27:8-10
* Proverbs 11:9-11
* Acts 03:11-12
* 1 Timothy 01:9-11
* 1 Timothy 04:6-8
* 2 Timothy 03:10-13
* Hebrews 12:14-17
* Hebrews 11:7
* 1 Peter 04:17-19
* Jude 01:14-16
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>)
* 1 Corinthians 08:4-6
* 1 John 02:1-3
* 1 John 02:22-23
* 1 John 03:1-3
* Colossians 01:1-3
* Ephesians 05:18-21
* Luke 10:22
* Matthew 05:15-16
* Matthew 23:8-10
* __Open Bible Stories - 24:09__ There is only one God. But John heard __God the Father__  speak, and saw Jesus the Son and the Holy Spirit when he baptized Jesus.
* __Open Bible Stories - 29:09__ Then Jesus said, "This is what my __heavenly Father__  will do to every one of you if you do not forgive your brother from your heart."
* __Open Bible Stories - 37:09__ Then Jesus looked up to heaven and said, "__Father__, thank you for hearing me."
* __Open Bible Stories - 40:07__ Then Jesus cried out, "It is finished! __Father__, I give my spirit into your hands."
* __Open Bible Stories - 42:10__ "So go, make disciples of all people groups by baptizing them in the name of __the Father__, the Son, and the Holy Spirit and by teaching them to obey everything I have commanded you."
* __Open Bible Stories - 43:08__ "Jesus is now exalted to the right hand of __God the Father__."
* __Open Bible Stories - 50:10__ "Then the righteous ones will shine like the sun in the kingdom of __God their Father__."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/profit')">profit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>)
* Galatians 05:22-24
* Genesis 01:11-13
* Genesis 02:9-10
* Genesis 02:15-17
* James 03:13-14
* Romans 02:3-4
* __Open Bible Stories - 01:04__ God saw that what he had created was __good__.
* __Open Bible Stories - 01:11__ God plantedâ€¦the tree of the knowledge of __good__  and evil."
* __Open Bible Stories - 01:12__ Then God said, "It is not __good__  for man to be alone."
* __Open Bible Stories - 02:04__ "God just knows that as soon as you eat it, you will be like God and will understand __good__  and evil like he does."
* __Open Bible Stories - 08:12__ "You tried to do evil when you sold me as a slave, but God used the evil for __good__!"
* __Open Bible Stories - 14:15__ Joshua was a __good__  leader because he tTable of Contentsrusted and obeyed God.
* __Open Bible Stories - 18:13__ Some of these kings were __good__  men who ruled justly and worshiped God.
* __Open Bible Stories - 28:01__ "__Good__  teacher, what must I do to have eternal life?" Jesus said to him, "Why do you call me '__good__?' There is only one who is __good__, and that is God."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>)
* 1 Thessalonians 01:4-5
* Acts 08:25
* Colossians 01:21-23
* Galatians 01:6-7
* Luke 08:1-3
* Mark 01:14-15
* Philippians 02:22-24
* Romans 01:1-3
* __Open Bible Stories - 23:06__ The angel said, "Do not be afraid, because I have some __good news__  for you. The Messiah, the Master, has been born in Bethlehem!"
* __Open Bible Stories - 26:03__ Jesus read, "God has given me his Spirit so that I can proclaim __good news__  to the poor, freedom to captives, recovery of sight for the blind, and release to the oppressed. This is the year of the Lord's favor."
* __Open Bible Stories - 45:10__ Philip also used other Scriptures to tell him the __good news of Jesus__.
* __Open Bible Stories - 46:10__ Then they sent them off to preach the __good news about Jesus__  in many other places.
* __Open Bible Stories - 47:01__ One day, Paul and his friend Silas went to the town of Philippi to proclaim the __good news about Jesus__.
* __Open Bible Stories - 47:13__ The __good news about Jesus__  kept spreading, and the Church kept growing.
* __Open Bible Stories - 50:01__ For almost 2,000 years, more and more people around the world have been hearing the __good news about Jesus__  the Messiah.
* __Open Bible Stories - 50:02__ When Jesus was living on earth he said, "My disciples will preach the __good news__  about the kingdom of God to people everywhere in the world, and then the end will come."
* __Open Bible Stories - 50:03__ Before he returned to heaven, Jesus told Christians to proclaim the __good news__  to people who have never heard it.
* Acts 04:32-33
* Acts 06:8-9
* Acts 14:3-4
* Colossians 04:5-6
* Colossians 04:18
* Genesis 43:28-29
* James 04:6-7
* John 01:16-18
* Philippians 04:21-23
* Revelation 22:20-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/innocent')">innocent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/iniquity')">iniquity</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* Exodus 28:36-38
* Isaiah 06:6-7
* James 02:10-11
* John 19:4-6
* Jonah 01:14-16
* __Open Bible Stories - 39:02__ They brought many witnesses who lied about him (Jesus). However, their statements did not agree with each other, so the Jewish leaders could not prove he was __guilty__  of anything.
* __Open Bible Stories - 39:11__ After speaking with Jesus, Pilate went out to the crowd and said, "I find no __guilt__  in this man." But the Jewish leaders and the crowd shouted, "Crucify him!" Pilate replied, "He is not __guilty__." But they shouted even louder. Then Pilate said a third time, "He is not __guilty__!"
* __Open Bible Stories - 40:04__ Jesus was crucified between two robbers. One of them mocked Jesus, but the other said, "Don't you fear God? We are __guilty__, but this man is innocent.
* __Open Bible Stories - 49:10__ Because of your sin, you are __guilty__  and deserve to die.
* Some translations keep the words "Sheol" and "Hades," spelling them to fit the sound patterns of the language of translation. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>).
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hell')">hell</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tomb')">tomb</a>)
* Acts 02:29-31
* Genesis 44:27-29
* Jonah 02:1-2
* Luke 10:13-15
* Luke 16:22-23
* Matthew 11:23-24
* Matthew 16:17-18
* Revelation 01:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/hard')">hard</a>)
* 1 John 03:16-18
* 1 Thessalonians 02:3-4
* 2 Thessalonians 03:13-15
* Acts 08:20-23
* Acts 15:7-9
* Luke 08:14-15
* Mark 02:5-7
* Matthew 05:5-8
* Matthew 22:37-38
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingdomofgod')">kingdom of God</a>)
* 1 Kings 08:22-24
* 1 Thessalonians 01:8-10
* 1 Thessalonians 04:16-18
* Deuteronomy 09:1-2
* Ephesians 06:9
* Genesis 01:1-2
* Genesis 07:11-12
* John 03:12-13
* John 03:27-28
* Matthew 05:17-18
* Matthew 05:46-48
* __Open Bible Stories - 04:02__ They even began building a tall tower to reach __heaven__.
* __Open Bible Stories - 14:11__ He (God) gave them bread from __heaven__, called "manna."
* __Open Bible Stories - 23:07__ Suddenly, the skies were filled with angels praising God, saying, "Glory to God in __heaven__  and peace on earth to the people he favors!"
* __Open Bible Stories - 29:09__ Then Jesus said, "This is what my __heavenly__  Father will do to every one of you if you do not forgive your brother from your heart."
* __Open Bible Stories - 37:09__ Then Jesus looked up to __heaven__  and said, "Father, thank you for hearing me."
* __Open Bible Stories - 42:11__ Then Jesus went up to __heaven__, and a cloud hid him from their sight.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>)
* Acts 26:12-14
* Genesis 39:13-15
* Genesis 40:14-15
* Genesis 41:12-13
* John 05:1-4
* John 19:12-13
* Jonah 01:8-10
* Philippians 03:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hades')">Hades</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/abyss')">abyss</a>)
* James 03:5-6
* Luke 12:4-5
* Mark 09:42-44
* Matthew 05:21-22
* Matthew 05:29-30
* Matthew 10:28-31
* Matthew 23:32-33
* Matthew 25:41-43
* Revelation 20:13-15
* __Open Bible Stories - 50:14__ He (God) will throw them into __hell__, where they will weep and grind their teeth in anguish forever. A fire that never goes out will continually burn them, and worms will never stop eating them.
* __Open Bible Stories - 50:15__ He will throw Satan into __hell__ where he will burn forever, along with everyone who chose to follow him rather than to obey God.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/annas')">Annas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/caiaphas')">Caiaphas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/chiefpriests')">chief priests</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* Acts 05:26-28
* Acts 07:1-3
* Acts 09:1-2
* Exodus 30:10
* Hebrews 06:19-20
* Leviticus 16:32-33
* Luke 03:1-2
* Mark 02:25-26
* Matthew 26:3-5
* Matthew 26:51-54
* __Open Bible Stories - 13:08__ No one could enter the room behind the curtain except the __high priest__, because God lived there.
* __Open Bible Stories - 21:07__ The Messiah who would come would be the perfect __high priest__  who would offer himself as a perfect sacrifice to God.
* __Open Bible Stories - 38:03__ The Jewish leaders, led by the __high priest__, paid Judas thirty silver coins to betray Jesus.
* __Open Bible Stories - 39:01__ The soldiers led Jesus to the house of the __high priest__  in order for the __high priest__  to question him.
* __Open Bible Stories - 39:03__ Finally, the __high priest__  looked directly at Jesus and said, "Tell us, are you the Messiah, the Son of the living God?"
* __Open Bible Stories - 44:07__ The next day, the Jewish leaders brought Peter and John to the __high priest__  and the other religious leaders.
* __Open Bible Stories - 45:02__ So the religious leaders arrested Stephen and brought him to the __high priest__  and the other leaders of the Jews, where more false witnesses lied about Stephen.
* __Open Bible Stories - 46:01__ The __high priest__  gave Saul permission to go to the city of Damascus to arrest Christians there and bring them back to Jerusalem.
* __Open Bible Stories - 48:06__ Jesus is the Great __High Priest__. Unlike other priests, he offered himself as the only sacrifice that could to take away the sin of all the people in the world. Jesus was the perfect __high priest__  because he took the punishment for every sin that anyone has ever committed.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/consecrate')">consecrate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sanctify')">sanctify</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/setapart')">set apart</a>)
* Genesis 28:20-22
* 2 Kings 03:1-3
* Lamentations 04:1-2
* Ezekiel 20:18-20
* Matthew 07:6
* Mark 08:38
* Acts 07:33-34
* Acts 11:7-10
* Romans 01:1-3
* 2 Corinthians 12:3-5
* Colossians 01:21-23
* 1 Thessalonians 03:11-13
* 1 Thessalonians 04:7-8
* 2 Timothy 03:14-15
* __Open Bible Stories - 01:16__ He (God) blessed the seventh day and made it __holy__, because on this day he rested from his work.
* __Open Bible Stories - 09:12__ "You are standing on __holy__  ground."
* __Open Bible Stories - 13:01__ "If you will obey me and keep my covenant, you will be my prized possession, a kingdom of priests, and a __holy__  nation."
* __Open Bible Stories - 13:05__ "Always be sure to keep the Sabbath day __holy__."
* __Open Bible Stories - 22:05__ "So the baby will be __holy__, the Son of God."
* __Open Bible Stories - 50:02__ As we wait for Jesus to return, God wants us to live in a way that is __holy__  and that honors him.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>)
* 1 John 02:20-21
* 2 Kings 19:20-22
* Acts 02:27-28
* Acts 03:13-14
* Isaiah 05:15-17
* Isaiah 41:14-15
* Luke 04:33-34
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/altarofincense')">altar of incense</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/bread')">bread</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/consecrate')">consecrate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/courtyard')">courtyard</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/curtain')">curtain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/setapart')">set apart</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 1 Kings 06:16-18
* Acts 06:12-15
* Exodus 26:31-33
* Exodus 31:10-11
* Ezekiel 41:1-2
* Ezra 09:8-9
* Hebrews 09:1-2
* Leviticus 16:17-19
* Matthew 24:15-18
* Revelation 15:5-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">Lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godthefather')">God the Father</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gift')">gift</a>)
* 1 Samuel 10:9-10
* 1 Thessalonians 04:7-8
* Acts 08:14-17
* Galatians 05:25-26
* Genesis 01:1-2
* Isaiah 63:10
* Job 33:4-5
* Matthew 12:31-32
* Matthew 28:18-19
* Psalms 051:10-11
* __Open Bible Stories - 01:01__ But __God's Spirit__  was there over the water.
* __Open Bible Stories - 24:08__ When Jesus came up out of the water after being baptized, __the Spirit of God__  appeared in the form of a dove and came down and rested on him.
* __Open Bible Stories - 26:01__ After overcoming Satan's temptations, Jesus returned in the power of __the Holy Spirit__  to the region of Galilee where he lived.
* __Open Bible Stories - 26:03__ Jesus read, "God has given me __his Spirit__  so that I can proclaim good news to the poor, freedom to captives, recovery of sight for the blind, and release to the oppressed."
* __Open Bible Stories - 42:10__ "So go, make disciples of all people groups by baptizing them in the name of the Father, the Son, and __the Holy Spirit__  and by teaching them to obey everything I have commanded you."
* __Open Bible Stories - 43:03__ They were all filled with the __Holy Spirit__  and they began to speak in other languages.
* __Open Bible Stories - 43:08__ "And Jesus has sent the __Holy Spirit__  just as he promised he would do. The __Holy Spirit__  is causing the things that you are are now seeing and hearing."
* __Open Bible Stories - 43:11__ Peter answered them, "Every one of you should repent and be baptized in the name of Jesus Christ so that God will forgive your sins. Then he will also give you the gift of the __Holy Spirit__."
* __Open Bible Stories - 45:01__ He (Stephen) had a good reputation and was full of the __Holy Spirit__  and of wisdom.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/dishonor')">dishonor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/glory')">glory</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/glory')">glory</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/praise')">praise</a>)
* 1 Samuel 02:8
* Acts 19:15-17
* John 04:43-45
* John 12:25-26
* Mark 06:4-6
* Matthew 15:4-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bless')">bless</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/confidence')">confidence</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/good')">good</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/trust')">trust</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>)
* 1 Chronicles 29:14-15
* 1 Thessalonians 02:17-20
* Acts 24:14-16
* Acts 26:6-8
* Acts 27:19-20
* Colossians 01:4-6
* Job 11:20
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/peopleofgod')">people of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 1 Timothy 03:14-15
* 2 Chronicles 23:8-9
* Ezra 05:12-13
* Genesis 28:16-17
* Judges 18:30-31
* Mark 02:25-26
* Matthew 12:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/proud')">proud</a>)
* James 01:19-21
* James 03:13-14
* James 04:8-10
* Luke 14:10-11
* Luke 18:13-14
* Matthew 18:4-6
* Matthew 23:11-12
* __Open Bible Stories - 17:02__ David was a __humble__ and righteous man who trusted and obeyed God.
* __Open Bible Stories - 34:10__ "God will __humble__ everyone who is proud, and he will lift up whoever __humbles__ himself."
* Galatians 02:13-14
* Luke 06:41-42
* Luke 12:54-56
* Luke 13:15-16
* Mark 07:6-7
* Matthew 06:1-2
* Romans 12:9-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/image')">image</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>)
* 2 Corinthians 04:3-4
* Colossians 03:9-11
* Genesis 01:26-27
* Genesis 09:5-7
* James 03:9-10
* Romans 08:28-30
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">Lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>)
* 1 John 02:4-6
* 2 Corinthians 02:16-17
* 2 Timothy 01:1-2
* Galatians 01:21-24
* Galatians 02:17-19
* Philemon 01:4-7
* Revelation 01:9-11
* Romans 09:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/heir')">heir</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promisedland')">Promised Land</a>)
* 1 Corinthians 06:9-11
* 1 Peter 01:3-5
* 2 Samuel 21:2-3
* Acts 07:4-5
* Deuteronomy 20:16-18
* Galatians 05:19-21
* Genesis 15:6-8
* Hebrews 09:13-15
* Jeremiah 02:7-8
* Luke 15:11-12
* Matthew 19:29-30
* Psalm 079:1-3
* __Open Bible Stories - 04:06__ When Abram arrived in Canaan God said, "Look all around you. I will give to you and your descendants all the land that you can see as an __inheritance__."
* __Open Bible Stories - 27:01__ One day, an expert in the Jewish law came to Jesus to test him, saying, "Teacher, what must I do to __inherit__  eternal life?"
* __Open Bible Stories - 35:03__ "There was a man who had two sons. The younger son told his father, 'Father, I want my __inheritance__  now!' So the father divided his property between the two sons."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/transgression')">transgress</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/trespass')">trespass</a>)
* Daniel 09:12-14
* Exodus 34:5-7
* Genesis 15:14-16
* Genesis 44:16-17
* Habakkuk 02:12-14
* Matthew 13:40-43
* Matthew 23:27-28
* Micah 03:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/guilt')">guilt</a>)
* 1 Corinthians 04:3-4
* 1 Samuel 19:4-5
* Acts 20:25-27
* Exodus 23:6-9
* Jeremiah 22:17-19
* Job 09:21-24
* Romans 16:17-18
* __Open Bible Stories - 08:06__ After two years, Joseph was still in prison, even though he was __innocent__.
* __Open Bible Stories - 40:04__ One of them mocked Jesus, but the other said, "Do you have no fear of God? We are guilty, but this man is __innocent__."
* __Open Bible Stories - 40:08__ When the soldier guarding Jesus saw everything that happened, he said, "Certainly, this man was __innocent__. He was the Son of God."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pray')">pray</a>)
* Hebrews 07:25-26
* Isaiah 53:12
* Jeremiah 29:6-7
* Romans 08:26-27
* Romans 08:33-34
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/nation')">nation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 10:1-3
* 1 Kings 08:1-2
* Acts 02:34-36
* Acts 07:22-25
* Acts 13:23-25
* John 01:49-51
* Luke 24:21
* Mark 12:28-31
* Matthew 02:4-6
* Matthew 27:9-10
* Philippians 03:4-5
* __Open Bible Stories - 08:15__ The descendants of the twelve sons became the twelve tribes of __Israel__.
* __Open Bible Stories - 09:03__ The Egyptians forced the __Israelites__ to build many buildings and even whole cities.
* __Open Bible Stories - 09:05__ A certain __Israelite__ woman gave birth to a baby boy.
* __Open Bible Stories - 10:01__ They said, "This is what the God of __Israel__ says, 'Let my people go!'"
* __Open Bible Stories - 14:12__ But despite all this, the people of __Israel __ complained and grumbled against God and against Moses.
* __Open Bible Stories - 15:09__ God fought for __Israel__ that day. He caused the Amorites to be confused and he sent large hailstones that killed many of the Amorites.
* __Open Bible Stories - 15:12__ After this battle, God gave each tribe of __Israel __ its own section of the Promised Land. Then God gave __Israel__ peace along all its borders.
* __Open Bible Stories - 16:16__ So God punished __Israel __ again for worshiping idols.
* __Open Bible Stories - 43:06__ "Men of __Israel__, Jesus was a man who did many mighty signs and wonders by the power of God, as you have seen and already know."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/envy')">envy</a>)
* 2 Corinthians 12:20-21
* Deuteronomy 05:9-10
* Exodus 20:4-6
* Ezekiel 36:4-6
* Joshua 24:19-20
* Nahum 01:2-3
* Romans 13:13-14
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godthefather')">God the Father</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingdomofgod')">kingdom of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mary')">Mary</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/savior')">Savior</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>)
* 1 Corinthians 06:9-11
* 1 John 02:1-3
* 1 John 04:15-16
* 1 Timothy 01:1-2
* 2 Peter 01:1-2
* 2 Thessalonians 02:13-15
* 2 Timothy 01:8-11
* Acts 02:22-24
* Acts 05:29-32
* Acts 10:36-38
* Hebrews 09:13-15
* Hebrews 10:19-22
* Luke 24:19-20
* Matthew 01:20-21
* Matthew 04:1-4
* Philippians 02:5-8
* Philippians 02:9-11
* Philippians 04:21-23
* Revelation 01:4-6
* __Open Bible Stories - 22:04__ The angel said, "You will become pregnant and give birth to a son. You are to name him __Jesus__  and he will be the Messiah."
* __Open Bible Stories - 23:02__ "Name him __Jesus__  (which means, 'Yahweh saves'), because he will save the people from their sins."
* __Open Bible Stories - 24:07__ So John baptized him (Jesus), even though __Jesus__  had never sinned.
* __Open Bible Stories - 24:09__ There is only one God. But John heard God the Father speak, and saw __Jesus__  the Son and the Holy Spirit when he baptized __Jesus__.
* __Open Bible Stories - 25:08__ __Jesus__  did not give in to Satan's temptations, so Satan left him.
* __Open Bible Stories - 26:08__ Then __Jesus__  went throughout the region of Galilee, and large crowds came to him. They brought many people who were sick or handicapped, including those who could not see, walk, hear, or speak, and __Jesus__  healed them.
* __Open Bible Stories - 31:03__ Then __Jesus__  finished praying and went to the disciples. He walked on top of the water across the lake toward their boat!
* __Open Bible Stories - 38:02__ He (Judas) knew that the Jewish leaders denied that __Jesus__  was the Messiah and that they were plotting to kill him.
* __Open Bible Stories - 40:08__ Through his death, __Jesus__  opened a way for people to come to God.
* __Open Bible Stories - 42:11__ Then __Jesus__  was taken up to heaven, and a cloud hid him from their sight. __Jesus__  sat down at the right hand of God to rule over all things.
* __Open Bible Stories - 50:17__ __Jesus__  and his people will live on the new earth, and he will reign forever over everything that exists. He will wipe away every tear and there will be no more suffering, sadness, crying, evil, pain, or death. __Jesus__  will rule his kingdom with peace and justice, and he will be with his people forever.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>)
* Acts 02:5-7
* Acts 10:27-29
* Acts 14:5-7
* Colossians 03:9-11
* John 02:13-14
* Matthew 28:14-15
* __Open Bible Stories - 20:11__ The Israelites were now called __Jews__  and most of them had lived their whole lives in Babylon.
* __Open Bible Stories - 20:12__ So, after seventy years in exile, a small group of __Jews__  returned to the city of Jerusalem in Judah.
* __Open Bible Stories - 37:10__ Many of the __Jews__  believed in Jesus because of this miracle.
* __Open Bible Stories - 37:11__ But the religious leaders of the __Jews__  were jealous, so they gathered together to plan how they could kill Jesus and Lazarus.
* __Open Bible Stories - 40:02__ Pilate commanded that they write, "King of the __Jews__" on a sign and put it on the cross above Jesus' head.
* __Open Bible Stories - 46:06__ Right away, Saul began preaching to the __Jews__  in Damascus, saying, "Jesus is the Son of God!"
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/decree')">decree</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/judgeposition')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judgmentday')">judgment day</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/justice')">just</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>)
* 1 John 04:17-18
* 1 Kings 03:7-9
* Acts 10:42-43
* Isaiah 03:13-15
* James 02:1-4
* Luke 06:37
* Micah 03:9-11
* Psalm 054:1-3
* __Open Bible Stories - 19:16__ The prophets warned the people that if they did not stop doing evil and start obeying God, then God would __judge__  them as guilty, and he would punish them.
* __Open Bible Stories - 21:08__ A king is someone who rules over a kingdom and __judges__  the people. The Messiah would come would be the perfect king who would sit on the throne of his ancestor David. He would reign over the whole world forever, and who would always __judge__  honestly and make the right decisions.
* __Open Bible Stories - 39:04__ The high priest tore his clothes in anger and shouted to the other religious leaders, "We do not need any more witnesses! You have heard him say that he is the Son of God. What is your __judgment__?"
* __Open Bible Stories - 50:14__ But God will __judge__  everyone who does not believe in Jesus. He will throw them into hell, where they will weep and grind their teeth in anguish forever.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hell')">hell</a>)
* Luke 10:10-12
* Luke 11:31
* Luke 11:32
* Matthew 10:14-15
* Matthew 12:36-37
* Ways to translate "injustice" could include, "wrong treatment" or "unfair treatment" or "acting unfairly." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-abstractnouns')">abstractnouns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/guilt')">guilt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>)
* Genesis 44:16-17
* 1 Chronicles 18:14-17
* Isaiah 04:3-4
* Jeremiah 22:1-3
* Ezekiel 18:16-17
* Micah 03:8
* Matthew 05:43-45
* Matthew 11:18-19
* Matthew 23:23-24
* Luke 18:3-5
* Luke 18:6-8
* Luke 18:13-14
* Luke 21:20-22
* Luke 23:39-41
* Acts 13:38-39
* Acts 28:3-4
* Romans 04:1-3
* Galatians 03:6-9
* Galatians 03:10-12
* Galatians 05:3-4
* Titus 03:6-7
* Hebrews 06:9-10
* James 02:21-24
* Revelation 15:3-4
* __Open Bible Stories - 17:09__ David ruled with __justice__  and faithfulness for many years, and God blessed him.
* __Open Bible Stories - 18:13__ Some of these kings (of Judah) were good men who ruled __justly__  and worshiped God.
* __Open Bible Stories - 19:16__ They (the prophets) all told the people to stop worshiping idols and to start showing __justice__  and mercy to others.
* __Open Bible Stories - 50:17__ Jesus will rule his kingdom with peace and __justice__, and he will be with his people forever.
* The Jews often used the term "heaven" to refer to God, to avoid saying his name directly. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metonymy')">metonymy</a>) 
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingofthejews')">King of the Jews</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/reign')">reign</a>)
* 2 Thessalonians 01:3-5
* Acts 08:12-13
* Acts 28:23-24
* Colossians 04:10-11
* John 03:3-4
* Luke 07:27-28
* Luke 10:8-9
* Luke 12:31-32
* Matthew 03:1-3
* Matthew 04:17
* Matthew 05:9-10
* Romans 14:16-17
* __Open Bible Stories - 24:02__ He (John) preached to them, saying, "Repent, for the __kingdom of God__  is near!"
* __Open Bible Stories - 28:06__ Then Jesus said to his disciples, "It is extremely hard for rich people to enter into the __kingdom of God__! Yes, it is easier for a camel to go through the eye of a needle than for a rich man to enter the __kingdom of God__."
* __Open Bible Stories - 29:02__ Jesus said, "The __kingdom of God__  is like a king who wanted to settle accounts with his servants."
* __Open Bible Stories - 34:01__ Jesus told many other stories about the __kingdom of God__. For example, he said, "The __kingdom of God__  is like a mustard seed that someone planted in his field."
* __Open Bible Stories - 34:03__ Jesus told another story, "The __kingdom of God__  is like yeast that a woman mixes into some bread dough until it spreads throughout the dough."
* __Open Bible Stories - 34:04__ "The __kingdom of God__  is also like hidden treasure that someone hid in a field.. Another man found the treasure and then buried it again."
* __Open Bible Stories - 34:05__ "The __kingdom of God__  is also like a perfect pearl of great value."
* __Open Bible Stories - 42:09__ He proved to his disciples in many ways that he was alive, and he taught them about the __kingdom of God__.
* __Open Bible Stories - 49:05__ Jesus said that the __kingdom of God__  is more valuable than anything else in the world.
* __Open Bible Stories - 50:02__ When Jesus was living on earth he said, "My disciples will preach the good news about the __kingdom of God__  to people everywhere in the world, and then the end will come."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingdomofgod')">kingdom of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wisemen')">wise men</a>)
* Luke 23:3-5
* Luke 23:36-38
* Matthew 02:1-3
* Matthew 27:11-14
* Matthew 27:35-37
* __Open Bible Stories - 23:09__ Some time later, wise men from countries far to the east saw an unusual star in the sky. They realized it meant a new __king of the Jews__  was born.
* __Open Bible Stories - 39:09__ Pilate asked Jesus, "Are you the __King of the Jews__?"
* __Open Bible Stories - 39:12__ The Roman soldiers whipped Jesus and put a royal robe and a crown made of thorns on him. Then they mocked him by saying, "Look, the __King of the Jews__!"
* __Open Bible Stories - 40:02__ Pilate commanded that they write, "__King of the Jews__" on a sign and put it on the cross above Jesus' head.
(See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>)
* 2 Samuel 12:1-3
* Ezra 08:35-36
* Isaiah 66:3
* Jeremiah 11:18-20
* John 01:29-31
* John 01:35-36
* Leviticus 14:21-23
* Leviticus 17:1-4
* Luke 10:3-4
* Revelation 15:3-4
* __Open Bible Stories - 05:07__ As Abraham and Isaac walked to the place of the sacrifice Isaac asked, "Father, we have wood for the sacrifice, but where is the __lamb__?"
* __Open Bible Stories - 11:02__ God provided a way to save the firstborn son of anyone who believed in him. Each family had to choose a perfect __lamb__ or goat and kill it.
* __Open Bible Stories - 24:06__ The next day, Jesus came to be baptized by John. When John saw him, he said, "Look! There is the __Lamb of God__ who will take away the sin of the world."
* __Open Bible Stories - 45:08__ He read, "They led him like a __lamb__ to be killed, and as a __lamb__ is silent, he did not say a word.
* __Open Bible Stories - 48:08__ When God told Abraham to offer his son, Isaac, as a sacrifice, God provided a __lamb__ for the sacrifice instead of his son, Isaac. We all deserve to die for our sins! But God provided Jesus, the __Lamb__ of God, as a sacrifice to die in our place.
* __Open Bible Stories - 48:09__ When God sent the last plague on Egypt, he told each Israelite family to kill a perfect __lamb__ and spread its blood around the tops and sides of their door frames.
* Amos 08:9-10
* Ezekiel 32:1-2
* Jeremiah 22:17-19
* Job 27:15-17
* Lamentations 02:5-6
* Lamentations 02:8-9
* Micah 02:3-5
* Psalm 102:1-2
* Zechariah 11:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/dayofthelord')">day of the Lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/turn')">turn</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/world')">world</a>)
* 2 Peter 03:3-4
* Daniel 10:14-15
* Hebrews 01:1-3
* Isaiah 02:1-2
* James 05:1-3
* Jeremiah 23:19-20
* John 11:24-26
* Micah 04:1
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/instruct')">instruct</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tencommandments')">Ten Commandments</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/lawful')">lawful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* Acts 15:5-6
* Daniel 09:12-14
* Exodus 28:42-43
* Ezra 07:25-26
* Galatians 02:15-16
* Luke 24:44
* Matthew 05:17-18
* Nehemiah 10:28-29
* Romans 03:19-20
* __Open Bible Stories - 13:07__ God also gave many other __laws__  and rules to follow. If the people obeyed these __laws__, God promised that he would bless and protect them. If they disobeyed them, God would punish them.\\
* __Open Bible Stories - 13:09__ Anyone who disobeyed __God's law__  could bring an animal to the altar in front of the Tent of Meeting as a sacrifice to God.\\
* __Open Bible Stories - 15:13__ Then Joshua reminded the people of their obligation to obey the covenant that God had made with the Israelites at Sinai. The people promised to remain faithful to God and follow __his laws__.\\
* __Open Bible Stories - 16:01__ After Joshua died, the Israelites disobeyed God and did not drive out the rest of the Canaanites or obey __God's laws__.\\
* __Open Bible Stories - 21:05__ In the New Covenant, God would write __his law__  on the people's hearts, the people would know God personally, they would be his people, and God would forgive their sins.\\
* __Open Bible Stories - 27:01__ Jesus answered, "What is written in __God's law__?"\\
* __Open Bible Stories - 28:01__ Jesus said to him, "Why do you call me 'good?' There is only one who is good, and that is God. But if you want to have eternal life, obey __God's laws__."\\
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eternity')">everlasting</a>)
* 2 Peter 01:3-4
* Acts 10:42-43
* Genesis 02:7-8
* Genesis 07:21-22
* Hebrews 10:19-22
* Jeremiah 44:1-3
* John 01:4-5
* Judges 02:18-19
* Luke 12:22-23
* Matthew 07:13-14
* __Open Bible Stories - 01:10__ So God took some dirt, formed it into a man, and breathed __life__  into him.
* __Open Bible Stories - 03:01__ After a long time, many people were __living __  in the world.
* __Open Bible Stories - 08:13__ When Joseph's brothers returned home and told their father, Jacob, that Joseph was still __alive__, he was very happy.
* __Open Bible Stories - 17:09__ However, toward the end of his [David's] __life__  he sinned terribly before God.
* __Open Bible Stories - 27:01__ One day, an expert in the Jewish law came to Jesus to test him, saying, "Teacher, what must I do to inherit eternal __life__?"
* __Open Bible Stories - 35:05__ Jesus replied, "I am the Resurrection and the __Life__."
* __Open Bible Stories - 44:05__ "You are the ones who told the Roman governor to kill Jesus. You killed the author of __life__, but God raised him from the dead."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* Genesis 39:1-2
* Joshua 03:9-11
* Psalms 086:15-17
* Jeremiah 27:1-4
* Lamentations 02:1-2
* Ezekiel 18:29-30
* Daniel 09:9-11
* Daniel 09:17-19
* Malachi 03:1-3
* Matthew 07:21-23
* Luke 01:30-33
* Luke 16:13
* Romans 06:22-23
* Ephesians 06:9
* Philippians 02:9-11
* Colossians 03:22-25
* Hebrews 12:14-17
* James 02:1-4
* 1 Peter 01:3-5
* Jude 01:5-6
* Revelation 15:3-4
* __Open Bible Stories - 25:05__ But Jesus replied to Satan by quoting from the Scriptures. He said, "In God's word, he commands his people, 'Do not test the __Lord__  your God.'"
* __Open Bible Stories - 25:07__ Jesus replied, "Get away from me, Satan! In God's word he commands his people, 'Worship only the __Lord__  your God and only serve him.'"
* __Open Bible Stories - 26:03__ This is the year of the __Lord's__  favor.
* __Open Bible Stories - 27:02__ The law expert replied that God's law says, "Love the __Lord__  your God with all your heart, soul, strength, and mind."
* __Open Bible Stories - 31:05__ Then Peter said to Jesus, "__Master__, if it is you, command me to come to you on the water"
* __Open Bible Stories - 43:09__ "But know for certain that God has caused Jesus to become both __Lord__  and Messiah!"
* __Open Bible Stories - 47:03__ By means of this demon she predicted the future for people, she made a lot of money for her __masters__  as a fortuneteller.
* __Open Bible Stories - 47:11__ Paul answered, "Believe in Jesus, the __Master__, and you and your family will be saved."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/passover')">Passover</a>)
* 1 Corinthians 11:20-22
* 1 Corinthians 11:25-26
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">Lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Corinthians 04:3-4
* 2 Samuel 07:21-23
* Deuteronomy 03:23-25
* Ezekiel 39:25-27
* Ezekiel 45:18-20
* Jeremiah 44:26-28
* Judges 06:22-24
* Micah 01:2-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* 1 Corinthians 13:4-7
* 1 John 03:1-3
* 1 Thessalonians 04:9-12
* Galatians 05:22-24
* Genesis 29:15-18
* Isaiah 56:6-7
* Jeremiah 02:1-3
* John 03:16-18
* Matthew 10:37-39
* Nehemiah 09:32-34
* Philippians 01:9-11
* Song of Solomon 01:1-4
* __Open Bible Stories - 27:02__ The law expert replied that God's law says, "__Love__  the Lord your God with all your heart, soul, strength, and mind. And __love__  your neighbor as yourself."
* __Open Bible Stories - 33:08__ "The thorny ground is a person who hears God's word, but, as time passes, the cares, riches, and pleasures of life choke out his __love__  for God."
* __Open Bible Stories - 36:05__ As Peter was talking, a bright cloud came down on top of them and a voice from the cloud said, "This is my Son whom I __love__."
* __Open Bible Stories - 39:10__ "Everyone who __loves__  the truth listens to me."
* __Open Bible Stories - 47:01__ She (Lydia) __loved__  and worshiped God.
* __Open Bible Stories - 48:01__ When God created the world, everything was perfect. There was no sin. Adam and Eve __loved__  each other, and they __loved__  God.
* __Open Bible Stories - 49:03__ He (Jesus) taught that you need to __love__  other people the same way you love yourself.
* __Open Bible Stories - 49:04__ He (Jesus) also taught that you need to __love__  God more than you __love__  anything else, including your wealth.
* __Open Bible Stories - 49:07__ Jesus taught that God __loves__  sinners very much.
* __Open Bible Stories - 49:09__ But God __loved__  everyone in the world so much that he gave his only Son so that whoever believes in Jesus will not be punished for his sins, but will live with God forever.
* __Open Bible Stories - 49:13__ God __loves__  you and wants you to believe in Jesus so he can have a close relationship with you.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>)
* 2 Peter 01:16-18
* Daniel 04:36-37
* Isaiah 02:9-11
* Jude 01:24-25
* Micah 05:4-5
* Also consider how this term is translated in a Bible translation in a local or national language. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bread')">bread</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sabbath')">Sabbath</a>)
* Deuteronomy 08:3
* Exodus 16:26-27
* Hebrews 09:3-5
* John 06:30-31
* Joshua 05:12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/compassion')">compassion</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>)
* 1 Peter 01:3-5
* 1 Timothy 01:12-14
* Daniel 09:17-19
* Exodus 34:5-7
* Genesis 19:16-17
* Hebrews 10:28-29
* James 02:12-13
* Luke 06:35-36
* Matthew 09:27-28
* Philippians 02:25-27
* Psalms 041:4-6
* Romans 12:1-2
* __Open Bible Stories - 19:16__ They (the prophets) all told the people to stop worshiping idols and to start showing justice and __mercy__  to others.
* __Open Bible Stories - 19:17__ He (Jeremiah) sank down into the mud that was in the bottom of the well, but then the king had __mercy__  on him and ordered his servants to pull Jeremiah out of the well before he died.
* __Open Bible Stories - 20:12__ The Persian Empire was strong but __merciful__  to the people it conquered.
* __Open Bible Stories - 27:11__ Then Jesus asked the law expert, "What do you think? Which one of the three men was a neighbor to the man who was robbed and beaten?" He replied, "The one who was __merciful__  to him."
* __Open Bible Stories - 32:11__ But Jesus said to him, "No, I want you to go home and tell your friends and family about everything that God has done for you and how he has had __mercy__  on you."
* __Open Bible Stories - 34:09__ "But the tax collector stood far away from the religious ruler, did not even look up to heaven. Instead, he pounded on his chest and prayed, 'God, please be __merciful__  to me because I am a sinner.'"
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">serve</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* 2 Samuel 20:23-26
* Acts 06:2-4
* Acts 21:17-19
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sign')">sign</a>)
* 2 Thessalonians 02:8-10
* Acts 04:15-18
* Acts 04:21-22
* Daniel 04:1-3
* Deuteronomy 13:1-3
* Exodus 03:19-22
* John 02:11
* Matthew 13:57-58
* __Open Bible Stories - 16:08__ Gideon asked God for two __signs__  so he could be sure that God would use him to save Israel.
* __Open Bible Stories - 19:14__ God did many __miracles__  through Elisha.
* __Open Bible Stories - 37:10__ Many of the Jews believed in Jesus because of this __miracle__.
* __Open Bible Stories - 43:06__ "Men of Israel, Jesus was a man who did many mighty __signs__  and __wonders__  by the power of God, as you have seen and already know."
* __Open Bible Stories - 49:02__ Jesus did many __miracles__  that prove he is God. He walked on water, calmed storms, healed many sick people, drove out demons, raised the dead to life, and turned five loaves of bread and two small fish into enough food for over 5,000 people.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>)
* Acts 07:47-50
* Acts 16:16-18
* Daniel 04:17-18
* Deuteronomy 32:7-8
* Genesis 14:17-18
* Hebrews 07:1-3
* Hosea 07:16
* Lamentations 03:34-36
* Luke 01:30-33
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/frankincense')">frankincense</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/learnedmen')">learned men</a>)
* Exodus 30:22-25
* Genesis 37:25-26
* John 11:1-2
* Mark 15:22-24
* Matthew 02:11-12
* The "name" of someone could refer to the entire person, as in "there is no other name under heaven by which we must be saved." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metonymy')">metonymy</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/call')">call</a>)
* 1 John 02:12-14
* 2 Timothy 02:19-21
* Acts 04:5-7
* Acts 04:11-12
* Acts 09:26-27
* Genesis 12:1-3
* Genesis 35:9-10
* Matthew 18:4-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samson')">Samson</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/vow')">vow</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahot')">Zechariah (OT)</a>)
* Acts 18:18-19
* Amos 02:11-12
* Judges 13:3-5
* Numbers 06:1-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>)
* Luke 05:36
* Luke 06:39-40
* Luke 08:4-6
* Luke 08:9-10
* Mark 04:1-2
* Matthew 13:3-6
* Matthew 13:10-12
* Matthew 13:13-14
* 1 Corinthians 05:6-8
* 2 Chronicles 30:13-15
* 2 Kings 23:21-23
* Deuteronomy 16:1-2
* Exodus 12:26-28
* Ezra 06:21-22
* John 13:1-2
* Joshua 05:10-11
* Leviticus 23:4-6
* Numbers 09:1-3
* __Open Bible Stories - 12:14__ God commanded the Israelites to remember his victory over the Egyptians and their deliverance from slavery by celebrating the __Passover__  every year.
* __Open Bible Stories - 38:01__ Every year, the Jews celebrated the __Passover__. This was a celebration of how God had saved their ancestors from slavery in Egypt many centuries earlier.
* __Open Bible Stories - 38:04__ Jesus celebrated the __Passover__  with his disciples.
* __Open Bible Stories - 48:09__ When God saw the blood, he passed over their houses and did not kill their firstborn sons. This event is called the __Passover__.
* __Open Bible Stories - 48:10__ Jesus is our __Passover__  Lamb. He was perfect and sinless and was killed at the time of the __Passover__  celebration.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>)
* Ephesians 04:11-13
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/festival')">festival</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/firstfruit')">firstfruits</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/harvest')">harvest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/raise')">raise</a>)
* 2 Chronicles 08:12-13
* Acts 02:1-4
* Acts 20:15-16
* Deuteronomy 16:16-17
* Numbers 28:26-28
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peoplegroup')">people group</a>)
* 1 Chronicles 11:1-3
* Acts 07:33-34
* Acts 07:51-53
* Acts 10:36-38
* Daniel 09:24-25
* Isaiah 02:5-6
* Jeremiah 06:20-22
* Joel 03:16-17
* Micah 06:3-5
* Revelation 13:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eternity')">everlasting</a>)
* 1 Peter 01:22-23
* 2 Corinthians 02:16-17
* 2 Thessalonians 02:8-10
* Jeremiah 18:18-20
* Psalms 049:18-20
* Zechariah 09:5-7
* Zechariah 13:8-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/council')">council</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sadducee')">Sadducee</a>)
* Acts 26:4-5
* John 03:1-2
* Luke 11:43-44
* Matthew 03:7-9
* Matthew 05:19-20
* Matthew 09:10-11
* Matthew 12:1-2
* Matthew 12:38-40
* Philippians 03:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>)
* 1 Thessalonians 01:4-5
* Colossians 01:11-12
* Genesis 31:29-30
* Jeremiah 18:21-23
* Jude 01:24-25
* Judges 02:18-19
* Luke 01:16-17
* Luke 04:14-15
* Matthew 26:62-64
* Philippians 03:20-21
* Psalm 080:1-3
* __Open Bible Stories - 22:05__ The angel explained, "The Holy Spirit will come to you, and the __power__  of God will overshadow you. So the baby will be holy, the Son of God."
* __Open Bible Stories - 26:01__ After overcoming Satan's temptations, Jesus returned in the __power__  of the Holy Spirit to the region of Galilee where he lived.
* __Open Bible Stories - 32:15__ Immediately Jesus realized that __power__  had gone out from him.
* __Open Bible Stories - 42:11__ Forty days after Jesus rose from the dead, he told his disciples, "Stay in Jerusalem until my Father gives you __power__  when the Holy Spirit comes on you."
* __Open Bible Stories - 43:06__ "Men of Israel, Jesus was a man who did many mighty signs and wonders by the __power__  of God, as you have seen and already know."
* __Open Bible Stories - 44:08__ Peter answered them, "This man stands before you healed by the __power__  of Jesus the Messiah."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/praise')">praise</a>)
* 1 Thessalonians 03:8-10
* Acts 08:24
* Acts 14:23-26
* Colossians 04:2-4
* John 17:9-11
* Luke 11:1
* Matthew 05:43-45
* Matthew 14:22-24
* __Open Bible Stories - 06:05__  Isaac __prayed__ for Rebekah, and God allowed her to get pregnant with twins.
* __Open Bible Stories - 13:12__  But Moses __prayed__ for them, and God listened to his __prayer__ and did not destroy them.
* __Open Bible Stories - 19:08__  Then the prophets of Baal __prayed__ to Baal, "Hear us, O Baal!"
* __Open Bible Stories - 21:07__  Priests also __prayed__ to God for the people.
* __Open Bible Stories - 38:11__  Jesus told his disciples to __pray__ that they would not enter into temptation.
* __Open Bible Stories - 43:13__ The disciples continually listened to the teaching of the apostles, spent time together, ate together, and __prayed__ with each other.
* __Open Bible Stories - 49:18__  God tells you to __pray__, to study his word, to worship him with other Christians, and to tell others what he has done for you.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/foreordain')">foreknew</a>)
* 1 Corinthians 02:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aaron')">Aaron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/chiefpriests')">chief priests</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/mediator')">mediator</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* 2 Chronicles 06:40-42
* Genesis 14:17-18
* Genesis 47:20-22
* John 01:19-21
* Luke 10:31-32
* Mark 01:43-44
* Mark 02:25-26
* Matthew 08:4
* Matthew 12:3-4
* Micah 03:9-11
* Nehemiah 10:28-29
* Nehemiah 10:34-36
* Revelation 01:4-6
* __Open Bible Stories - 04:07__ "Melchizedek, the __priest__ of God Most High"
* __Open Bible Stories - 13:09__ Anyone who disobeyed God's law could bring an animal to the altar in front of the Tent of Meeting as a sacrifice to God. A __priest__ would kill the animal and burn it on the altar. The blood of the animal that was sacrificed covered the person's sin and made that person clean in God's sight. God chose Moses' brother, Aaron, and Aaron's descendants to be his __priests__.
* __Open Bible Stories - 19:07__ So the __priests__ of Baal prepared a sacrifice but did not light the fire.
* __Open Bible Stories - 21:07__ An Israelite __priest__ was someone who made sacrifices to God on behalf of the people as a substitute for the punishment of their sins. __Priests__ also prayed to God for the people.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/oath')">oath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/vow')">vow</a>)
* Galatians 03:15-16
* Genesis 25:31-34
* Hebrews 11:8-10
* James 01:12-13
* Numbers 30:1-2
* __Open Bible Stories - 03:15__ God said, "I __promise__  I will never again curse the ground because of the evil things people do, or destroy the world by causing a flood, even though people are sinful from the time they are children."Â�
* __Open Bible Stories - 03:16__ God then made the first rainbow as a sign of his __promise__. Every time the rainbow appeared in the sky, God would remember what he __promised__  and so would his people.
* __Open Bible Stories - 04:08__ God spoke to Abram and __promised__  again that he would have a son and as many descendants as the stars in the sky. Abram believed God's __promise__.
* __Open Bible Stories - 05:04__ "Your wife, Sarai, will have a son—he will be the son of __promise__."
* __Open Bible Stories - 08:15__ The covenant __promises__  that God gave to Abraham were passed on to Isaac, then to Jacob, and then to Jacob's twelve sons and their families.
* __Open Bible Stories - 17:14__ Though David had been unfaithful to God, God was still faithful to his __promises__.
* __Open Bible Stories - 50:01__ Jesus __promised__  he would return at the end of the world. Though he has not yet come back, he will keep his __promise__.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promise')">promise</a>)
* Deuteronomy 08:1-2
* Ezekiel 07:26-27
* __Open Bible Stories - 12:01__ They (Israelites) were no longer slaves, and they were going to the __Promised Land__!
* __Open Bible Stories - 14:01__ After God had told the Israelites the laws he wanted them to obey as part of his covenant with them, God began leading them from Mount Sinai toward the __Promised Land__, which was also called Canaan.
* __Open Bible Stories - 14:02__ God had promised Abraham, Isaac, and Jacob that he would give the __Promised Land__  to their descendants, but now there were many people groups living there.
* __Open Bible Stories - 14:14__ Then God led the people to the edge of the __Promised Land__  again.
* __Open Bible Stories - 15:02__ The Israelites had to cross the Jordan River to enter into the __Promised Land__.
* __Open Bible Stories - 15:12__ After this battle, God gave each tribe of Israel its own section of the __Promised Land__.
* __Open Bible Stories - 20:09__ This period of time when God's people were forced to leave the __Promised Land__  is called the Exile.
* The figurative expression, "law and the prophets" could also be translated as, "the books of the law and of the prophets" or "everything written about God and his people, including God's laws and what his prophets preached." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/divination')">divination</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/falseprophet')">false prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fulfill')">fulfill</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vision')">vision</a>)
* 1 Thessalonians 02:14-16
* Acts 03:24-26
* John 01:43-45
* Malachi 04:4-6
* Matthew 01:22-23
* Matthew 02:17-18
* Matthew 05:17-18
* Psalm 051:1-2
* __Open Bible Stories - 12:12__ When the Israelites saw that the Egyptians were dead, they trusted in God and believed that Moses was a __prophet__  of God.
* __Open Bible Stories - 17:13__ God was very angry about what David had done, so he sent the __prophet__  Nathan to tell David how evil his sin was.
* __Open Bible Stories - 19:01__ Throughout the history of the Israelites, God sent them __prophets__. The __prophets__  heard messages from God and then told the people God's messages.
* __Open Bible Stories - 19:06__ All the people of the entire kingdom of Israel, including the 450 __prophets__  of Baal, came to Mount Carmel.
* __Open Bible Stories - 19:17__ Most of the time, the people did not obey God. They often mistreated the __prophets__  and sometimes even killed them.
* __Open Bible Stories - 21:09__ The __prophet__  Isaiah __prophesied__  that the Messiah would be born from a virgin.
* __Open Bible Stories - 43:05__ "This fulfills the __prophecy__  made by the __prophet__  Joel in which God said, 'In the last days, I will pour out my Spirit.'"
* __Open Bible Stories - 43:07__ "This fulfills the __prophecy__  which says, 'You will not let your Holy One rot in the grave.'"
* __Open Bible Stories - 48:12__ Moses was a great __prophet__  who proclaimed the word of God. But Jesus is the greatest __prophet__  of all. He is the Word of God.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/atonement')">atonement</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eternity')">everlasting</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* 1 John 02:1-3
* 1 John 04:9-10
* Romans 03:25-26
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/joy')">joy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>)
* Acts 13:32-34
* Acts 13:35-37
* Colossians 03:15-17
* Luke 20:41-44
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/atonement')">atonement</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 1 Timothy 01:5-8
* Exodus 31:6-9
* Hebrews 09:13-15
* James 04:8-10
* Luke 02:22-24
* Revelation 14:3-5
See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/teacher')">teacher</a>)
* John 01:49-51
* John 06:24-25
* Mark 14:43-46
* Matthew 23:8-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/atonement')">atonement</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/redeem')">redeem</a>)
* 1 Timothy 02:5-7
* Isaiah 43:2-3
* Job 06:21-23
* Leviticus 19:20-22
* Matthew 20:25-28
* Psalms 049:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/peace')">peace</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* 2 Corinthians 05:18-19
* Colossians 01:18-20
* Matthew 05:23-24
* Proverbs 13:17-18
* Romans 05:10-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/free')">free</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ransom')">ransom</a>)
* Colossians 01:13-14
* Ephesians 01:7-8
* Ephesians 05:15-17
* Galatians 03:13-14
* Galatians 04:3-5
* Luke 02:36-38
* Ruth 02:19-20
* Acts 15:15-18
* Amos 09:11-12
* Ezekiel 06:8-10
* Genesis 45:7-8
* Isaiah 11:10-11
* Micah 04:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/turn')">turn</a>)
* Acts 03:19-20
* Luke 03:3
* Luke 03:8
* Luke 05:29-32
* Luke 24:45-47
* Mark 01:14-15
* Matthew 03:1-3
* Matthew 03:10-12
* Matthew 04:17
* Romans 02:3-4
* __Open Bible Stories - 16:02__ After many years of disobeying God and being oppressed by their enemies, the Israelites __repented__  and asked God to rescue them.
* __Open Bible Stories - 17:13__ David __repented__  of his sin and God forgave him.
* __Open Bible Stories - 19:18__ They (prophets) warned people that God would destroy them if they did not __repent__.
* __Open Bible Stories - 24:02__ Many people came out to the wilderness to listen to John. He preached to them, saying, "__Repent__, for the kingdom of God is near!"
* __Open Bible Stories - 42:08__ ""It was also written in the scriptures that my disciples will proclaim that everyone should repent in order to __receive__  forgiveness for their sins. "
* __Open Bible Stories - 44:05__ "So now, __repent__  and turn to God so that your sins will be washed away."
* 2 Kings 05:8-10
* Acts 03:21-23
* Acts 15:15-18
* Isaiah 49:5-6
* Jeremiah 15:19-21
* Lamentations 05:19-22
* Leviticus 06:5-7
* Luke 19:8-10
* Matthew 12:13-14
* Psalm 080:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/raise')">raise</a>)
* 1 Corinthians 15:12-14
* 1 Peter 03:21-22
* Hebrews 11:35-38
* John 05:28-29
* Luke 20:27-28
* Luke 20:34-36
* Matthew 22:23-24
* Matthew 22:29-30
* Philippians 03:8-11
* __Open Bible Stories - 21:14__ Through the Messiah's death and __resurrection__, God would accomplish his plan to save sinners and start the New Covenant.
* __Open Bible Stories - 37:05__ Jesus replied, "I am the __Resurrection__  and the Life. Whoever believes in me will live, even though he dies.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/dream')">dream</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vision')">vision</a>)
* Daniel 11:1-2
* Ephesians 03:3-5
* Galatians 01:11-12
* Lamentations 02:13-14
* Matthew 10:26-27
* Philippians 03:15-16
* Revelation 01:1-3
* Terms such as "integrity" and "righteous" have similar meanings and are sometimes used in parallelism constructions, such as "integrity and uprightness."  (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-parallelism')">parallelism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/good')">good</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/integrity')">integrity</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/justice')">just</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/purify')">pure</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/lawful')">unlawful</a>)
* Deuteronomy 19:15-16
* Job 01:6-8
* Psalms 037:28-30
* Psalms 049:14-15
* Psalms 107:41-43
* Ecclesiastes 12:10-11
* Isaiah 48:1-2
* Ezekiel 33:12-13
* Malachi 02:5-7
* Matthew 06:1-2
* Acts 03:13-14
* Romans 01:29-31
* 1 Corinthians 06:9-11
* Galatians 03:6-9
* Colossians 03:22-25
* 2 Thessalonians 02:8-10
* 2 Timothy 03:16-17
* 1 Peter 03:18-20
* 1 John 01:8-10
* 1 John 05:16-17
* __Open Bible Stories - 03:02__ But Noah found favor with God. He was a __righteous__  man, living among wicked people.
* __Open Bible Stories - 04:08__ God declared that Abram was __righteous__  because he believed in God's promise.
* __Open Bible Stories - 17:02__ David was a humble and __righteous__  man who trusted and obeyed God.
* __Open Bible Stories - 23:01__ Joseph, the man Mary was engaged to, was a __righteous__  man.
* __Open Bible Stories - 50:10__ Then the __righteous__  ones will shine like the sun in the kingdom of God their Father."
* The figurative expression "his right hand and his mighty arm" uses two ways of emphasizing God's power and great strength. One way to translate this expression could be "his amazing strength and mighty power." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-parallelism')">parallelism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/accuse')">accuse</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/mighty')">mighty</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/rebel')">rebel</a>)
* Acts 02:32-33
* Colossians 03:1-4
* Galatians 02:9-10
* Genesis 48:14-16
* Hebrews 10:11-14
* Lamentations 02:3-4
* Matthew 25:31-33
* Matthew 26:62-64
* Psalms 044:3-4
* Revelation 02:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/rest')">rest</a>)
* 2 Chronicles 31:2-3
* Acts 13:26-27
* Exodus 31:12-15
* Isaiah 56:6-7
* Lamentations 02:5-6
* Leviticus 19:1-4
* Luke 13:12-14
* Mark 02:27-28
* Matthew 12:1-2
* Nehemiah 10:32-33
* __Open Bible Stories - 13:05__ "Always be sure to keep the __Sabbath day__  holy. That is, do all your work in six days, for the seventh day is a day for you to rest and to honor me."
* __Open Bible Stories - 26:02__ Jesus went to the town of Nazareth where he had lived during his childhood. On the __Sabbath__, he went to the place of worship.
* __Open Bible Stories - 41:03__ The day after Jesus was buried was a __Sabbath__  day, and the Jews were not permitted to go to the tomb on that day.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/chiefpriests')">chief priests</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/council')">council</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hypocrite')">hypocrite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pharisee')">Pharisee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* Acts 04:1-4
* Acts 05:17-18
* Luke 20:27-28
* Matthew 03:7-9
* Matthew 16:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>)
* 1 Timothy 05:9-10
* 2 Corinthians 09:12-15
* Revelation 16:4-7
* Revelation 20:9-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/consecrate')">consecrate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/setapart')">set apart</a>)
* 1 Thessalonians 04:3-6
* 2 Thessalonians 02:13-15
* Genesis 02:1-3
* Luke 11:2
* Matthew 06:8-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/setapart')">set apart</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tax')">tax</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, )
* Amos 07:12-13
* Exodus 25:3-7
* Ezekiel 25:3-5
* Hebrews 08:1-2
* Luke 11:49-51
* Numbers 18:1-2
* Psalms 078:67-69
(See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingdomofgod')">kingdom of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tempt')">tempt</a>)
* 1 John 03:7-8
* 1 Thessalonians 02:17-20
* 1 Timothy 05:14-16
* Acts 13:9-10
* Job 01:6-8
* Mark 08:33-34
* Zechariah 03:1-3
* __Open Bible Stories - 21:01__ The snake who deceived Eve was __Satan__. The promise meant that the Messiah who would come would defeat __Satan__  completely.
* __Open Bible Stories - 25:06__ Then __Satan__  showed Jesus all the kingdoms of the world and all their glory and said, "I will give you all this if you bow down and worship me."
* __Open Bible Stories - 25:08__ Jesus did not give in to __Satan's__  temptations, so __Satan__  left him.
* __Open Bible Stories - 33:06__ So Jesus explained, "The seed is the word of God. The path is a person who hears God's word, but does not understand it, and the __devil__  takes the word from him."
* __Open Bible Stories - 38:07__ After Judas took the bread, __Satan__  entered into him.
* __Open Bible Stories - 48:04__ God promised that one of Eve's descendants would crush __Satan's__  head, and __Satan__  would wound his heel. This meant that __Satan__  would kill the Messiah, but God would raise him to life again, and then the Messiah will crush the power of __Satan__  forever.
* __Open Bible Stories - 49:15__ God has taken you out of __Satan's__  kingdom of darkness and put you into God's kingdom of light.
* __Open Bible Stories - 50:09__ "The weeds represent the people who belong to the __evil one__. The enemy who planted the weeds represents the __devil__."
* __Open Bible Stories - 50:10__ "When the world ends, the angels will gather together all the people who belong to the __devil__  and throw them into a raging fire, where they will cry and grind their teeth in terrible suffering."
* __Open Bible Stories - 50:15__ When Jesus returns, he will completely destroy __Satan__  and his kingdom. He will throw __Satan__  into hell where he will burn forever, along with everyone who chose to follow him rather than to obey God.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/cross')">cross</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/deliverer')">deliver</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/savior')">Savior</a>)
* Genesis 49:16-18
* Genesis 47:25-26
* Psalms 080:1-3
* Jeremiah 16:19-21
* Micah 06:3-5
* Luke 02:30-32
* Luke 08:36-37
* Acts 04:11-12
* Acts 28:28
* Acts 02:20-21
* Romans 01:16-17
* Romans 10:8-10
* Ephesians 06:17-18
* Philippians 01:28-30
* 1 Timothy 01:15-17
* Revelation 19:1-2
* __Open Bible Stories - 09:08__ Moses tried to __save__  his fellow Israelite.
* __Open Bible Stories - 11:02__ God provided a way to __save__  the firstborn son of anyone who believed in him.
* __Open Bible Stories - 12:05__ Moses told the Israelites, "Stop being afraid! God will fight for you today and __save__  you."
* __Open Bible Stories - 12:13__ The Israelites sang many songs to celebrate their new freedom and to praise God because he __saved__  them from the Egyptian army.
* __Open Bible Stories - 16:17__ This pattern repeated many times: the Israelites would sin, God would punish them, they would repent, and God would send a deliverer to __save__  them.
* __Open Bible Stories - 44:08__ "You crucified Jesus, but God raised him to life again! You rejected him, but there is no other way to be __saved__  except through the power of Jesus!"
* __Open Bible Stories - 47:11__ The jailer trembled as he came to Paul and Silas and asked, "What must I do to be __saved__?" Paul answered, "Believe in Jesus, the Master, and you and your family will be __saved__."
* __Open Bible Stories - 49:12__ Good works cannot __save__  you.
* __Open Bible Stories - 49:13__ God will __save__  everyone who believes in Jesus and receives him as their Master. But he will not __save__  anyone who does not believe in him.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/deliverer')">deliver</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>)
* 1 Timothy 04:9-10
* 2 Peter 02:20-22
* Acts 05:29-32
* Isaiah 60:15-16
* Luke 01:46-47
* Psalms 106:19-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pharisee')">Pharisee</a>)
* Acts 04:5-7
* Luke 07:29-30
* Luke 20:45-47
* Mark 01:21-22
* Mark 02:15-16
* Matthew 05:19-20
* Matthew 07:28-29
* Matthew 12:38-40
* Matthew 13:51-53
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sanctify')">sanctify</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/appoint')">appoint</a>)
* Ephesians 03:17-19
* Exodus 31:12-15
* Judges 17:12-13
* Numbers 03:11-13
* Philippians 01:1-2
* Romans 01:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/circumcise')">circumcise</a>)
* Acts 02:18-19
* Exodus 04:8-9
* Exodus 31:12-15
* Genesis 01:14-15
* Genesis 09:11-13
* John 02:17-19
* Luke 02:10-12
* Mark 08:11-13
* Psalms 089:5-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/flesh')">flesh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tax')">tax collector</a>)
* 1 Chronicles 09:1-3
* 1 John 01:8-10
* 1 John 02:1-3
* 2 Samuel 07:12-14
* Acts 03:19-20
* Daniel 09:24-25
* Genesis 04:6-7
* Hebrews 12:1-3
* Isaiah 53:10-11
* Jeremiah 18:21-23
* Leviticus 04:13-15
* Luke 15:17-19
* Matthew 12:31-32
* Romans 06:22-23
* Romans 08:3-5
* __Open Bible Stories - 03:15__ God said, "I promise I will never again curse the ground because of the evil things people do, or destroy the world by causing a flood, even though people are __sinful__  from the time they are children."
* __Open Bible Stories - 13:12__ God was very angry with them because of their __sin__  and planned to destroy them.
* __Open Bible Stories - 20:01__ The kingdoms of Israel and Judah both __sinned__  against God. They broke the covenant that God made with them at Sinai.
* __Open Bible Stories - 21:13__ The prophets also said that the Messiah would be perfect, having no __sin__. He would die to receive the punishment for other people's __sin__.
* __Open Bible Stories - 35:01__ One day, Jesus was teaching many tax collectors and other __sinners__  who had gathered to hear him.
* __Open Bible Stories - 38:05__ Then Jesus took a cup and said, "Drink this. It is my blood of the New Covenant that is poured out for the forgiveness of __sins__.
* __Open Bible Stories - 43:11__ Peter answered them, "Every one of you should repent and be baptized in the name of Jesus Christ so that God will forgive your __sins__."
* __Open Bible Stories - 48:08__ We all deserve to die for our __sins__!
* __Open Bible Stories - 49:17__ Even though you are a Christian, you will still be tempted to __sin__. But God is faithful and says that if you confess your __sins__, he will forgive you. He will give you strength to fight against __sin__.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/azariah')">Azariah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/firstborn')">firstborn</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonsofgod')">sons of God</a>)
* 1 Chronicles 18:14-17
* 1 Kings 13:1-3
* 1 Thessalonians 05:4-7
* Galatians 04:6-7
* Hosea 11:1-2
* Isaiah 09:6-7
* Matthew 03:16-17
* Matthew 05:9-10
* Matthew 08:11-13
* Nehemiah 10:28-29
* __Open Bible Stories - 04:08__ God spoke to Abram and promised again that he would have a __son__  and as many descendants as the stars in the sky.
* __Open Bible Stories - 04:09__ God said, "I will give you a __son__  from your own body."
* __Open Bible Stories - 05:05__ About a year later, when Abraham was 100 years old and Sarah was 90, Sarah gave birth to Abraham's __son__.
* __Open Bible Stories - 05:08__ When they reached the place of sacrifice, Abraham tied up his __son__  Isaac and laid him on an altar. He was about to kill his __son__  when God said, "Stop! Do not hurt the boy! Now I know that you fear me because you did not keep your only __son__  from me."
* __Open Bible Stories - 09:07__ When she saw the baby, she took him as her own __son__.
* __Open Bible Stories - 11:06__ God killed every one of the Egyptians' firstborn __sons__.
* __Open Bible Stories - 18:01__ After many years, David died, and his __son__  Solomon began to rule.
* __Open Bible Stories - 26:04__ "Is this the __son__  of Joseph?â€š" they said.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godthefather')">God the Father</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/son')">son</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonsofgod')">sons of God</a>)
* 1 John 04:9-10
* Acts 09:20-22
* Colossians 01:15-17
* Galatians 02:20-21
* Hebrews 04:14-16
* John 03:16-18
* Luke 10:22
* Matthew 11:25-27
* Revelation 02:18-19
* Romans 08:28-30
* __Open Bible Stories - 22:05__ The angel explained, "The Holy Spirit will come to you, and the power of God will overshadow you. So the baby will be holy, the __Son of God__."
* __Open Bible Stories - 24:09__ God had told John, "The Holy Spirit will come down and rest on someone you baptize. That person is __the Son of God__."
* __Open Bible Stories - 31:08__ The disciples were amazed. They worshiped Jesus, saying to him, "Truly, you are __the Son of God__."
* __Open Bible Stories - 37:05__ Martha answered, "Yes, Master! I believe you are the Messiah, the __Son of God__."
* __Open Bible Stories - 42:10__ So go, make disciples of all people groups by baptizing them in the name of the Father, __the Son__, and the Holy Spirit, and by teaching them to obey everything I have commanded you."
* __Open Bible Stories - 46:06__ Right away, Saul began preaching to the Jews in Damascus, saying, "Jesus is the __Son of God__!"
* __Open Bible Stories - 49:09__ But God loved everyone in the world so much that he gave his only __Son__  so that whoever believes in Jesus will not be punished for his sins, but will live with God forever.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/son')">son</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* Acts 07:54-56
* Daniel 07:13-14
* Ezekiel 43:6-8
* John 03:12-13
* Luke 06:3-5
* Mark 02:10-12
* Matthew 13:36-39
* Psalms 080:17-18
* Revelation 14:14-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/son')">son</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* Genesis 06:1-3
* Genesis 06:4
* Job 01:6-8
* Romans 08:14-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 2 Peter 02:7-9
* Acts 02:27-28
* Acts 02:40-42
* Genesis 49:5-6
* Isaiah 53:10-11
* James 01:19-21
* Jeremiah 06:16-19
* Jonah 02:7-8
* Luke 01:46-47
* Matthew 22:37-38
* Psalms 019:7-8
* Revelation 20:4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/soul')">soul</a>)
* 1 Corinthians 05:3-5
* 1 John 04:1-3
* 1 Thessalonians 05:23-24
* Acts 05:9-11
* Colossians 01:9-10
* Ephesians 04:23-24
* Genesis 07:21-22
* Isaiah 04:3-4
* Mark 01:23-26
* Matthew 26:39-41
* Philippians 01:25-27
* __Open Bible Stories - 13:03__ Three days later, after the people had prepared themselves __spiritually__, God came down on top of Mount Sinai with thunder, lightning, smoke, and a loud trumpet blast.
* __Open Bible Stories - 40:07__ Then Jesus cried out, "It is finished! Father, I give my __spirit__  into your hands." Then he bowed his head and gave up his __spirit__.
* __Open Bible Stories - 45:05__ As Stephen was dying, he cried out, "Jesus, receive my __spirit__."
* __Open Bible Stories - 48:07__ All the people groups are blessed through him, because everyone who believes in Jesus is saved from sin, and becomes a __spiritual__  descendant of Abraham.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/commit')">commit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/criminal')">crime</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lystra')">Lystra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/testimony')">testimony</a>)
* Acts 07:57-58
* Acts 07:59-60
* Acts 14:5-7
* Acts 14:19-20
* John 08:4-6
* Luke 13:34-35
* Luke 20:5-6
* Matthew 23:37-39
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/heal')">heal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pray')">pray</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* Acts 06:8-9
* Acts 14:1-2
* Acts 15:19-21
* Acts 24:10-13
* John 06:57-59
* Luke 04:14-15
* Matthew 06:1-2
* Matthew 09:35-36
* Matthew 13:54-56
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/altarofincense')">altar of incense</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tentofmeeting')">tent of meeting</a>)
* 1 Chronicles 21:28-30
* 2 Chronicles 01:2-5
* Acts 07:43
* Acts 07:44-46
* Exodus 38:21-23
* Joshua 22:19-20
* Leviticus 10:16-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/courtyard')">courtyard</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/zion')">Zion</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/house')">house</a>)
* Acts 03:1-3
* Acts 03:7-8
* Ezekiel 45:18-20
* Luke 19:45-46
* Nehemiah 10:28-29
* Psalm 079:1-3
* __Open Bible Stories - 17:06__ David wanted to build a __temple__  where all the Israelites could worship God and offer him sacrifices.
* __Open Bible Stories - 18:02__ In Jerusalem, Solomon built the __Temple__  for which his father David had planned and gathered materials. Instead of at the Tent of Meeting, people now worshiped God and offered sacrifices to him at the __Temple__. God came and was present in the __Temple__, and he lived there with his people.
* __Open Bible Stories - 20:07__ They (Babylonians) captured the city of Jerusalem, destroyed the __Temple__, and took away all the treasures.
* __Open Bible Stories - 20:13__ When the people arrived in Jerusalem, they rebuilt the __Temple__  and the wall around the city of the city and the __Temple__.
* __Open Bible Stories - 25:04__ Then Satan took Jesus to the highest point on the __Temple__  and said, "If you are the Son of God, throw yourself down, for it is written, 'God will command his angels to carry you so your foot does not hit a stone.'"
* __Open Bible Stories - 40:07__ When he died, there was an earthquake and the large curtain that separated the people from the presence of God in the __Temple__  was torn in two, from the top to the bottom.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/test')">test</a>) 
* 1 Thessalonians 03:4-5
* Hebrews 04:14-16
* James 01:12-13
* Luke 04:1-2
* Luke 11:3-4
* Matthew 26:39-41
* __Open Bible Stories - 25:01__ Then Satan came to Jesus and __tempted__  him to sin.
* __Open Bible Stories - 25:08__ Jesus did not give in to Satan's __temptations__, so Satan left him.
* __Open Bible Stories - 38:11__ Jesus told his disciples to pray that they would not enter into __temptation__.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tempt')">tempt</a>)
* 1 John 04:1-3
* 1 Thessalonians 05:19-22
* Acts 15:10-11
* Genesis 22:1-3
* Isaiah 07:13-15
* James 01:12-13
* Lamentations 03:40-43
* Malachi 03:10-12
* Philippians 01:9-11
* Psalm 026:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/guilt')">guilt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/testimony')">testimony</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* Deuteronomy 31:27-29
* Micah 06:3-5
* Matthew 26:59-61
* Mark 01:43-44
* John 01:6-8
* John 03:31-33
* Acts 04:32-33
* Acts 07:44-46
* Acts 13:30-31
* Romans 01:8-10
* 1 Thessalonians 02:10-12
* 1 Timothy 05:19-20
* 2 Timothy 01:8-11
* 2 Peter 01:16-18
* 1 John 05:6-8
* 3 John 01:11-12
* Revelation 12:11-12
* __Open Bible Stories - 39:02__ Inside the house, the Jewish leaders put Jesus on trial. They brought many __false witnesses__  who lied about him.
* __Open Bible Stories - 39:04__ The high priest tore his clothes in anger and shouted, "We do not need any more __witnesses__. You have heard him say that he is the Son of God. What is your judgment?"
* __Open Bible Stories - 42:08__ "It was also written in the scriptures that my disciples will proclaim that everyone should repent in order to receive forgiveness for their sins. They will do this starting in Jerusalem, and then go to all people groups everywhere. You are __witnesses__  of these things."
* __Open Bible Stories - 43:07__ "We are __witnesses__  to the fact that God raised Jesus to life again."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/governor')">governor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/herodantipas')">Herod Antipas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/province')">province</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>)
* Luke 03:1-2
* Luke 09:7-9
* Matthew 14:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>)
* 1 Corinthians 15:5-7
* Acts 06:2-4
* Luke 09:1-2
* Luke 18:31-33
* Mark 10:32-34
* Matthew 10:5-7
(See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-parallelism')">parallelism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/trespass')">trespass</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/iniquity')">iniquity</a>)
* 1 Thessalonians 04:3-6
* Daniel 09:24-25
* Galatians 03:19-20
* Galatians 06:1-2
* Numbers 14:17-19
* Psalm 032:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/iniquity')">iniquity</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/transgression')">transgress</a>)
* 1 Samuel 25:27-28
* 2 Chronicles 26:16-18
* Colossians 02:13-15
* Ephesians 02:1-3
* Ezekiel 15:7-8
* Romans 05:16-17
* Romans 05:20-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fulfill')">fulfill</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/understand')">understand</a>)
* 1 Corinthians 05:6-8
* 1 John 01:5-7
* 1 John 02:7-8
* 3 John 01:5-8
* Acts 26:24-26
* Colossians 01:4-6
* Genesis 47:29-31
* James 01:17-18
* James 03:13-14
* James 05:19-20
* Jeremiah 04:1-3
* John 01:9
* John 01:16-18
* John 01:49-51
* John 03:31-33
* Joshua 07:19-21
* Lamentations 05:19-22
* Matthew 08:8-10
* Matthew 12:15-17
* Psalm 026:1-3
* Revelation 01:19-20
* Revelation 15:3-4
* __Open Bible Stories - 02:04__ The snake responded to the woman, "That is not __true__! You will not die."
* __Open Bible Stories - 14:06__ Immediately Caleb and Joshua, the other two spies, said, "It is __true __ that the people of Canaan are tall and strong, but we can certainly defeat them!"
* __Open Bible Stories - 16:01__ The Israelites began to worship the Canaanite gods instead of Yahweh, the __true __ God.
* __Open Bible Stories - 31:08__ They worshiped Jesus, saying to him, "__Truly__, you are the Son of God." 
* __Open Bible Stories - 39:10__ "I have come to earth to tell the __truth__ about God. Everyone who loves the __truth__ listens to me." Pilate said, "What is __truth__?"
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/confidence')">confidence</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* 1 Chronicles 09:22-24
* 1 Timothy 04:9-10
* Hosea 10:12-13
* Isaiah 31:1-2
* Nehemiah 13:12-14
* Psalm 031:5-7
* Titus 03:8
* __Open Bible Stories - 12:12__ When the Israelites saw that the Egyptians were dead, they __trusted__  in God and believed that Moses was a prophet of God.
* __Open Bible Stories - 14:15__ Joshua was a good leader because he __trusted__  and obeyed God.
* __Open Bible Stories - 17:02__ David was a humble and righteous man who __trusted__  and obeyed God.
* __Open Bible Stories - 34:06__ Then Jesus told a story about people who __trusted__  in their own good deeds and despised other people.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bread')">bread</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/feast')">feast</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/passover')">Passover</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/yeast')">yeast</a>)
* 1 Corinthians 05:6-8
* 2 Chronicles 30:13-15
* Acts 12:3-4
* Exodus 23:14-15
* Ezra 06:21-22
* Genesis 19:1-3
* Judges 06:21
* Leviticus 08:1-3
* Luke 22:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promise')">promise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/oath')">oath</a>)
* 1 Corinthians 07:27-28
* Acts 21:22-24
* Genesis 28:20-22
* Genesis 31:12-13
* Jonah 01:14-16
* Jonah 02:9-10
* Proverbs 07:13-15
* 1 John 02:15-17
* 1 Thessalonians 04:3-6
* Colossians 04:12-14
* Ephesians 01:1-2
* John 05:30-32
* Mark 03:33-35
* Matthew 06:8-10
* Psalms 103:20-22
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fruit')">fruit</a>)
* Acts 06:2-4
* Colossians 03:15-17
* Exodus 31:6-9
* Genesis 03:4-6
* Isaiah 19:11-12
* Jeremiah 18:18-20
* Matthew 07:24-25
* __Open Bible Stories - 02:05__ She also wanted to be __wise__, so she picked some of the fruit and ate it.
* __Open Bible Stories - 18:01__ When Solomon asked for __wisdom__, God was pleased and made him the __wisest__  man in the world.
* __Open Bible Stories - 23:09__ Some time later, __wise__  men from countries far to the east saw an unusual star in the sky.
* __Open Bible Stories - 45:01__ He (Stephen) had a good reputation and was full of the Holy Spirit and of __wisdom__.
* Ezekiel 13:17-18
* Habakkuk 02:12-14
* Isaiah 31:1-2
* Jeremiah 45:1-3
* Jude 01:9-11
* Luke 06:24-25
* Luke 17:1-2
* Matthew 23:23-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/word')">word</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* Genesis 15:1-3
* 1 Kings 13:1-3
* Jeremiah 36:1-3
* Luke 08:11-13
* John 05:39-40
* Acts 06:2-4
* Acts 12:24-25
* Romans 01:1-3
* 2 Corinthians 06:4-7
* Ephesians 01:13-14
* 2 Timothy 03:16-17
* James 01:17-18
* James 02:8-9
* __Open Bible Stories - 25:07__ In __God's word__  he commands his people, 'Worship only the Lord your God and only serve him.'"
* __Open Bible Stories - 33:06__ So Jesus explained, "The seed is the __word of God__.
* __Open Bible Stories - 42:03__ Then Jesus explained to them what __God's word__  says about the Messiah.
* __Open Bible Stories - 42:07__ Jesus said, "I told you that everything written about me in __God's word__  must be fulfilled." Then he opened their minds so they could understand __God's word__.
* __Open Bible Stories - 45:10__ Philip also used other __scriptures__  to tell him the good news of Jesus.
* __Open Bible Stories - 48:12__ But Jesus is the greatest prophet of all. He is the __Word of God__.
* __Open Bible Stories - 49:18__ God tells you to pray, to study his __word__, to worship him with other Christians, and to tell others what he has done for you.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/fruit')">fruit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>)
* 1 John 03:11-12
* Acts 02:8-11
* Daniel 04:36-37
* Exodus 34:10-11
* Galatians 02:15-16
* James 02:14-17
* Matthew 16:27-28
* Micah 02:6-8
* Romans 03:27-28
* Titus 03:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/corrupt')">corrupt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godly')">godly</a>)
* 1 John 02:15-17
* 1 John 04:4-6
* 1 John 05:4-5
* John 01:29-31
* Matthew 13:36-39
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/praise')">praise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>)  
* Colossians 02:18-19
* Deuteronomy 29:17-19
* Exodus 03:11-12
* Luke 04:5-7
* Matthew 02:1-3
* Matthew 02:7-8
* __Open Bible Stories - 13:04__  Then God gave them the covenant and said, "I am Yahweh, your God, who saved you from slavery in Egypt. Do not __worship__ other gods."
* __Open Bible Stories - 14:02__  The Canaanites did not __worship__ or obey God. They __worshiped__ false gods and did many evil things.
* __Open Bible Stories - 17:06__  David wanted to build a temple where all the Israelites could __worship__ God and offer him sacrifices.
* __Open Bible Stories - 18:12__  All of the kings and most of the people of the kingdom of Israel __worshiped__ idols.
* __Open Bible Stories - 25:07__  Jesus replied, "Get away from me, Satan! In God's word he commands his people, '__Worship__ only the Lord your God and only serve him.'"
* __Open Bible Stories - 26:02__  On the Sabbath, he (Jesus) went to the place of __worship__.
* __Open Bible Stories - 47:01__  There they met a woman named Lydia who was a merchant. She loved and __worshiped__ God.
* __Open Bible Stories - 49:18__  God tells you to pray, to study his word, to __worship__ him with other Christians, and to tell others what he has done for you.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>)
* 2 Samuel 22:3-4
* 2 Thessalonians 01:11-12
* Acts 13:23-25
* Acts 25:25-27
* Acts 26:30-32
* Colossians 01:9-10
* Jeremiah 08:18-19
* Mark 01:7-8
* Matthew 03:10-12
* Philippians 01:25-27
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* 1 Thessalonians 01:8-10
* 1 Timothy 02:8-10
* Luke 03:7
* Luke 21:23-24
* Matthew 03:7-9
* Revelation 14:9-10
* Romans 01:18-19
* Romans 05:8-9
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">Lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/reveal')">reveal</a>)
* 1 Kings 21:19-20
* 1 Samuel 16:6-7
* Daniel 09:3-4
* Ezekiel 17:24
* Genesis 02:4-6
* Genesis 04:3-5
* Genesis 28:12-13
* Hosea 11:12
* Isaiah 10:3-4
* Isaiah 38:7-8
* Job 12:9-10
* Joshua 01:8-9
* Lamentations 01:4-5
* Leviticus 25:35-38
* Malachi 03:4-5
* Micah 02:3-5
* Micah 06:3-5
* Numbers 08:9-11
* Psalm 124:1-3
* Ruth 01:19-21
* Zechariah 14:5
* __Open Bible Stories - 09:14__ God said, "I AM WHO I AM. Tell them, 'I AM has sent me to you.' Also tell them, 'I am __Yahweh__, the God of your ancestors Abraham, Isaac, and Jacob. This is my name forever.'"
* __Open Bible Stories - 13:04__ Then God gave them the covenant and said, "I am __Yahweh__, your God, who saved you from slavery in Egypt. Do not worship other gods."
* __Open Bible Stories - 13:05__ "Do not make idols or worship them, for I, __Yahweh__, am a jealous God."
* __Open Bible Stories - 16:01__ The Israelites began to worship the Canaanite gods instead of __Yahweh__, the true God.
* __Open Bible Stories - 19:10__ Then Elijah prayed, "O __Yahweh__, God of Abraham, Isaac, and Jacob, show us today that you are the God of Israel and that I am your servant."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">Lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lordyahweh')">Lord Yahweh</a> <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* Zechariah 13:1-2
* 1 Corinthians 12:30-31
* 1 Kings 19:9-10
* Acts 22:3-5
* Galatians 04:17-18
* Isaiah 63:15-16
* John 02:17-19
* Philippians 03:6-7
* Romans 10:1-3
* Mount Zion and Mount Moriah were two of the hills that the city of Jerusalem was located on. Later, "Zion" and "Mount Zion" became used as general terms to refer to both of these mountains and to the city of Jerusalem. Sometimes they also referred to the temple that was located in Jerusalem. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metonymy')">metonymy</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jebusites')">Jebusites</a>)
* 1 Chronicles 11:4-6
* Amos 01:1-2
* Jeremiah 51:34-35
* Psalm 076:1-3
* Romans 11:26-27
* God also appointed Aaron and his descendants to be the <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a> priests for the people of Israel.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>)
* 1 Chronicles 23:12-14
* Acts 07:38-40
* Exodus 28:1-3
* Luke 01:5-7
* Numbers 16:44-46
* __Open Bible Stories - 09:15__ God warned Moses and __Aaron__  that Pharaoh would be stubborn.
* __Open Bible Stories - 10:05__ Pharaoh called Moses and __Aaron__  and told them that if they stopped the plague, the Israelites could leave Egypt.
* __Open Bible Stories - 13:09__ God chose Moses' brother, __Aaron__, and Aaron's descendants to be his priests.
* __Open Bible Stories - 13:11__ So they (the Israelites) brought gold to __Aaron__  and asked him to form it into an idol for them!
* __Open Bible Stories - 14:07__ They (the Israelites) became angry with Moses and __Aaron__  and said, "Oh, why did you bring us to this horrible place?"
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>) 
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/cain')">Cain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>)
* Genesis 04:1-2
* Genesis 04:8-9
* Hebrews 12:22-24
* Luke 11:49-51
* Matthew 23:34-36
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/zadok')">Zadok</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/adonijah')">Adonijah</a>)
* 1 Chronicles 27:32-34
* 1 Kings 01:7-8
* 1 Kings 02:22-23
* 2 Samuel 17:15-16
* Mark 02:25-26
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
* 1 Kings 15:1-3
* 1 Samuel 08:1-3
* 2 Chronicles 13:1-3
* 2 Chronicles 13:19-22
* Luke 01:5-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/beersheba')">Beersheba</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gerar')">Gerar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gideon')">Gideon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jotham')">Jotham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* 2 Samuel 11:21
* Genesis 20:1-3
* Genesis 20:4-5
* Genesis 21:22-24
* Genesis 26:9-11
* Judges 09:52-54
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
* 1 Chronicles 26:26-28
* 1 Kings 02:5-6
* 1 Kings 02:32-33
* 1 Samuel 17:55-56
* 2 Samuel 03:22-23
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/chaldeans')">Chaldea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sarah')">Sarah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaac')">Isaac</a>)
* Galatians 03:6-9
* Genesis 11:29-30
* Genesis 21:1-4
* Genesis 22:1-3
* James 02:21-24
* Matthew 01:1-3
* __Open Bible Stories - 04:06__ When __Abram__  arrived in Canaan, God said, "Look all around you. I will give to you and your descendants all the land that you can see as an inheritance."
* __Open Bible Stories - 05:04__ Then God changed __Abram__'s name to __Abraham__, which means "father of many."
* __Open Bible Stories - 05:05__ About a year later, when __Abraham__  was 100 years old and Sarah was 90, Sarah gave birth to Abraham's son.
* __Open Bible Stories - 05:06__ When Isaac was a young man, God tested __Abraham's__  faith by saying, "Take Isaac, your only son, and kill him as a sacrifice to me."
* __Open Bible Stories - 06:01__ When __Abraham__  was very old and his son, Isaac, had grown to be a man, __Abraham__  sent one of his servants back to the land where his relatives lived to find a wife for his son, Isaac.
* __Open Bible Stories - 06:04__ After a long time, __Abraham__  died and all of the promises that God had made to him in the covenant were passed on to Isaac.
* __Open Bible Stories - 21:02__ God promised __Abraham__  that through him all people groups of the world would receive a blessing.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/geshur')">Geshur</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/amnon')">Amnon</a>)
* 1 Chronicles 03:1-3
* 1 Kings 01:5-6
* 2 Samuel 15:1-2
* 2 Samuel 17:1-4
* 2 Samuel 18:18
* Psalm 003:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/eve')">Eve</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/imageofgod')">image of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>)
* 1 Timothy 02:13-15
* Genesis 03:17-19
* Genesis 05:1-2
* Genesis 11:5-7
* Luke 03:36-38
* Romans 05:14-15
* __Open Bible Stories - 01:09__ Then God said, "Let us make human beings in our image to be like us."
* __Open Bible Stories - 01:10__ This man's name was __Adam__. God planted a garden where __Adam__  could live, and put him there to care for it.
* __Open Bible Stories - 01:12__ Then God said, "It is not good for man to be alone." But none of the animals could be __Adam's__  helper.
* __Open Bible Stories - 02:11__ And God clothed __Adam__  and Eve with animal skins.
* __Open Bible Stories - 02:12__ So God sent __Adam__  and Eve away from the beautiful garden.
* __Open Bible Stories - 49:08__ When __Adam__  and Eve sinned, it affected all of their descendants.
* __Open Bible Stories - 50:16__ Because __Adam__  and Eve disobeyed God and brought sin into this world, God cursed it and decided to destroy it.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>) 
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jezebel')">Jezebel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Kings 18:1-2
* 1 Kings 20:1-3
* 2 Chronicles 21:6-7
* 2 Kings 09:7-8
* __Open Bible Stories - 19:02__ Elijah was a prophet when __Ahab__  was king over the kingdom of Israel. __Ahab__  was an evil man who encouraged people to worship a false god named Baal.
* __Open Bible Stories - 19:03__ __Ahab__  and his army looked for Elijah, but they could not find him.
* __Open Bible Stories - 19:05__ After three and a half years, God told Elijah to return to the kingdom of Israel and speak with __Ahab__  because he was going to send rain again.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esther')">Esther</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ethiopia')">Ethiopia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/exile')">exile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>)
* Daniel 09:1-2
* Esther 10:1-2
* Ezra 04:7-8
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>)
* 1 Chronicles 08:35-37
* 2 Chronicles 28:1-2
* 2 Kings 16:19-20
* Hosea 01:1-2
* Isaiah 01:1
* Isaiah 07:3-4
* Matthew 01:9-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehu')">Jehu</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeroboam')">Jeroboam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joash')">Joash</a>)
* 1 Kings 22:39-40
* 2 Chronicles 22:1-3
* 2 Chronicles 25:23-24
* 2 Kings 11:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/baasha')">Baasha</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shiloh')">Shiloh</a>)
* 1 Kings 15:27-28
* 1 Kings 21:21-22
* 1 Samuel 14:18-19
* 2 Chronicles 10:15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethel')">Bethel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jericho')">Jericho</a>)
* Ezra 02:27-30
* Genesis 12:8-9
* Genesis 13:3-4
* Joshua 07:2-3
* Joshua 08:10-12
* Sometimes the term "Amalek" is used figuratively to refer to all the Amalekites. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/arabia')">Arabia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/negev')">Negev</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>)
* 1 Chronicles 04:42-43
* 2 Samuel 01:8-10
* Exodus 17:8-10
* Numbers 14:23-25
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/joash')">Joash</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/edom')">Edom</a>)
* 1 Chronicles 03:10-12
* 1 Chronicles 04:34-38
* 2 Chronicles 25:9-10
* 2 Kings 14:8-10
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/curse')">curse</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lot')">Lot</a>)
* 1 Chronicles 19:1-3
* Ezekiel 25:1-2
* Genesis 19:36-38
* Joshua 12:1-2
* Judges 11:26-28
* Zephaniah 02:8-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/absalom')">Absalom</a>)
* 1 Chronicles 03:1-3
* 2 Samuel 13:1-2
* 2 Samuel 13:7-9
* Amos 02:9-10
* Ezekiel 16:1-3
* Genesis 10:15-18
* Genesis 15:14-16
* Joshua 09:9-10
* __Open Bible Stories - 15:07__ Sometime later, the kings of another people group in Canaan, the __Amorites__, heard that the Gibeonites had made a peace treaty with the Israelites, so they combined their armies into one large army and attacked Gibeon. 
* __Open Bible Stories - 15:08__ In the early morning they surprised the __Amorite__ armies and attacked them. 
* __Open Bible Stories - 15:09__ God fought for Israel that day. He caused the __Amorites__ to be confused and he sent large hailstones that killed many of the __Amorites__.
* __Open Bible Stories - 15:10__ God also caused the sun to stay in one place in the sky so that Israel would have enough time to completely defeat the __Amorites__.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/fig')">fig</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/uzziah')">Uzziah</a>)
* Amos 01:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/amos')">Amos</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaiah')">Isaiah</a>)
* 2 Kings 19:1-2
* Isaiah 37:1-2
* Isaiah 37:21-23
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* Acts 01:12-14
* John 01:40-42
* Mark 01:16-18
* Mark 01:29-31
* Mark 03:17-19
* Matthew 04:18-20
* Matthew 10:2-4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* Acts 04:5-7
* John 18:22-24
* Luke 03:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also:<a style="cursor: pointer" onclick="return followLink('en/tw/names/barnabas')">Barnabas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/colossae')">Colossae</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnmark')">John Mark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/province')">province</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)   
* 2 Timothy 03:10-13
* Acts 06:5-6
* Acts 11:19-21
* Acts 11:25-26
* Galatians 02:11-12
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aquila')">Aquila</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephesus')">Ephesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/priscilla')">Priscilla</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>)
* 1 Corinthians 01:12-13
* 1 Corinthians 16:10-12
* Acts 18:24-26
* Titus 03:12-13
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/apollos')">Apollos</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/corinth')">Corinth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* 1 Corinthians 16:19-20
* 2 Timothy 04:19-22
* Acts 18:1-3
* Acts 18:24-26
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/redsea')">Sea of Reeds</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>)
* 1 Samuel 23:24-25
* 2 Kings 25:4-5
* 2 Samuel 02:28-29
* Jeremiah 02:4-6
* Job 24:5-7
* Zechariah 14:9-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/galatia')">Galatia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ishmael')">Ishmael</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shem')">Shem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sinai')">Sinai</a>)
* 1 Kings 10:14-15
* Acts 02:8-11
* Galatians 01:15-17
* Galatians 04:24-25
* Jeremiah 25:24-26
* Nehemiah 02:19-20
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/mesopotamia')">Mesopotamia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paddanaram')">Paddan Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rebekah')">Rebekah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shem')">Shem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)
* 1 Chronicles 01:17-19
* 2 Samuel 08:5-6
* Amos 01:5
* Ezekiel 27:16-18
* Genesis 31:19-21
* Hosea 12:11-12
* Psalm 060:1
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>)
* 2 Kings 19:35-37
* Genesis 08:4-5
* Isaiah 37:38
* Jeremiah 51:27-28
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahasuerus')">Ahasuerus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cupbearer')">cupbearer</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>)
* Ezra 04:7-8
* Ezra 07:1-5
* Nehemiah 02:1-2
* Nehemiah 13:6-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
* 1 Chronicles 09:14-16
* 1 Kings 15:7-8
* 2 Chronicles 14:1-4
* Jeremiah 41:8-9
* Matthew 01:7-8
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/harp')">harp</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/lute')">lute</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/psalm')">psalm</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/trumpet')">trumpet</a>)
* 1 Chronicles 06:39-43
* 2 Chronicles 35:15
* Nehemiah 02:7-8
* Psalm 050:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ekron')">Ekron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gath')">Gath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gaza')">Gaza</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joppa')">Joppa</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philip')">Philip</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* 1 Samuel 05:1-3
* Acts 08:39-40
* Amos 01:8
* Joshua 15:45-47
* Zechariah 09:5-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 02:1-2
* 1 Kings 04:15-17
* Ezekiel 48:1-3
* Genesis 30:12-13
* Luke 02:36-38
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gideon')">Gideon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/image')">image</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 2 Kings 18:4-5
* 2 Kings 21:1-3
* Isaiah 27:9
* Judges 03:7-8
* Micah 05:12-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ashdod')">Ashdod</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ekron')">Ekron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gath')">Gath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gaza')">Gaza</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">Mediterranean</a>)
* 1 Samuel 06:17-18
* Amos 01:8
* Jeremiah 25:19-21
* Joshua 13:2-3
* Judges 01:18-19
* Zechariah 09:5-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephesus')">Ephesus</a>)
* 1 Corinthians 16:19-20
* 1 Peter 01:1-2
* 2 Timothy 01:15-18
* Acts 06:8-9
* Acts 16:6-8
* Acts 27:1-2
* Revelation 01:4-6
* Romans 16:3-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>)
* Genesis 10:11-14
* Genesis 25:17-18
* Isaiah 07:16-17
* Jeremiah 50:17-18
* Micah 07:11-13
* __Open Bible Stories - 20:02__ So God punished both kingdoms by allowing their enemies to destroy them. The kingdom of Israel was destroyed by the __Assyrian Empire__, a powerful, cruel nation. The __Assyrians__ killed many people in the kingdom of Israel, took away everything of value, and burned much of the country.
* __Open Bible Stories - 20:03__ The __Assyrians__ gathered all the leaders, the rich people, and the people with skills and took them to __Assyria__.
* __Open Bible Stories - 20:04__ Then the __Assyrians__ brought foreigners to live in the land where the kingdom of Israel had been.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaziah')">Ahaziah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoram')">Jehoram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joash')">Joash</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/omri')">Omri</a>)
* 2 Chronicles 22:1-3
* 2 Chronicles 24:6-7
* 2 Kings 11:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hananiah')">Hananiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mishael')">Mishael</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/uzziah')">Uzziah</a>)
* 1 Chronicles 02:36-38
* 1 Kings 04:1-4
* 2 Chronicles 15:1-2
* Daniel 01:6-7
* Jeremiah 43:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>) 
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/asherim')">Asherah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prostitute')">prostitute</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Kings 16:31-33
* 1 Samuel 07:3-4
* Jeremiah 02:7-8
* Judges 02:11-13
* Numbers 22:41
* __Open Bible Stories - 19:02__ Ahab was an evil man who encouraged people to worship a false god named __Baal__.
* __Open Bible Stories - 19:06__ All the people of the entire kingdom of Israel, including the 450 prophets of __Baal__, came to Mount Carmel. Elijah said to the people, "How long will you keep changing your mind? If Yahweh is God, serve him! If __Baal__  is God, serve him!"
* __Open Bible Stories - 19:07__ Then Elijah said to the prophets of __Baal__, "Kill a bull and prepare it as a sacrifice, but do not light the fire.
* __Open Bible Stories - 19:08__ Then the prophets of __Baal__  prayed to __Baal__, "Hear us, O __Baal__!"
* __Open Bible Stories - 19:12__ So the people captured the prophets of __Baal__. Then Elijah took them away from there and killed them.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asa')">Asa</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>)
* 1 Kings 15:16-17
* 2 Kings 09:9-10
* Jeremiah 41:8-9
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ham')">Ham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mesopotamia')">Mesopotamia</a>)
* Genesis 10:8-10
* Genesis 11:8-9
* Part of this region was called "Chaldea" and the people living there were the "Chaldeans." As a result, the term "Chaldea" was often used to refer to Babylonia. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
* The phrase "Babylon the Great" or "great city of Babylon" refers metaphorically to a city or nation that was large, wealthy, and sinful, just as the ancient city of Babylon was. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babel')">Babel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/chaldeans')">Chaldea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>)
* 1 Chronicles 09:1-3
* 2 Kings 17:24-26
* Acts 07:43
* Daniel 01:1-2
* Ezekiel 12:11-13
* Matthew 01:9-11
* Matthew 01:15-17
* __Open Bible Stories - 20:06__ About 100 years after the Assyrians destroyed the kingdom of Israel, God sent Nebuchadnezzar, king of the __Babylonians__, to attack the kingdom of Judah. __Babylon__  was a powerful empire.
* __Open Bible Stories - 20:07__ But after a few years, the king of Judah rebelled against __Babylon__. So, the __Babylonians__  came back and attacked the kingdom of Judah. They captured the city of Jerusalem, destroyed the Temple, and took away all the treasures of the city and the Temple.
* __Open Bible Stories - 20:09__ Nebuchadnezzar and his army took almost all of the people of the kingdom of Judah to __Babylon__, leaving only the poorest people behind to plant the fields.
* __Open Bible Stories - 20:11__ About seventy years later, Cyrus, the king of the Persians, defeated __Babylon__.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bless')">bless</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/curse')">curse</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/donkey')">donkey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/euphrates')">Euphrates River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/midian')">Midian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moab')">Moab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/peor')">Peor</a>)
* 2 Peter 02:15-16
* Deuteronomy 23:3-4
* Joshua 13:22-23
* Numbers 22:5-6
* Revelation 02:14-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/pilate')">Pilate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* John 18:38-40
* Luke 23:18-19
* Mark 15:6-8
* Matthew 27:15-16
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christian')">Christian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/cyprus')">Cyprus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>)
* Acts 04:36-37
* Acts 11:25-26
* Acts 13:1-3
* Acts 15:33-35
* Colossians 04:10-11
* Galatians 02:9-10
* Galatians 02:13-14
* __Open Bible Stories - 46:08__ Then a believer named __Barnabas__ took Saul to the apostles and told them how Saul had preached boldly in Damascus. 
* __Open Bible Stories - 46:09__ __Barnabas__ and Saul went there to teach these new believers more about Jesus and to strengthen the church. I
* __Open Bible Stories - 46:10__ One day, while the Christians at Antioch were fasting and praying, the Holy Spirit said to them, "Set apart for me __Barnabas__ and Saul to do the work I have called them to do." So the church in Antioch prayed for __Barnabas__ and Saul and placed their hands on them.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pentecost')">Pentecost</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* Acts 01:12-14
* Luke 06:14-16
* Mark 03:17-19
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* Jeremiah 32:10-12
* Jeremiah 36:4-6
* Jeremiah 43:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/oak')">oak</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seaofgalilee')">Sea of Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)
* 1 Kings 04:11-14
* Amos 04:1-2
* Jeremiah 22:20-21
* Joshua 09:9-10
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>. <a style="cursor: pointer" onclick="return followLink('en/tw/names/uriah')">Uriah</a>)
* 1 Chronicles 03:4-5
* 1 Kings 01:11-12
* 2 Samuel 11:2-3
* Psalm 051:1-2
* __Open Bible Stories - 17:10__ One day, when all of David's soldiers were away from home fighting battles, he got up from an afternoon nap and saw a beautiful woman bathing. Her name was __Bathsheba__.
* __Open Bible Stories - 17:11__ A short time later __Bathsheba__ sent a message to David saying that she was pregnant.
* __Open Bible Stories - 17:12__ __Bathsheba's__ husband, a man named Uriah, was one of David's best soldiers.
* __Open Bible Stories - 17:13__ After Uriah was killed, David married __Bathsheba__.
* __Open Bible Stories - 17:14__ Later,  David and __Bathsheba__ had another son, and they named him Solomon.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ekron')">Ekron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>)
* Luke 11:14-15
* Mark 03:20-22
* Matthew 10:24-25
* Matthew 12:24-25
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abimelech')">Abimelech</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hagar')">Hagar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ishmael')">Ishmael</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/oath')">oath</a>)
* 1 Samuel 03:19-21
* 2 Samuel 17:11-12
* Genesis 21:14-16
* Genesis 21:31-32
* Genesis 46:1-4
* Nehemiah 11:28-30
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asaph')">Asaph</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoiada')">Jehoiada</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 1 Chronicles 04:34-38
* 1 Kings 01:7-8
* 2 Samuel 23:20-21
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josephot')">Joseph (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rachel')">Rachel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 02:1-2
* 1 Kings 02:8-9
* Acts 13:21-22
* Genesis 35:16-20
* Genesis 42:1-4
* Genesis 42:35-36
* Philippians 03:4-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/macedonia')">Macedonia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/silas')">Silas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/thessalonica')">Thessalonica</a>)
* Acts 17:10-12
* Acts 17:13-15
* Acts 20:4-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jericho')">Jericho</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lazarus')">Lazarus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/martha')">Martha</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/marysisterofmartha')">Mary (sister of Martha)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mountofolives')">Mount of Olives</a>)
* John 01:26-28
* Luke 24:50-51
* Mark 11:1-3
* Matthew 21:15-17
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>)
* Genesis 12:8-9
* Genesis 35:1-3
* Hosea 10:14-15
* Judges 01:22-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/caleb')">Caleb</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/micah')">Micah</a>)
* Genesis 35:16-20
* John 07:40-42
* Matthew 02:4-6
* Matthew 02:16
* Ruth 01:1-2
* Ruth 01:19-21
* __Open Bible Stories - 17:02__ David was a shepherd from the town of __Bethlehem__.
* __Open Bible Stories - 21:09__ The prophet Isaiah prophesied that the Messiah would be born from a virgin. The prophet Micah said that he would be born in the town of __Bethlehem__.
* __Open Bible Stories - 23:04__ Joseph and Mary had to make a long journey from where they lived in Nazareth to __Bethlehem__ because their ancestor was David whose hometown was __Bethlehem__.
* __Open Bible Stories - 23:06__ "The Messiah, the Master, has been born in __Bethlehem__!"
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joshua')">Joshua</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* 1 Kings 04:7-10
* 1 Samuel 06:7-9
* Joshua 19:20-22
* Judges 01:33
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/beersheba')">Beersheba</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/laban')">Laban</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nahor')">Nahor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rebekah')">Rebekah</a>)
* 1 Chronicles 04:29-31
* Genesis 28:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/moab')">Moab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/redeem')">redeem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ruth')">Ruth</a>)
* 1 Chronicles 02:9-12
* 2 Chronicles 03:15-17
* Luke 03:30-32
* Matthew 01:4-6
* Ruth 02:3-4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Acts 25:6-8
* Luke 02:1-3
* Luke 20:23-24
* Luke 23:1-2
* Mark 12:13-15
* Matthew 22:15-17
* Philippians 04:21-23
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/caesar')">Caesar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gentile')">Gentile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/carmel')">Carmel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mounthermon')">Mount Hermon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/tarsus')">Tarsus</a>)
* Acts 09:28-30
* Acts 10:1-2
* Acts 25:1-3
* Acts 25:13-16
* Mark 08:27-28
* Matthew 16:13-16
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/annas')">Annas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>)
* Acts 04:5-7
* John 18:12-14
* Luke 03:1-2
* Matthew 26:3-5
* Matthew 26:57-58
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/adam')">Adam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* 1 John 03:11-12
* Genesis 04:1-2
* Genesis 04:8-9
* Genesis 04:13-15
* Hebrews 11:4
* Jude 01:9-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/hebron')">Hebron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joshua')">Joshua</a>)
* 1 Chronicles 04:13-16
* Joshua 14:6-7
* Judges 01:11-13
* Numbers 32:10-12
* __Open Bible Stories - 14:04__ When the Israelites reached the edge of Canaan, Moses chose twelve men, one from each tribe of Israel. He gave the men instructions to go and spy on the land to see what it was like. 
* __Open Bible Stories - 14:06__ Immediately __Caleb__ and Joshua, the other two spies, said, "It is true that the people of Canaan are tall and strong, but we can certainly defeat them! God will fight for us!"
* __Open Bible Stories - 14:08__ "Except for Joshua and __Caleb__, everyone who is twenty years old or older will die there and never enter the Promised Land."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/capernaum')">Capernaum</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/galilee')">Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* John 02:1-2
* John 04:46-47
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ham')">Ham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promisedland')">Promised Land</a>)
* Acts 13:19-20
* Exodus 03:7-8
* Genesis 09:18-19
* Genesis 10:19-20
* Genesis 13:5-7
* Genesis 47:1-2
* __Open Bible Stories - 04:05__ He (Abram) took his wife, Sarai, together with all his servants and everything he owned and went to the land God showed him, the land of __Canaan__.
* __Open Bible Stories - 04:06__ When Abram arrived in __Canaan__  God said, "Look all around you. I will give to you and your descendants all the land that you can see as an inheritance."
* __Open Bible Stories - 04:09__ "I give the land of __Canaan__  to your descendants."
* __Open Bible Stories - 05:03__ "I will give you and your descendants the land of __Canaan__  as their possession and I will be their God forever."
* __Open Bible Stories - 07:08__ After twenty years away from his home in __Canaan__, Jacob returned there with his family, his servants, and all his herds of animals.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/galilee')">Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seaofgalilee')">Sea of Galilee</a>)
* John 02:12
* Luke 04:31-32
* Luke 07:1
* Mark 01:21-22
* Mark 02:1-2
* Matthew 04:12-13
* Matthew 17:24-25
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>)
* 1 Kings 18:18-19
* 1 Samuel 15:12-13
* Jeremiah 46:18-19
* Micah 07:14-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shinar')">Shinar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ur')">Ur</a>)
* Acts 07:4-5
* Ezekiel 01:1-3
* Genesis 11:27-28
* Genesis 11:31-32
* Genesis 15:6-8
* Isaiah 13:19-20
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/absalom')">Absalom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/benaiah')">Benaiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* Zephaniah 02:4-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/stephen')">Stephen</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/tarsus')">Tarsus</a>)
* Acts 06:8-9
* Acts 15:39-41
* Acts 27:3-6
* Galatians 01:21-24
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>)
* 1 Kings 08:1-2
* 2 Samuel 05:6-7
* Isaiah 22:8-9
* Luke 02:4-5
* Nehemiah 03:14-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephesus')">Ephesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>)
* Colossians 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/apollos')">Apollos</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/timothy')">Timothy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/titus')">Titus</a>)
* 1 Corinthians 01:1-3
* 2 Corinthians 01:23-24
* 2 Timothy 04:19-22
* Acts 18:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gentile')">Gentile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/greek')">Greek</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/centurion')">centurion</a>)
* Acts 10:1-2
* Acts 10:7-8
* Acts 10:17-18
* Acts 10:22-23
* Acts 10:24
* Acts 10:25-26
* Acts 10:30-33
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
* Acts 02:8-11
* Acts 27:7-8
* Amos 09:7-8
* Titus 01:12-13
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/arabia')">Arabia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ethiopia')">Ethiopia</a>)
* 1 Chronicles 01:8-10
* Ezekiel 29:8-10
* Genesis 02:13-14
* Genesis 10:6-7
* Jeremiah 13:22-24
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/barnabas')">Barnabas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnmark')">John Mark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>)
* Acts 04:36-37
* Acts 13:4-5
* Acts 15:39-41
* Acts 27:3-6
* Ezekiel 27:6-7
* Isaiah 23:10-12
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/crete')">Crete</a>)
* Acts 11:19-21
* Matthew 27:32-34
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/darius')">Darius</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>)
* 2 Chronicles 36:22-23
* Daniel 01:19-21
* Ezra 05:12-13
* Isaiah 44:28
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)
* 2 Chronicles 24:23-24
* Acts 09:1-2
* Acts 09:3-4
* Acts 26:12-14
* Galatians 01:15-17
* Genesis 14:15-16
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 12:34-35
* 1 Kings 04:24-25
* Exodus 01:1-5
* Genesis 14:13-14
* Genesis 30:5-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>)
* Daniel 01:6-7
* Daniel 05:29-31
* Daniel 07:27-28
* Ezekiel 14:12-14
* Matthew 24:15-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>)
* Ezra 04:4-6
* Haggai 01:1-2
* Nehemiah 12:22-23
* Zechariah 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/goliath')">Goliath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>)
* 1 Samuel 17:12-13
* 1 Samuel 20:32-34
* 2 Samuel 05:1-2
* 2 Timothy 02:8-10
* Acts 02:25-26
* Acts 13:21-22
* Luke 01:30-33
* Mark 02:25-26
* __Open Bible Stories - 17:02__ God chose a young Israelite named __David__ to be king after Saul. __David__ was a shepherd from the town of Bethlehem. … __David__ was a humble and righteous man who trusted and obeyed God. 
* __Open Bible Stories - 17:03__ __David__ was also a great soldier and leader. When __David__ was still a young man, he fought against a giant named Goliath. 
* __Open Bible Stories - 17:04__ Saul became jealous of the people's love for __David__. Saul tried many times to kill him, so __David__ hid from Saul. 
* __Open Bible Stories - 17:05__ God blessed __David__ and made him successful. __David__ fought many battles and God helped him defeat Israel's enemies.  
* __Open Bible Stories - 17:06__ __David__ wanted to build a temple where all the Israelites could worship God and offer him sacrifices. 
* __Open Bible Stories - 17:09__ __David__ ruled with justice and faithfulness for many years, and God blessed him. However, toward the end of his life he sinned terribly against God. 
* __Open Bible Stories - 17:13__ God was very angry about what __David__ had done, so he sent the prophet Nathan to tell __David__ how evil his sin was. __David__ repented of his sin and God forgave him. For the rest of his life, __David__ followed and obeyed God, even in difficult times.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bribe')">bribe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samson')">Samson</a>)
* Judges 16:4-5
* Judges 16:6-7
* Judges 16:10-12
* Judges 16:18-19
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/adam')">Adam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/euphrates')">Euphrates River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/eve')">Eve</a>)
* Ezekiel 28:11-13
* Genesis 02:7-8
* Genesis 02:9-10
* Genesis 02:15-17
* Genesis 04:16-17
* Joel 02:3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/adversary')">adversary</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/birthright')">birthright</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/obadiah')">Obadiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* Genesis 25:29-30
* Genesis 32:3-5
* Genesis 36:1-3
* Isaiah 11:14-15
* Joshua 11:16-17
* Obadiah 01:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/herodthegreat')">Herod the Great</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josephnt')">Joseph (NT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nileriver')">Nile River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/patriarchs')">patriarchs</a>)
* 1 Samuel 04:7-9
* Acts 07:9-10
* Exodus 03:7-8
* Genesis 41:27-29
* Genesis 41:55-57
* Matthew 02:13-15
* __Open Bible Stories - 08:04__ The slave traders took Joseph to __Egypt__. __Egypt__  was a large, powerful country located along the Nile River.
* __Open Bible Stories - 08:08__ Pharaoh was so impressed with Joseph that he appointed him to be the second most powerful man in all of __Egypt__!
* __Open Bible Stories - 08:11__ So Jacob sent his older sons to __Egypt __  to buy food.
* __Open Bible Stories - 08:14__ Even though Jacob was an old man, he moved to __Egypt__  with all of his family, and they all lived there.
* __Open Bible Stories - 09:01__ After Joseph died, all of his relatives stayed in __Egypt__.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>) 
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaziah')">Ahaziah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ashdod')">Ashdod</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/beelzebul')">Beelzebul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gath')">Gath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* 1 Samuel 05:10
* Joshua 13:2-3
* Judges 01:18-19
* Zechariah 09:5-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shem')">Shem</a>)
* 1 Chronicles 01:17-19
* Acts 02:8-11
* Ezra 08:4-7
* Isaiah 22:5-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aaron')">Aaron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/mighty')">mighty</a>)
* 1 Chronicles 24:1-3
* Judges 20:27-28
* Numbers 26:1-2
* Numbers 34:16-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/hezekiah')">Hezekiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoiakim')">Jehoiakim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josiah')">Josiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/pharaoh')">Pharaoh</a>)
* 2 Kings 18:16-18
* 2 Kings 18:26-27
* 2 Kings 18:36-37
* 2 Kings 23:34-35
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Kings 17:1
* 2 Kings 01:3-4
* James 05:16-18
* John 01:19-21
* John 01:24-25
* Mark 09:4-6
* __Open Bible Stories - 19:02__ __Elijah__ was a prophet when Ahab was king over the kingdom of Israel.
* __Open Bible Stories - 19:02__ __Elijah__ said to Ahab, "There will be no rain or dew in the kingdom of Israel until I say so."
* __Open Bible Stories - 19:03__ God told __Elijah__ to go to a stream in the wilderness to hide from Ahab who wanted to kill him. Every morning and every evening, birds would bring him bread and meat.
* __Open Bible Stories - 19:04__ But they took care of __Elijah__, and God provided for them so that their flour jar and their bottle of oil never became empty.
* __Open Bible Stories - 19:05__ After three and a half years, God told __Elijah__ to return to the kingdom of Israel and speak with Ahab because he was going to send rain again.
* __Open Bible Stories - 19:07__ Then __Elijah__ said to the prophets of Baal, "Kill a bull and prepare it as a sacrifice, but do not light the fire."
* __Open Bible Stories - 19:12__ Then __Elijah__ said, "Do not let any of the prophets of Baal escape!"
* __Open Bible Stories - 36:03__ Then Moses and the prophet __Elijah__ appeared. These men had lived hundreds of years before this. They talked with Jesus about his death that would soon happen in Jerusalem.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/naaman')">Naaman</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* 1 Kings 19:15-16
* 2 Kings 03:15-17
* 2 Kings 05:8-10
* Luke 04:25-27
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahnt')">Zechariah (NT)</a>)
* Luke 01:5-7
* Luke 01:24-25
* Luke 01:39-41
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fountain')">fountain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/rest')">rest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/stronghold')">stronghold</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vineyard')">vineyard</a>)
* 2 Chronicles 20:1-2
* Song of Solomon 01:12-14
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/cain')">Cain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seth')">Seth</a>)
* 1 Chronicles 01:1-4
* Genesis 05:18-20
* Genesis 05:21-24
* Jude 01:14-16
* Luke 03:36-38
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asia')">Asia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/timothy')">Timothy</a>)
* 1 Corinthians 15:31-32
* 1 Timothy 01:3-4
* 2 Timothy 04:11-13
* Acts 19:1-2
* Ephesians 01:1-2
* Sometimes the name Ephraim is used in the Bible to refer to the whole northern kingdom of Israel. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 06:66-69
* 2 Chronicles 13:4-5
* Ezekiel 37:15-17
* Genesis 41:50-52
* Genesis 48:1-2
* John 11:54-55
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/boaz')">Boaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/caleb')">Caleb</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/edom')">Edom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaac')">Isaac</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rebekah')">Rebekah</a>)
* Genesis 25:24-26
* Genesis 25:29-30
* Genesis 26:34-35
* Genesis 27:11-12
* Genesis 32:3-5
* Hebrews 12:14-17
* Romans 09:10-13
* __Open Bible Stories - 06:07__ When Rebekah's babies were born, the older son came out red and hairy, and they named him __Esau__.
* __Open Bible Stories - 07:02__ So __Esau __ gave Jacob his rights as the oldest son.
* __Open Bible Stories - 07:04__ When Isaac felt the goat hair and smelled the clothes, he thought it was __Esau__ and blessed him.
* __Open Bible Stories - 07:05__ __Esau__ hated Jacob because Jacob had stolen his rights as oldest son and also his blessing.
* __Open Bible Stories - 07:10__ But __Esau __ had already forgiven Jacob, and they were happy to see each other again.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahasuerus')">Ahasuerus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mordecai')">Mordecai</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>)
* Esther 02:7
* Esther 02:15-16
* Esther 07:1-2
* Esther 08:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/cush')">Cush</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eunuch')">eunuch</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philip')">Philip</a>)
* Acts 08:26-28
* Acts 08:29-31
* Acts 08:32-33
* Acts 08:36-38
* Isaiah 18:1-2
* Nahum 03:8-9
* Zephaniah 03:9-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
* 1 Chronicles 05:7-9
* 2 Chronicles 09:25-26
* Exodus 23:30-33
* Genesis 02:13-14
* Isaiah 07:20-22
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/adam')">Adam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>)
* 1 Timothy 02:13-15
* 2 Corinthians 11:3-4
* Genesis 03:20-21
* Genesis 04:1-2
* __Open Bible Stories - 01:13__ Then God took one of Adam's ribs and made it into a woman and brought her to him.
* __Open Bible Stories - 02:02__ But there was a crafty snake in the garden. He asked the woman, "Did God really tell you not to eat the fruit from any of the trees in the garden?"
* __Open Bible Stories - 02:11__ The man named his wife __Eve__, which means "life-giver," because she would become the mother of all people.
* __Open Bible Stories - 21:01__ God promised that a descendant of __Eve__  would be born who would crush the snake's head.
* __Open Bible Stories - 48:02__ Satan spoke through the snake in the garden in order to deceive __Eve__. 
* __Open Bible Stories - 49:08__ When Adam and __Eve__ sinned, it affected all of their descendants.
* __Open Bible Stories - 50:16__ Because Adam and __Eve__ disobeyed God and brought sin into this world, God cursed it and decided to destroy it.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/exile')">exile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* Ezekiel 01:1-3
* Ezekiel 24:22-24
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/exile')">exile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* Ezra 07:6-7
* Nehemiah 08:1-3
* Nehemiah 12:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elizabeth')">Elizabeth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mary')">Mary</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahnt')">Zechariah (NT)</a>)
* Daniel 08:15-17
* Daniel 09:20-21
* Luke 01:18-20
* Luke 01:26-29
(Translation suggestions:<a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/census')">census</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 05:18-19
* Exodus 01:1-5
* Genesis 30:9-11
* Joshua 01:12-13
* Joshua 21:36-38
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asia')">Asia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/cilicia')">Cilicia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/works')">works</a>)
* 1 Corinthians 16:1-2
* 1 Peter 01:1-2
* 2 Timothy 04:9-10
* Acts 16:6-8
* Galatians 01:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/nazareth')">Nazareth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seaofgalilee')">Sea of Galilee</a>)
* Acts 09:31-32
* Acts 13:30-31
* John 02:1-2
* John 04:1-3
* Luke 13:1-3
* Mark 03:7-8
* Matthew 02:22-23
* Matthew 03:13-15
* __Open Bible Stories - 21:10__ The prophet Isaiah said the Messiah would live in __Galilee__, comfort broken-hearted people, and proclaim freedom to captives and release to prisoners.
* __Open Bible Stories - 26:01__ After overcoming Satan's temptations, Jesus returned in the power of the Holy Spirit to the region of __Galilee__  where he lived.
* __Open Bible Stories - 39:06__ Finally, the people said, "We know that you were with Jesus because you both are from __Galilee__."
* __Open Bible Stories - 41:06__ Then the angel told the women, "Go and tell the disciples, 'Jesus has risen from the dead and he will go to __Galilee__  ahead of you.'"
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ashdod')">Ashdod</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ashkelon')">Ashkelon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ekron')">Ekron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gaza')">Gaza</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/goliath')">Goliath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* 1 Kings 02:39-40
* 1 Samuel 05:8-9
* 2 Chronicles 26:6-8
* Joshua 11:21-22
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ashdod')">Ashdod</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philip')">Philip</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ethiopia')">Ethiopia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gath')">Gath</a>)
* 1 Kings 04:24-25
* Acts 08:26-28
* Genesis 10:19-20
* Joshua 10:40-41
* Judges 06:3-4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abimelech')">Abimelech</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/beersheba')">Beersheba</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hebron')">Hebron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* 2 Chronicles 14:12-13
* Genesis 20:1-3
* Genesis 26:1
* Genesis 26:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/absalom')">Absalom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/amnon')">Amnon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seaofgalilee')">Sea of Galilee</a>)
* 1 Chronicles 02:23-24
* 2 Samuel 03:2-3
* Deuteronomy 03:14
* Joshua 12:3-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/judasiscariot')">Judas Iscariot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kidronvalley')">Kidron Valley</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mountofolives')">Mount of Olives</a>)
* Mark 14:32-34
* Matthew 26:36-38
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/benjamin')">Benjamin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethel')">Bethel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>)
* 1 Samuel 10:26-27
* 2 Samuel 21:5-6
* Hosea 09:8-9
* Judges 19:12-13
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/gilgal')">Gilgal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jericho')">Jericho</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>)
* 1 Chronicles 08:29-31
* 1 Kings 03:4-5
* 2 Samuel 02:12-13
* Joshua 09:3-5
* __Open Bible Stories - 15:06__ But one of the Canaanite people groups, called the __Gibeonites__, lied to Joshua and said they were from a place far from Canaan.  
* __Open Bible Stories - 15:07__ Sometime later, the kings of another people group in Canaan, the Amorites, heard that the __Gibeonites__ had made a peace treaty with the Israelites, so they combined their armies into one large army and attacked __Gibeon__.  
* __Open Bible Stories - 15:08__ So Joshua gathered the Israelite army and they marched all night to reach the __Gibeonites__.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/asherim')">Asherah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/deliverer')">deliver</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/midian')">Midian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>) 
* Hebrews 11:32-34
* Judges 06:11-12
* Judges 06:22-24
* Judges 08:15-17
* __Open Bible Stories - 16:05__ The angel of Yahweh came to __Gideon__  and said, "God is with you, mighty warrior. Go and save Israel from the Midianites."
* __Open Bible Stories - 16:06__ __Gideon's__  father had an altar dedicated to an idol. God told __Gideon__  to tear down that altar.
* __Open Bible Stories - 16:08__ There were so many of them (Midianites) that they could not be counted. __Gideon__  called the Israelites together to fight them.
* __Open Bible Stories - 16:08__ __Gideon__  called the Israelites together to fight them. __Gideon__  asked God for two signs so he could be sure that God would use him to save Israel.
* __Open Bible Stories - 16:10__ 32,000 Israelite soldiers came to __Gideon__, but God told him this was too many.
* __Open Bible Stories - 16:12__ Then __Gideon__  returned to his soldiers and gave each of them a horn, a clay pot, and a torch.
* __Open Bible Stories - 16:15__ The people wanted to make __Gideon__  their king.
* __Open Bible Stories - 16:16__ Then __Gideon__  used the gold to make a special garment like the high priest used to wear. But the people started worshiping it as if it were an idol.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/gad')">Gad</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jephthah')">Jephthah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/manasseh')">Manasseh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/reuben')">Reuben</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 02:21-22
* 1 Samuel 11:1-2
* Amos 01:3-4
* Deuteronomy 02:36-37
* Genesis 31:19-21
* Genesis 37:25-26
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, , <a style="cursor: pointer" onclick="return followLink('en/tw/names/elisha')">Elisha</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jericho')">Jericho</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>)
* 1 Samuel 07:15-17
* 2 Kings 02:1-2
* Hosea 04:15-16
* Judges 02:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a> , <a style="cursor: pointer" onclick="return followLink('en/tw/names/ham')">Ham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>)
* 1 Chronicles 01:13-16
* Deuteronomy 07:1
* Genesis 10:15-18
* Joshua 03:9-11
* Joshua 24:11-12
(Translation Suggestion: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mountofolives')">Mount of Olives</a>)
* John 19:17-18
* Mark 15:22-24
* Matthew 27:32-34
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* 1 Chronicles 20:4-5
* 1 Samuel 17:4-5
* 1 Samuel 21:8-9
* 1 Samuel 22:9-10
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a> , <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lot')">Lot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sodom')">Sodom</a>)
* 2 Peter 02:4-6
* Genesis 10:19-20
* Genesis 14:1-2
* Genesis 18:20-21
* Isaiah 01:9
* Matthew 10:14-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/famine')">famine</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nileriver')">Nile River</a>)
* Exodus 08:22-24
* Genesis 45:9-11
* Genesis 47:1-2
* Genesis 50:7-9
* Joshua 10:40-41
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/corinth')">Corinth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gentile')">Gentile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/greek')">Greek</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hebrew')">Hebrew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philippi')">Philippi</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/thessalonica')">Thessalonica</a>)
* Daniel 08:20-21
* Daniel 10:20-21
* Daniel 11:1-2
* Zechariah 09:11-13
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gentile')">Gentile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/greece')">Greece</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hebrew')">Hebrew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Acts 06:1
* Acts 09:28-30
* Acts 11:19-21
* Acts 14:1-2
* Colossians 03:9-11
* Galatians 02:3-5
* John 07:35-36
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoiakim')">Jehoiakim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>)
* Habakkuk 01:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ishmael')">Ishmael</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sarah')">Sarah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>)
* Galatians 04:24-25
* Genesis 16:1-4
* Genesis 21:8-9
* Genesis 25:12
* __Open Bible Stories - 05:01__ So Abram's wife, Sarai, said to him, "Since God has not allowed me to have children and now I am too old to have children, here is my servant, __Hagar__. Marry her also so she can have a child for me."
* __Open Bible Stories - 05:02__ __Hagar__ had a baby boy, and Abram named him Ishmael.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/uzziah')">Uzziah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahot')">Zechariah (OT)</a>)
* Ezra 05:1-2
* Ezra 06:13-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/dishonor')">dishonor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>)
* Genesis 05:32
* Genesis 06:9-10
* Genesis 07:13-14
* Genesis 10:1
* Genesis 10:19-20
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zedekiah')">Zedekiah</a>)
* 1 Chronicles 18:3-4
* 2 Samuel 08:9-10
* Amos 06:1-2
* Ezekiel 47:15-17
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hivite')">Hivite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shechem')">Shechem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/succoth')">Succoth</a>)
* Acts 07:14-16
* Genesis 34:1-3
* Genesis 34:20-21
* Joshua 24:32-33
* Judges 09:28-29
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/azariah')">Azariah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/falseprophet')">false prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mishael')">Mishael</a>)
* Daniel 01:6-7
* Daniel 02:17-18
* Jeremiah 28:1-2
* Jeremiah 28:5-7
* Jeremiah 28:15-17
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/conceive')">conceive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samuel')">Samuel</a>)
* 1 Samuel 01:1-2
* 1 Samuel 02:1
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/caleb')">Caleb</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lot')">Lot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/terah')">Terah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ur')">Ur</a>)
* 2 Kings 19:12-13
* Acts 07:1-3
* Genesis 11:31-32
* Genesis 27:43-45
* Genesis 28:10-11
* Genesis 29:4-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/absalom')">Absalom</a>)
* 2 Samuel 02:10-11
* Genesis 13:16-18
* Genesis 23:1-2
* Genesis 35:26-27
* Genesis 37:12-14
* Judges 01:8-10
* Numbers 13:21-22
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/crucify')">crucify</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/herodthegreat')">Herod the Great</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Luke 03:1-2
* Luke 03:18-20
* Luke 09:7-9
* Luke 13:31-33
* Luke 23:8-10
* Mark 06:18-20
* Matthew 14:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/herodantipas')">Herod Antipas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>)
* Luke 03:18-20
* Mark 06:16-17
* Mark 06:21-22
* Matthew 14:3-5
(See <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/herodantipas')">Herod Antipas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judea')">Judea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* Matthew 02:1-3
* Matthew 02:11-12
* Matthew 02:16
* Matthew 02:19-21
* Matthew 02:22-23
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaz')">Ahaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sennacherib')">Sennacherib</a>)
* 1 Chronicles 03:13-14
* 2 Kings 16:19-20
* Hosea 01:1-2
* Matthew 01:9-11
* Proverbs 25:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/eliakim')">Eliakim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hezekiah')">Hezekiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josiah')">Josiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 2 Kings 18:16-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/foreigner')">foreigner</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ham')">Ham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/mighty')">mighty</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/uriah')">Uriah</a>)
* 1 Kings 09:20-21
* Exodus 03:7-8
* Genesis 23:10-11
* Genesis 25:9-11
* Joshua 01:4-5
* Nehemiah 09:7-8
* Numbers 13:27-29
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hamor')">Hamor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shechem')">Shechem</a>)
* 2 Chronicles 08:7-8
* Exodus 03:7-8
* Genesis 34:1-3
* Joshua 09:1-2
* Judges 03:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sinai')">Sinai</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tencommandments')">Ten Commandments</a>)
* 1 Kings 08:9-11
* 2 Chronicles 05:9-10
* Deuteronomy 01:1-2
* Exodus 03:1-3
* Psalms 106:19-21
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaz')">Ahaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hezekiah')">Hezekiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hoshea')">Hoshea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeroboam')">Jeroboam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jotham')">Jotham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/uzziah')">Uzziah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahot')">Zechariah (OT)</a>)
* Hosea 01:1-2
* Hosea 01:3-5
* Hosea 01:6-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaz')">Ahaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephraim')">Ephraim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hezekiah')">Hezekiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joshua')">Joshua</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>)
* 1 Chronicles 27:19-22
* 2 Kings 15:29-31
* 2 Kings 17:1-3
* 2 Kings 18:1-3
* 2 Kings 18:9-10
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/house')">house</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>)
* 2 Chronicles 10:17-19
* 2 Samuel 03:6-7
* Luke 01:69-71
* Psalms 122:4-5
* Zechariah 12:7-9
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/barnabas')">Barnabas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lystra')">Lystra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/stone')">stone</a>)
* 2 Timothy 03:10-13
* Acts 14:1-2
* Acts 14:19-20
* Acts 16:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eternity')">eternity</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fulfill')">fulfill</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sarah')">Sarah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* Galatians 04:28-29
* Genesis 25:9-11
* Genesis 25:19-20
* Genesis 26:1
* Genesis 26:6-8
* Genesis 28:1-2
* Genesis 31:17-18
* Matthew 08:11-13
* Matthew 22:31-33
* __Open Bible Stories - 05:04__ "Your wife, Sarai, will have a son—he will be the son of promise. Name him __Isaac__."
* __Open Bible Stories - 05:06__ When __Isaac__ was a young man, God tested Abraham's faith by saying, "Take __Isaac__, your only son, and kill him as a sacrifice to me."
* __Open Bible Stories - 05:09__ God had provided the ram to be the sacrifice instead of __Isaac__.
* __Open Bible Stories - 06:01__ When Abraham was very old and his son, __Isaac__, had grown to be a man, Abraham sent one of his servants back to the land where his relatives lived to find a wife for his son, __Isaac.__ 
* __Open Bible Stories - 06:05__ __Isaac__ prayed for Rebekah, and God allowed her to get pregnant with twins.
* __Open Bible Stories - 07:10__ Then __Isaac__ died, and Jacob and Esau buried him. The covenant promises God had promised to Abraham and then to __Isaac__ now passed on to Jacob.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaz')">Ahaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hezekiah')">Hezekiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jotham')">Jotham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/uzziah')">Uzziah</a>)
* 2 Kings 20:1-3
* Acts 28:25-26
* Isaiah 01:1
* Luke 03:4
* Mark 01:1-3
* Mark 07:6-7
* Matthew 03:1-3
* Matthew 04:14-16
* __Open Bible Stories - 21:09__ The prophet __Isaiah__ prophesied that the Messiah would be born from a virgin.
* __Open Bible Stories - 21:10__ The prophet __Isaiah__ said the Messiah would live in Galilee, comfort broken-hearted people, and proclaim freedom to captives and release to prisoners. 
* __Open Bible Stories - 21:11__ The prophet __Isaiah__ also prophesied that the Messiah would be hated without reason and rejected.
* __Open Bible Stories - 21:12__ __Isaiah__ prophesied that people would spit on, mock, and beat the Messiah. 
* __Open Bible Stories - 26:02__ They handed him (Jesus) the scroll of the prophet __Isaiah__ so that he would read from it. Jesus opened up the scroll and read part of it to the people.
* __Open Bible Stories - 45:08__ When Philip approached the chariot, he heard the Ethiopian reading from what the prophet __Isaiah__ wrote.
* __Open Bible Stories - 45:10__ Philip explained to the Ethiopian that __Isaiah__ was writing about Jesus.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hagar')">Hagar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaac')">Isaac</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paran')">Paran</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sarah')">Sarah</a>)
* 1 Chronicles 01:28-31
* 2 Chronicles 23:1-3
* Genesis 16:11-12
* Genesis 25:9-11
* Genesis 25:13-16
* Genesis 37:25-26
* __Open Bible Stories - 05:02__ So Abram married Hagar. Hagar had a baby boy, and Abram named him __Ishmael__.
* __Open Bible Stories - 05:04__ "I will make __Ishmael__  a great nation, too, but my covenant will be with Isaac."
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/gad')">Gad</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/manasseh')">Manasseh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/naphtali')">Naphtali</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zebulun')">Zebulun</a>)
* Exodus 01:1-5
* Ezekiel 48:23-26
* Genesis 30:16-18
* Joshua 17:9-10
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/deceive')">deceive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaac')">Isaac</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rebekah')">Rebekah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* Acts 07:11-13
* Acts 07:44-46
* Genesis 25:24-26
* Genesis 29:1-3
* Genesis 32:1-2
* John 04:4-5
* Matthew 08:11-13
* Matthew 22:31-33
* __Open Bible Stories - 07:01__ As the boys grew up, Rebekah loved __Jacob__, but Isaac loved Esau. __Jacob__  loved to stay at home, but Esau loved to hunt.
* __Open Bible Stories - 07:07__ __Jacob__  lived there for many years, and during that time he married and had twelve sons and a daughter. God made him very wealthy.
* __Open Bible Stories - 07:08__ After twenty years away from his home in Canaan, __Jacob__  returned there with his family, his servants, and all his herds of animals.
* __Open Bible Stories - 07:10__ The covenant promises God had promised to Abraham and then to Isaac now passed on to __Jacob__.
* __Open Bible Stories - 08:01__ Many years later, when __Jacob__  was an old man, he sent his favorite son, Joseph, to check on his brothers who were taking care of the herds.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judassonofjames')">Judas the son of James</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/persecute')">persecute</a>)
* Galatians 01:18-20
* Galatians 02:9-10
* James 01:1-3
* Jude 01:1-2
* Mark 09:1-3
* Matthew 13:54-56
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamesbrotherofjesus')">James (brother of Jesus)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamessonofzebedee')">James (son of Zebedee)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* Acts 01:12-14
* Luke 06:14-16
* Mark 03:17-19
* Mark 14:32-34
* Matthew 10:2-4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamesbrotherofjesus')">James (brother of Jesus)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamessonofalphaeus')">James (son of Alphaeus)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>)
* Luke 09:28-29
* Mark 01:19-20
* Mark 01:29-31
* Mark 03:17-19
* Matthew 04:21-22
* Matthew 17:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/flood')">flood</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ham')">Ham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shem')">Shem</a>)
* 1 Chronicles 01:1-4
* Genesis 05:32
* Genesis 06:9-10
* Genesis 07:13-14
* Genesis 10:1
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ham')">Ham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/melchizedek')">Melchizedek</a>)
* 1 Chronicles 01:13-16
* 1 Kings 09:20-21
* Exodus 03:7-8
* Genesis 10:15-18
* Joshua 03:9-11
* Judges 01:20-21
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoiakim')">Jehoiakim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/manasseh')">Manasseh</a>)
* 2 Chronicles 36:8
* 2 Kings 24:15-17
* Esther 02:5-6
* Ezekiel 01:1-3
* Jeremiah 22:24-26
* Jeremiah 37:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaziah')">Ahaziah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/benaiah')">Benaiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joash')">Joash</a>)
* 2 Kings 11:4-6
* 2 Kings 12:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/eliakim')">Eliakim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>)
* 1 Chronicles 03:15-16
* 2 Kings 23:34-35
* 2 Kings 24:1-2
* Daniel 01:1-2
* Jeremiah 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoshaphat')">Jehoshaphat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joram')">Joram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/obadiah')">Obadiah</a>)
* 1 Kings 22:48-50
* 2 Chronicles 21:1-3
* 2 Kings 11:1-3
* 2 Kings 12:17-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 1 Chronicles 03:10-12
* 1 Kings 04:15-17
* 2 Chronicles 17:1-2
* 2 Kings 01:17-18
* 2 Samuel 08:15-18
* Matthew 01:7-8
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaziah')">Ahaziah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elisha')">Elisha</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoshaphat')">Jehoshaphat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehu')">Jehu</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jezebel')">Jezebel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joram')">Joram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>)
* 1 Chronicles 04:34-38
* 1 Kings 16:1-2
* 2 Chronicles 19:1-3
* 2 Kings 10:8-9
* Hosea 01:3-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ammon')">Ammon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/deliverer')">deliver</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephraim')">Ephraim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/judgeposition')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/vow')">vow</a>)
* Hebrews 11:32-34
* Judges 11:1-3
* Judges 11:34-35
* Judges 12:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/rebel')">rebel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/suffer')">suffer</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/well')">well</a>)
* 2 Chronicles 35:25
* Jeremiah 01:1-3
* Jeremiah 11:1-2
* Matthew 02:17-18
* Matthew 16:13-16
* Matthew 27:9-10
* __Open Bible Stories - 19:17__ Once, the prophet __Jeremiah__ was put into a dry well and left there to die. He sank down into the mud that was in the bottom of the well, but then the king had mercy on him and ordered his servants to pull __Jeremiah__ out of the well before he died.
* __Open Bible Stories - 21:05__ Through the prophet __Jeremiah__, God promised that he would make a New Covenant, but not like the covenant God made with Israel at Sinai.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joshua')">Joshua</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>)
* 1 Chronicles 06:77-79
* Joshua 02:1-3
* Joshua 07:2-3
* Luke 18:35-37
* Mark 10:46-48
* Matthew 20:29-31
* Numbers 22:1
* __Open Bible Stories - 15:01__ Joshua sent two spies to the Canaanite city of __Jericho__.
* __Open Bible Stories - 15:03__ After the people crossed the Jordan River, God told Joshua how to attack the powerful city of __Jericho__.
* __Open Bible Stories - 15:05__ Then the walls around __Jericho__ fell down! The Israelites destroyed everything in the city as God had commanded.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 1 Chronicles 05:16-17
* 1 Kings 12:1-2
* 2 Chronicles 09:29-31
* 2 Kings 03:1-3
* Amos 01:1-2
* __Open Bible Stories - 18:08__ The other ten tribes of the nation of Israel that rebelled against Rehoboam appointed a man named __Jeroboam__  to be their king.
* __Open Bible Stories - 18:09__ __Jeroboam__  rebelled against God and caused the people to sin. He built two idols for his people to worship instead of worshiping God at the Temple in the kingdom of Judah.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jebusites')">Jebusites</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/zion')">Zion</a>)
* Galatians 04:26-27
* John 02:13-14
* Luke 04:9-11
* Luke 13:4-5
* Mark 03:7-8
* Mark 03:20-22
* Matthew 03:4-6
* Matthew 04:23-25
* Matthew 20:17-19
* __Open Bible Stories - 17:05__ David conquered __Jerusalem__  and made it his capital city.
* __Open Bible Stories - 18:02__ In __Jerusalem__, Solomon built the Temple for which his father David had planned and gathered materials.
* __Open Bible Stories - 20:07__ They (Babylonians) captured the city of __Jerusalem__, destroyed the Temple, and took away all the treasures of the city and the Temple.
* __Open Bible Stories - 20:12__ So, after seventy years in exile, a small group of Jews returned to the city of __Jerusalem__  in Judah.
* __Open Bible Stories - 38:01__ About three years after Jesus first began preaching and teaching publicly, Jesus told his disciples that he wanted to celebrate this Passover with them in __Jerusalem__, and that he would be killed there.
* __Open Bible Stories - 38:02__ After Jesus and the disciples arrived in __Jerusalem__, Judas went to the Jewish leaders and offered to betray Jesus to them in exchange for money.
* __Open Bible Stories - 42:08__ "It was also written in the scriptures that my disciples will proclaim that everyone should repent in order to receive forgiveness for their sins. They will do this starting in __Jerusalem__, and then go to all people groups everywhere."
* __Open Bible Stories - 42:11__ Forty days after Jesus rose from the dead, he told his disciples, "Stay in __Jerusalem__  until you receive power when the Holy Spirit comes on you."
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/boaz')">Boaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fruit')">fruit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ruth')">Ruth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 02:9-12
* 1 Kings 12:16-17
* 1 Samuel 16:1
* Luke 03:30-32
* Matthew 01:4-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/captive')">captive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/clan')">clan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>)
* 1 Chronicles 01:34-37
* Exodus 02:18-20
* Exodus 03:1-3
* Exodus 18:1-4
* Numbers 10:29-30
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>)
* 1 Kings 16:31-33
* 1 Kings 19:1-3
* 2 Kings 09:7-8
* 2 Kings 09:30-32
* Revelation 02:20-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/issachar')">Issachar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jezebel')">Jezebel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/palace')">palace</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>)
* 1 Kings 04:11-14
* 1 Samuel 25:43-44
* 2 Kings 08:28-29
* 2 Samuel 02:1-3
* Judges 06:33
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/absalom')">Absalom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>)
* 1 Chronicles 02:16-17
* 1 Kings 01:7-8
* 1 Samuel 26:6-8
* 2 Samuel 02:18-19
* Nehemiah 07:11-14
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaziah')">Ahaziah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/benjamin')">Benjamin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gideon')">Gideon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/highplaces')">high places</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>)
* 1 Chronicles 03:10-12
* 2 Chronicles 18:25-27
* 2 Kings 11:1-3
* Amos 01:1-2
* Judges 06:11-12
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/flood')">flood</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a><a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peoplegroup')">people group</a>)
* Ezekiel 14:12-14
* James 05:9-11
* Job 01:1-3
* Job 03:4-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/joash')">Joash</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pentecost')">Pentecost</a>)
* 1 Chronicles 06:33-35
* 1 Samuel 08:1-3
* Acts 02:16-17
* Ezra 10:41-44
* Joel 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/barnabas')">Barnabas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>)
* 2 Timothy 04:11-13
* Acts 12:24-25
* Acts 13:4-5
* Acts 13:13-15
* Acts 15:36-38
* Acts 15:39-41
* Colossians 04:10-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/reveal')">reveal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamessonofzebedee')">James (son of Zebedee)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zebedee')">Zebedee</a>)
* Galatians 02:9-10
* John 01:19-21
* Mark 03:17-19
* Matthew 04:21-22
* Revelation 01:1-3
* __Open Bible Stories - 36:01__ One day, Jesus took three of his disciples, Peter, James, and __John__ with him. (The disciple named __John__ was not the same person who baptized Jesus.) They went up on a high mountain by themselves.\\
* __Open Bible Stories - 44:01__ One day, Peter and __John__ were going to the Temple. As they approached the Temple gate, they saw a crippled man who was begging for money.\\
* __Open Bible Stories - 44:06__ The leaders of the Temple were very upset by what Peter and __John__ were saying. So they arrested them and put them into prison.\\
* __Open Bible Stories - 44:07__ The next day, the Jewish leaders brought Peter and __John__ to the high priest and the other religious leaders. They asked Peter and __John__, "By what power did you heal this crippled man?"\\
* __Open Bible Stories - 44:09__ The leaders were shocked that Peter and __John__ spoke so boldly because they could see that these men were ordinary men who were uneducated. But then they remembered that these men had been with Jesus. After they threatened Peter and __John__, they let them go.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/baptize')">baptize</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahnt')">Zechariah (NT)</a>)
* John 03:22-24
* Luke 01:11-13
* Luke 01:62-63
* Luke 03:7
* Luke 03:15-16
* Luke 07:27-28
* Matthew 03:13-15
* Matthew 11:13-15
* __Open Bible Stories - 22:02__ The angel said to Zechariah, "Your wife will have a son. You will name him __John__. He will be filled with the Holy Spirit, and will prepare the people for Messiah!"
* __Open Bible Stories - 22:07__ After Elizabeth gave birth to her baby boy, Zechariah and Elizabeth named the baby __John__, as the angel had commanded. 
* __Open Bible Stories - 24:01__ __John__, the son of Zechariah and Elizabeth, grew up and became a prophet. He lived in the wilderness, ate wild honey and locusts, and wore clothes made from camel hair.
* __Open Bible Stories - 24:02__ Many people came out to the wilderness to listen to __John__. He preached to them, saying, "Repent, for the kingdom of God is near!"
* __Open Bible Stories - 24:06__ The next day, Jesus came to be baptized by __John__. When __John__ saw him, he said, "Look! There is the Lamb of God who will take away the sin of the world."
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nineveh')">Nineveh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/turn')">turn</a>)
* Jonah 01:1-3
* Luke 11:29-30
* Matthew 12:38-40
* Matthew 16:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abiathar')">Abiathar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/scribe')">scribe</a>)
* 1 Kings 01:41-42
* 1 Samuel 14:1
* 1 Samuel 20:1-2
* 2 Samuel 01:3-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sharon')">Sharon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/tarshish')">Tarshish</a>) 
* Acts 09:36-37
* Acts 10:7-8
* Acts 11:4-6
* Acts 11:11-14
* Jonah 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elijah')">Elijah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hamath')">Hamath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoram')">Jehoram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/obadiah')">Obadiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* 1 Chronicles 03:10-12
* 2 Chronicles 22:4-5
* 2 Kings 01:17-18
* 2 Kings 08:16-17
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seaofgalilee')">Sea of Galilee</a>)
* Genesis 32:9-10
* John 01:26-28
* John 03:25-26
* Luke 03:3
* Matthew 03:4-6
* Matthew 03:13-15
* Matthew 04:14-16
* Matthew 19:1-2
* __Open Bible Stories - 15:02__ The Israelites had to cross the __Jordan River__ to enter into the Promised Land. 
* __Open Bible Stories - 15:03__ After the people crossed the __Jordan River__, God told Joshua how to attack the powerful city of Jericho. 
* __Open Bible Stories - 19:14__ Elisha told him (Naaman) to dip himself seven times in the __Jordan River__.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/galilee')">Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nazareth')">Nazareth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/virgin')">virgin</a>)
* John 01:43-45
* Luke 01:26-29
* Luke 02:4-5
* Luke 02:15-16
* Matthew 01:18-19
* Matthew 01:24-25
* Matthew 02:19-21
* Matthew 13:54-56
* __Open Bible Stories - 22:04__ She (Mary) was a virgin and was engaged to be married to a man named __Joseph__.
* __Open Bible Stories - 23:01__ __Joseph__, the man Mary was engaged to, was a righteous man. When he heard that Mary was pregnant, he knew it was not his baby. He did not want to shame her, so he planned to quietly divorce her.
* __Open Bible Stories - 23:02__ The angel said, "__Joseph__, do not be afraid to take Mary as your wife. The baby in her body is from the Holy Spirit. She will give birth to a son. Name him Jesus (which means, 'Yahweh saves'), because he will save the people from their sins."
* __Open Bible Stories - 23:03__ So __Joseph__ married Mary and took her home as his wife, but he did not sleep with her until she had given birth.
* __Open Bible Stories - 23:04__ __Joseph__ and Mary had to make a long journey from where they lived in Nazareth to Bethlehem because their ancestor was David whose hometown was Bethlehem.
* __Open Bible Stories - 26:04__ Jesus said, "The words I just read to you are happening right now." All the people were amazed. "Isn't this the son of __Joseph__?" they said.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>)
* Genesis 30:22-24
* Genesis 33:1-3
* Genesis 37:1-2
* Genesis 37:23-24
* Genesis 41:55-57
* John 04:4-5
* __Open Bible Stories - 08:02__ __Joseph's__ brothers hated him because their father loved him most and because Joseph had dreamed that he would be their ruler.
* __Open Bible Stories - 08:04__ The slave traders took __Joseph__ to Egypt.
* __Open Bible Stories - 08:05__ Even in prison, __Joseph__ remained faithful to God, and God blessed him.
* __Open Bible Stories - 08:07__ God had given __Joseph__ the ability to interpret dreams, so Pharaoh had Joseph brought to him from the prison.
* __Open Bible Stories - 08:09__ __Joseph__ told the people to store up large amounts of food during the seven years of good harvests.
* __Open Bible Stories - 09:02__ The Egyptians no longer remembered __Joseph__ and all he had done to help them.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/haggai')">Haggai</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jericho')">Jericho</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promisedland')">Promised Land</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahot')">Zechariah (OT)</a>)
* 1 Chronicles 07:25-27
* Deuteronomy 03:21-22
* Exodus 17:8-10
* Joshua 01:1-3
* Numbers 27:18-19
* __Open Bible Stories - 14:04__ When the Israelites reached the edge of Canaan, Moses chose twelve men, one from each tribe of Israel. He gave the men instructions to go and spy on the land to see what it was like.
* __Open Bible Stories - 14:06__  Immediately Caleb and __Joshua__, the other two spies, said, "It is true that the people of Canaan are tall and strong, but we can certainly defeat them!"
* __Open Bible Stories - 14:08__ Except for __Joshua__ and Caleb, everyone who is twenty years old or older will die there and never enter the Promised Land."
* __Open Bible Stories - 14:14__ Moses was now very old, so God chose __Joshua__ to help him lead the people.  
* __Open Bible Stories - 14:15__ __Joshua__ was a good leader because he trusted and obeyed God. 
* __Open Bible Stories - 15:03__ After the people crossed the Jordan River, God told __Joshua__ how to attack the powerful city of Jericho.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/passover')">Passover</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 1 Chronicles 03:13-14
* 2 Chronicles 33:24-25
* 2 Chronicles 34:1-3
* Jeremiah 01:1-3
* Matthew 01:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abimelech')">Abimelech</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaz')">Ahaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gideon')">Gideon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/uzziah')">Uzziah</a>)
* 2 Chronicles 26:21
* 2 Kings 15:4-5
* Isaiah 01:1
* Judges 09:5-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judea')">Judea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 02:1-2
* 1 Kings 01:9-10
* Genesis 29:35
* Genesis 38:1-2
* Luke 03:33-35
* Ruth 01:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/betray')">betray</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judassonofjames')">Judas the son of James</a>)
* Luke 06:14-16
* Luke 22:47-48
* Mark 03:17-19
* Mark 14:10-11
* Matthew 26:23-25
* __Open Bible Stories - 38:02__ One of Jesus' disciples was a man named __Judas__. … After Jesus and the disciples arrived in Jerusalem, __Judas__  went to the Jewish leaders and offered to betray Jesus to them in exchange for money.
* __Open Bible Stories - 38:03__ The Jewish leaders, led by the high priest, paid __Judas__  thirty silver coins to betray Jesus.
* __Open Bible Stories - 38:14__ __Judas__  came with the Jewish leaders, soldiers, and a large crowd. They were all carrying swords and clubs. __Judas__  came to Jesus and said, "Greetings, teacher," and kissed him.
* __Open Bible Stories - 39:08__ Meanwhile, __Judas__, the betrayer, saw that the Jewish leaders had condemned Jesus to die. He became full of sorrow and went away and killed himself.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamessonofzebedee')">James (son of Zebedee)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judasiscariot')">Judas Iscariot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/son')">son</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* Acts 01:12-14
* Luke 06:14-16
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/galilee')">Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/edom')">Edom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>)
* 1 Thessalonians 02:14-16
* Acts 02:8-11
* Acts 09:31-32
* Acts 12:18-19
* John 03:22-24
* Luke 01:5-7
* Luke 04:42-44
* Luke 05:17
* Mark 10:1-4
* Matthew 02:1-3
* Matthew 02:4-6
* Matthew 02:22-23
* Matthew 03:1-3
* Matthew 19:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/edom')">Edom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>)
* Ezekiel 48:27-29
* Genesis 14:7-9
* Genesis 16:13-14
* Genesis 20:1-3
* Joshua 10:40-41
* Numbers 20:1
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/arabia')">Arabia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/goat')">goat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ishmael')">Ishmael</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* Song of Solomon 01:5-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hebron')">Hebron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/naphtali')">Naphtali</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/refuge')">refuge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shechem')">Shechem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 06:71-73
* Joshua 19:35-37
* Judges 04:10
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/absalom')">Absalom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/asa')">Asa</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/athaliah')">Athaliah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hezekiah')">Hezekiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/highplaces')">high places</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josiah')">Josiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mountofolives')">Mount of Olives</a>)
* John 18:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>)
* 2 Chronicles 35:18-19
* Jeremiah 05:10-13
* Jeremiah 09:25-26
* __Open Bible Stories - 18:08__ The other ten tribes of the nation of Israel that rebelled against Rehoboam appointed a man named Jeroboam to be their king. They set up their kingdom in the northern part of the land and were called the __kingdom of Israel__.
* __Open Bible Stories - 18:10__ The __kingdoms of Judah and Israel__ became enemies and often fought against each other.
* __Open Bible Stories - 18:11__ In the new __kingdom of Israel__, all the kings were evil.
* __Open Bible Stories - 20:01__ The __kingdoms of Israel__ and Judah both sinned against God.
* __Open Bible Stories - 20:02__ The __kingdom of Israel__ was destroyed by the Assyrian Empire, a powerful, cruel nation. The Assyrians killed many people in the __kingdom of Israel__, took away everything of value, and burned much of the country.
* __Open Bible Stories - 20:04__ Then the Assyrians brought foreigners to live in the land where the __kingdom of Israel__ had been. The foreigners rebuilt the destroyed cities and married the Israelites who were left there. The descendants of the Israelites who married foreigners were called Samaritans.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>)
* 1 Samuel 30:26-28
* 2 Samuel 12:7-8
* Hosea 05:14-15
* Jeremiah 07:33-34
* Judges 01:16-17
* __Open Bible Stories - 18:07__ Only two tribes remained faithful to him (Rehoboam). These two tribes became the __kingdom of Judah__.\\
* __Open Bible Stories - 18:10__ The __kingdoms of Judah__ and Israel became enemies and often fought against each other.\\
* __Open Bible Stories - 18:13__ The __kings of Judah__ were descendants of David. Some of these kings were good men who ruled justly and worshiped God. But most of __Judah's__ kings were evil, corrupt, and they worshiped idols.\\
* __Open Bible Stories - 20:01__ The __kingdoms of Israel and Judah__ both sinned against God.\\
* __Open Bible Stories - 20:05__ The people in the __kingdom of Judah__ saw how God had punished the people of the kingdom of Israel for not believing and obeying him. But they still worshiped idols, including the gods of the Canaanites.\\
* __Open Bible Stories - 20:06__ About 100 years after the Assyrians destroyed the kingdom of Israel, God sent Nebuchadnezzar, king of the Babylonians, to attack the __kingdom of Judah__.\\
* __Open Bible Stories - 20:09__ Nebuchadnezzar and his army took almost all of the people of __the kingdom of Judah__ to Babylon, leaving only the poorest people behind to plant the fields.\\
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aaron')">Aaron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/caleb')">Caleb</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* 1 Chronicles 01:34-37
* Numbers 16:1-3
* Numbers 16:25-27
* Psalm 042:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nahor')">Nahor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/leah')">Leah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rachel')">Rachel</a>)
* Genesis 24:28-30
* Genesis 24:50-51
* Genesis 27:43-45
* Genesis 28:1-2
* Genesis 29:4-6
* Genesis 29:13-14
* Genesis 30:25-26
* Genesis 46:16-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/cain')">Cain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seth')">Seth</a>)
* Genesis 04:18-19
* Genesis 04:23-24
* Genesis 05:25-27
* Genesis 05:28-29
* Genesis 05:30-31
* Luke 03:36-38
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/beg')">beg</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/martha')">Martha</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mary')">Mary</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/raise')">raise</a>)
* John 11:10-11
* John 12:1-3
* Luke 16:19-21
* __Open Bible Stories - 37:01__ One day, Jesus received a message that __Lazarus__  was very sick. __Lazarus__  and his two sisters, Mary and Martha, were close friends of Jesus.
* __Open Bible Stories - 37:02__ Jesus said, "Our friend __Lazarus__  has fallen asleep, and I must wake him."
* __Open Bible Stories - 37:03__ Jesus' disciples replied, "Master, if __Lazarus__  is sleeping, then he will get better." Then Jesus told them plainly, "__Lazarus__  is dead."
* __Open Bible Stories - 37:04__ When Jesus arrived at __Lazarus'__  hometown, __Lazarus__  had already been dead for four days.
* __Open Bible Stories - 37:06__ Jesus asked them, "Where have you put __Lazarus__?"
* __Open Bible Stories - 37:09__ Then Jesus shouted, "__Lazarus__, come out!"
* __Open Bible Stories - 37:10__ So __Lazarus__  came out! He was still wrapped in grave clothes.
* __Open Bible Stories - 37:11__ But the religious leaders of the Jews were jealous, so they gathered together to plan how they could kill Jesus and __Lazarus__.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/laban')">Laban</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rachel')">Rachel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rebekah')">Rebekah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* Genesis 29:15-18
* Genesis 29:28-30
* Genesis 31:4-6
* Ruth 04:11-12
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/cedar')">cedar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cypress')">cypress</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fir')">fir</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/phonecia')">Phoenicia</a>)
* 1 Kings 04:32-34
* 2 Chronicles 02:8-10
* Deuteronomy 01:7-8
* Psalms 029:3-5
* Zechariah 10:8-10
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaiah')">Isaiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/job')">Job</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/serpent')">serpent</a>)
* Job 03:8-10
* Psalms 104:25-26
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/matthew')">Matthew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 02:1-2
* 1 Kings 08:3-5
* Acts 04:36-37
* Genesis 29:33-34
* John 01:19-21
* Luke 10:31-32
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ammon')">Ammon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/haran')">Haran</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moab')">Moab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sodom')">Sodom</a>)
* 2 Peter 02:7-9
* Genesis 11:27-28
* Genesis 12:4-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/antioch')">Antioch</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)
* 2 Timothy 04:11-13
* Colossians 04:12-14
* Philemon 01:23-25
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evangelism')">evangelist</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/iconium')">Iconium</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/timothy')">Timothy</a>)
* 2 Timothy 03:10-13
* Acts 14:5-7
* Acts 14:8-10
* Acts 14:21-22
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asa')">Asa</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/asherim')">Asherah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nahor')">Nahor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/naphtali')">Naphtali</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/berea')">Berea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/greece')">Greece</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philippi')">Philippi</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/thessalonica')">Thessalonica</a>)
* 1 Thessalonians 01:6-7
* 1 Thessalonians 04:9-12
* 1 Timothy 01:3-4
* Acts 16:9-10
* Acts 20:1-3
* Philippians 04:14-17
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/creation')">create</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* Hosea 08:13-14
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/captive')">captive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/turn')">turn</a>)
* Malachi 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/dan')">Dan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephraim')">Ephraim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/pagan')">pagan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 2 Chronicles 15:8-9
* Deuteronomy 03:12-13
* Genesis 41:50-52
* Genesis 48:1-2
* Judges 01:27-28
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* 1 Chronicles 23:12-14
* 1 Kings 12:22-24
* 1 Samuel 09:9-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/lazarus')">Lazarus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/marysisterofmartha')">Mary (sister of Martha)</a>)
* John 11:1-2
* John 12:1-3
* Luke 10:38-39
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/cana')">Cana</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/herodthegreat')">Herod the Great</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josephnt')">Joseph (NT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/virgin')">virgin</a>)
* John 02:3-5
* John 02:12
* Luke 01:26-29
* Luke 01:34-35
* Mark 06:1-3
* Matthew 01:15-17
* Matthew 01:18-19
* __Open Bible Stories - 22:04__ When Elizabeth was six months pregnant, the same angel appeared to Elizabeth's relative, whose name was __Mary__. She was a virgin and was engaged to be married to a man named Joseph. The angel said, "You will become pregnant and give birth to a son. You are to name him Jesus and he will be the Messiah."
* __Open Bible Stories - 22:05__ The angel explained, "The Holy Spirit will come to you, and the power of God will overshadow you. So the baby will be holy, the Son of God." __Mary__ believed and accepted what the angel said.
* __Open Bible Stories - 22:06__ Soon after the angel spoke to __Mary__, she went and visited Elizabeth. As soon as Elizabeth heard __Mary's__ greeting, Elizabeth's baby jumped inside her.
* __Open Bible Stories - 23:02__ The angel said, "Joseph, do not be afraid to take __Mary__ as your wife. The baby in her body is from the Holy Spirit."
* __Open Bible Stories - 23:04__ Joseph and __Mary__ had to make a long journey from where they lived in Nazareth to Bethlehem because their ancestor was David whose hometown was Bethlehem.
* __Open Bible Stories - 49:01__ An angel told a virgin named __Mary__ that she would give birth to God's Son. So while she was still a virgin, she gave birth to a son and named him Jesus. 
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demonpossessed')">demon-possessed</a>)
* Luke 08:1-3
* Luke 24:8-10
* Mark 15:39-41
* Matthew 27:54-56
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethany')">Bethany</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/frankincense')">frankincense</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lazarus')">Lazarus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/martha')">Martha</a>)
* John 11:1-2
* John 12:1-3
* Luke 10:38-39
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tax')">tax collector</a>)
* Luke 05:27-28
* Luke 06:14-16
* Mark 02:13-14
* Mark 03:17-19
* Matthew 09:7-9
* Matthew 10:2-4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/cyrus')">Cyrus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/darius')">Darius</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elam')">Elam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>)
* 2 Kings 17:4-6
* Acts 02:8-11
* Daniel 05:25-28
* Esther 01:3-4
* Ezra 06:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peoplegroup')">people group</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prosper')">prosper</a>)
* Ezekiel 47:15-17
* Ezekiel 47:18-20
* Joshua 15:3-4
* Numbers 13:27-29
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eternity')">everlasting</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>)
* Genesis 14:17-18
* Hebrews 06:19-20
* Hebrews 07:15-17
* Psalm 110:4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translating Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nileriver')">Nile River</a>)
* Hosea 09:5-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/japheth')">Japheth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shem')">Shem</a>)
* 1 Chronicles 01:5-7
* Ezekiel 27:12-13
* Genesis 10:2-5
* Psalms 120:5-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/chaldeans')">Chaldea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/euphrates')">Euphrates River</a>)
* Acts 02:8-11
* Acts 07:1-3
* Genesis 24:10-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/dan')">Dan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephraim')">Ephraim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaiah')">Isaiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/judgeposition')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/silver')">silver</a>)
* Jeremiah 26:18-19
* Micah 01:1
* Micah 06:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/messenger')">messenger</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>)
* Daniel 10:12-13
* Daniel 10:20-21
* Ezra 08:8-11
* Revelation 12:7-9
(See also   <a style="cursor: pointer" onclick="return followLink('en/tw/names/arabia')">Arabia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/flock')">flock</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gideon')">Gideon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jethro')">Jethro</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>) 
* Acts 07:29-30
* Exodus 02:15-17
* Genesis 25:1-4
* Genesis 36:34-36
* Genesis 37:27-28
* Judges 07:1
* __Open Bible Stories - 16:03__ But then the people forgot about God and started worshiping idols again. So God allowed the __Midianites__, a nearby enemy people group, to defeat them. 
* __Open Bible Stories - 16:04__ The Israelites were so scared, they hid in caves so the __Midianites__ would not find them. 
* __Open Bible Stories - 16:11__ The man's friend said, "This dream means that Gideon's army will defeat the __Midianite__ army!" 
* __Open Bible Stories - 16:14__ God confused the __Midianites__, so that they started attacking and killing each other. 
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aaron')">Aaron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/cush')">Cush</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/intercede')">intercede</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nileriver')">Nile River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/pharaoh')">Pharaoh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/rebel')">rebel</a>)
* 1 Chronicles 06:1-3
* Deuteronomy 24:8-9
* Micah 06:3-5
* Numbers 12:1-3
* Numbers 20:1
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aaron')">Aaron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/azariah')">Azariah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hananiah')">Hananiah</a>)
* Daniel 01:6-7
* Daniel 02:17-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moab')">Moab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>)
* 1 Kings 15:20-22
* 1 Samuel 07:5-6
* 1 Samuel 07:10-11
* Jeremiah 40:5-6
* Judges 10:17-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judea')">Judea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lot')">Lot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ruth')">Ruth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>)
* Genesis 19:36-38
* Genesis 36:34-36
* Ruth 01:1-2
* Ruth 01:22
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Kings 11:7-8
* 2 Kings 23:10-11
* Acts 07:43
* Jeremiah 32:33-35
* Leviticus 18:21
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahasuerus')">Ahasuerus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esther')">Esther</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>)
* Esther 02:5-6
* Esther 03:5-6
* Esther 08:1-2
* Esther 10:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/miriam')">Miriam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promisedland')">Promised Land</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tencommandments')">Ten Commandments</a>)
* Acts 07:20-21
* Acts 07:29-30
* Exodus 02:9-10
* Exodus 09:1-4
* Matthew 17:3-4
* Romans 05:14-15
* __Open Bible Stories - 09:12__ One day while __Moses__ was taking care of his sheep, he saw a bush that was on fire.
* __Open Bible Stories - 12:05__ __Moses__ told the Israelites, "Stop being afraid! God will fight for you today and save you."
* __Open Bible Stories - 12:07__ God told __Moses__ to raise his hand over the sea and divide the waters.
* __Open Bible Stories - 12:12__ When the Israelites saw that the Egyptians were dead, they trusted in God and believed that Moses was a prophet of God.
* __Open Bible Stories - 13:07__ Then God wrote these Ten Commandments on two stone tablets and gave them to __Moses__.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seaofgalilee')">Sea of Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)
* 1 Chronicles 05:23-24
* Ezekiel 27:4-5
* Joshua 11:16-17
* Psalms 042:5-6
* Song of Solomon 04:8
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/gethsemane')">Gethsemane</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/olive')">olive</a>)
* Luke 19:29-31
* Luke 19:37-38
* Mark 13:3-4
* Matthew 21:1-3
* Matthew 24:3-5
* Matthew 26:30-32
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/leprosy')">leprosy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* 1 Chronicles 08:6-7
* 2 Kings 05:1-2
* Luke 04:25-27
* __Open Bible Stories - 19:14__ One of the miracles happened to __Naaman__, an enemy commander, who had a horrible skin disease.
* __Open Bible Stories - 19:15__ At first __Naaman__  was angry and would not do it because it seemed foolish. But later he changed his mind and dipped himself seven times in the Jordan River.
* __Open Bible Stories - 26:06__ "He (Elisha) only healed the skin disease of __Naaman__, a commander of Israel's enemies."
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rebekah')">Rebekah</a>)
* 1 Chronicles 01:24-27
* Genesis 31:51-53
* Joshua 24:1-2
* Luke 03:33-35
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/manasseh')">Manasseh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nineveh')">Nineveh</a>)
* Nahum 01:1
* Sometimes the name Naphtali was used to refer to the land where the tribe lived. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asher')">Asher</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/dan')">Dan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/seaofgalilee')">Sea of Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Kings 04:15-17
* Deuteronomy 27:13-14
* Ezekiel 48:1-3
* Genesis 30:7-8
* Judges 01:33
* Matthew 04:12-13
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/uriah')">Uriah</a>)
* 1 Chronicles 17:1-2
* 2 Chronicles 09:29-31
* 2 Samuel 12:1-3
* Psalm 051:1-2
* __Open Bible Stories - 17:07__ God sent the prophet __Nathan__ to David with this message, "Because you are a man of war, you will not build this Temple for me."
* __Open Bible Stories - 17:13__ God was very angry about what David had done, so he sent the prophet __Nathan__ to tell David how evil his sin was. 
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/galilee')">Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josephnt')">Joseph (NT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mary')">Mary</a>)
* Acts 26:9-11
* John 01:43-45
* Luke 01:26-29
* Mark 16:5-7
* Matthew 02:22-23
* Matthew 21:9-11
* Matthew 26:71-72
* __Open Bible Stories - 23:04__ Joseph and Mary had to make a long journey from where they lived in __Nazareth__ to Bethlehem because their ancestor was David whose hometown was Bethlehem.
* __Open Bible Stories - 26:02__ Jesus went to the town of __Nazareth__ where he had lived during his childhood.
* __Open Bible Stories - 26:07__ The people of __Nazareth__ dragged Jesus out of the place of worship and brought him to the edge of a cliff to throw him off of it in order to kill him.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/arrogant')">arrogant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/azariah')">Azariah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hananiah')">Hananiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mishael')">Mishael</a>)
* 1 Chronicles 06:13-15
* 2 Kings 25:1-3
* Daniel 01:1-2
* Daniel 04:4-6
* Ezekiel 26:7-8
* __Open Bible Stories - 20:06__ About 100 years after the Assyrians destroyed the kingdom of Israel, God sent __Nebuchadnezzar__, king of the Babylonians, to attack the kingdom of Judah.
* __Open Bible Stories - 20:06__ The king of Judah agreed to be __Nebuchadnezzar's__ servant and pay him a lot of money every year.
* __Open Bible Stories - 20:08__  To punish the king of Judah for rebelling, __Nebuchadnezzar's__ soldiers killed the king's sons in front of him and then made him blind.
* __Open Bible Stories - 20:09__ __Nebuchadnezzar__ and his army took almost all of the people of the kingdom of Judah to Babylon, leaving only the poorest people behind to plant the fields.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/beersheba')">Beersheba</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kadesh')">Kadesh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/simeon')">Simeon</a>)
* Genesis 12:8-9
* Genesis 20:1-3
* Genesis 24:61-62
* Joshua 03:14-16
* Numbers 13:17-20
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/artaxerxes')">Artaxerxes</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/son')">son</a>)
* Ezra 02:1-2
* Nehemiah 01:1-2
* Nehemiah 10:1-3
* Nehemiah 12:46-47
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/goshen')">Goshen</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>)
* Amos 08:7-8
* Genesis 41:1-3
* Jeremiah 46:7-9
* __Open Bible Stories - 08:04__ Egypt was a large, powerful country located along the __Nile River__.
* __Open Bible Stories - 09:04__ Pharaoh saw that the Israelites were having many babies, so he ordered his people to kill all Israelite baby boys by throwing them into the __Nile River__.
* __Open Bible Stories - 09:06__ When the boy's parents could no longer hide him, they put him in a floating basket among the reeds along the edge of the __Nile River__ in order to save him from being killed. 
* __Open Bible Stories - 10:03__ God turned the __Nile River__ into blood, but Pharaoh still would not let the Israelites go.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jonah')">Jonah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/turn')">turn</a>)
* Genesis 10:11-14
* Jonah 01:1-3
* Jonah 03:1-3
* Luke 11:32
* Matthew 12:41
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>)
* Genesis 05:30-31
* Genesis 05:32
* Genesis 06:7-8
* Genesis 08:1-3
* Hebrews 11:7
* Matthew 24:37-39
* __Open Bible Stories - 03:02__ But __Noah__  found favor with God.
* __Open Bible Stories - 03:04__ __Noah__  obeyed God. He and his three sons built the boat just the way God had told them.
* __Open Bible Stories - 03:13__ Two months later God said to __Noah__, "You and your family and all the animals may leave the boat now. Have many children and grandchildren and fill the earth." So __Noah__ and his family came out of the boat.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/edom')">Edom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezekiel')">Ezekiel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gad')">Gad</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoshaphat')">Jehoshaphat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josiah')">Josiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zedekiah')">Zedekiah</a>)
* 1 Chronicles 03:19-21
* 1 Chronicles 08:38-40
* Ezra 08:8-11
* Obadiah 01:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeroboam')">Jeroboam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/tirzah')">Tirzah</a>)
* 2 Chronicles 22:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethuel')">Bethuel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/haran')">Haran</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/laban')">Laban</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rebekah')">Rebekah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)
* Genesis 28:1-2
* Genesis 35:9-10
* Genesis 46:12-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kadesh')">Kadesh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sinai')">Sinai</a>)
* 1 Kings 11:18-19
* 1 Samuel 25:1
* Genesis 21:19-21
* Numbers 10:11-13
* Numbers 13:3-4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christian')">christian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">jewish leaders</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">rome</a>)
* 1 Corinthians 01:1-3
* Acts 08:1-3
* Acts 09:26-27
* Acts 13:9-10
* Galatians 01:1-2
* Philemon 01:8-9
* __Open Bible Stories - 45:06__ A young man named __Saul__ agreed with the people who killed Stephen and guarded their robes while they threw stones at him.
* __Open Bible Stories - 46:01__ __Saul__ was the young man who guarded the robes of the men who killed Stephen. He did not believe in Jesus, so he persecuted the believers.
* __Open Bible Stories - 46:02__ While __Saul__ was on his way to Damascus, a bright light from heaven shone all around him, and he fell to the ground. __Saul__ heard someone say, "__Saul__! __Saul__! Why do you persecute me?"
* __Open Bible Stories - 46:05__ So Ananias went to __Saul__, placed his hands on him, and said, "Jesus who appeared to you on your way here, sent me to you so that you can regain your sight and be filled with the Holy Spirit." __Saul__ immediately was able to see again, and Ananias baptized him.
* __Open Bible Stories - 46:06__ Right away, __Saul__ began preaching to the Jews in Damascus, saying, "Jesus is the Son of God!"
* __Open Bible Stories - 46:09__ Barnabas and __Saul__ went there (Antioch) to teach these new believers more about Jesus and to strengthen the church.
* __Open Bible Stories - 47:01__ As __Saul__ traveled throughout the Roman Empire, he began to use his Roman name, "__Paul__."
* __Open Bible Stories - 47:14__ __Paul__ and other Christian leaders traveled to many cities, preaching and teaching people the good news about Jesus.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/baal')">Baal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moab')">Moab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* Numbers 23:28-30
* Numbers 31:16-17
* Psalms 106:28-29
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>)
* 1 Kings 09:20-21
* 2 Chronicles 08:7-8
* Exodus 03:16-18
* Genesis 13:5-7
* Joshua 03:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahasuerus')">Ahasuerus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/artaxerxes')">Artaxerxes</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/cyrus')">Cyrus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esther')">Esther</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>)
* 2 Chronicles 36:20-21
* Daniel 10:12-13
* Esther 01:3-4
* Ezekiel 27:10-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>)
* Acts 08:25
* Galatians 02:6-8
* Galatians 02:11-12
* Luke 22:56-58
* Mark 03:13-16
* Matthew 04:18-20
* Matthew 08:14-15
* Matthew 14:28-30
* Matthew 26:33-35
* __Open Bible Stories - 28:09__ __Peter__ said to Jesus, "We have left everything and followed you. What will be our reward?"
* __Open Bible Stories - 29:01__ One day __Peter__ asked Jesus, "Master, how many times should I forgive my brother when he sins against me? As many as seven times?"
* __Open Bible Stories - 31:05__ Then __Peter__ said to Jesus, "Master, if it is you, command me to come to you on the water." Jesus told __Peter__, "Come!"
* __Open Bible Stories - 36:01__ One day, Jesus took three of his disciples, __Peter__, James, and John with him.
* __Open Bible Stories - 38:09__ __Peter__ replied, "Even if all the others abandon you, I will not!" Then Jesus said to __Peter__, "Satan wants to have all of you, but I have prayed for you, __Peter__, that your faith will not fail. Even so, tonight, before the rooster crows, you will deny that you even know me three times."
* __Open Bible Stories - 38:15__ As the soldiers arrested Jesus, __Peter__ pulled out his sword and cut off the ear of the servant of the high priest.
* __Open Bible Stories - 43:11__ __Peter__ answered them, "Every one of you should repent and be baptized in the name of Jesus Christ so that God will forgive your sins."
* __Open Bible Stories - 44:08__ __Peter__ answered them, "This man stands before you healed by the power of Jesus the Messiah."
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>)
* Acts 07:9-10
* Acts 07:11-13
* Acts 07:20-21
* Genesis 12:14-16
* Genesis 40:6-8
* Genesis 41:25-26
* __Open Bible Stories - 08:06__ One night, the __Pharaoh__, which is what the Egyptians called their kings, had two dreams that disturbed him greatly.
* __Open Bible Stories - 08:08__ __Pharaoh__  was so impressed with Joseph that he appointed him to be the second most powerful man in all of Egypt!
* __Open Bible Stories - 09:02__ So the __Pharaoh__  who was ruling over Egypt at that time made the Israelites slaves to the Egyptians.
* __Open Bible Stories - 09:13__ "I will send you to __Pharaoh__  so that you can bring the Israelites out of their slavery in Egypt."
* __Open Bible Stories - 10:02__ Through these plagues, God showed __Pharaoh __  that he is more powerful than __Pharaoh__  and all of Egypt's gods.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/philiptheapostle')">Philip</a>)
* Acts 06:5-6
* Acts 08:6-8
* Acts 08:12-13
* Acts 08:29-31
* Acts 08:36-38
* Acts 08:39-40
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/caesarea')">Caesarea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christian')">Christian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/macedonia')">Macedonia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/silas')">Silas</a>)
* 1 Thessalonians 02:1-2
* Acts 16:11-13
* Matthew 16:13-16
* Philippians 01:1-2
* __Open Bible Stories - 47:01__ One day, Paul and his friend Silas went to the town of __Philippi__ to proclaim the good news about Jesus. 
* __Open Bible Stories - 47:13__ The next day the leaders of the city released Paul and Silas from prison and asked them to leave __Philippi__.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/philip')">Philip</a>)
* Acts 01:12-14
* John 01:43-45
* John 06:4-6
* Luke 06:14-16
* Mark 03:17-19
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gaza')">Gaza</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joppa')">Joppa</a>)
* 1 Chronicles 10:9-10
* Joel 03:4-6
* Psalms 060:8-9
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ashdod')">Ashdod</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ashkelon')">Ashkelon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ekron')">Ekron</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gath')">Gath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gaza')">Gaza</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/goliath')">Goliath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>)
* 1 Chronicles 18:9-11
* 1 Samuel 13:3-4
* 2 Chronicles 09:25-26
* Genesis 10:11-14
* Psalm 056:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/midian')">Midian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samuel')">Samuel</a>)
* 1 Samuel 04:3-4
* Ezra 08:1-3
* Joshua 22:13-14
* Numbers 25:6-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/cedar')">cedar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/purple')">purple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sidon')">Sidon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/tyre')">Tyre</a>)
* Acts 11:19-21
* Acts 15:3-4
* Acts 21:1-2
* Isaiah 23:10-12
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/crucify')">crucify</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/governor')">governor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/guilt')">guilt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judea')">Judea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Acts 04:27-28
* Acts 13:28-29
* Luke 23:1-2
* Mark 15:1-3
* Matthew 27:11-14
* Matthew 27:57-58
* __Open Bible Stories - 39:09__ Early the next morning, the Jewish leaders brought Jesus to __Pilate__, the Roman governor. They hoped that __Pilate__ would condemn Jesus as guilty and sentenced him to be killed. __Pilate__ asked Jesus, "Are you the King of the Jews?"
* __Open Bible Stories - 39:10__ __Pilate__ said, "What is truth?"
* __Open Bible Stories - 39:11__ After speaking with Jesus, __Pilate__ went out to the crowd and said, "I find no guilt in this man." But the Jewish leaders and the crowd shouted, "Crucify him!" __Pilate__ replied, "He is not guilty." But they shouted even louder. Then __Pilate__ said a third time, "He is not guilty!"
* __Open Bible Stories - 39:12__ __Pilate__ became afraid that the crowd would begin to riot, so he ordered his soldiers to crucify Jesus.
* __Open Bible Stories - 40:02__ __Pilate__ commanded that a sign be put above Jesus' head that read, "King of the Jews."
* __Open Bible Stories - 41:02__ __Pilate__ said, "Take some soldiers and make the tomb as secure as you can."
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aquila')">Aquila</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pentecost')">Pentecost</a>) 
* 1 Peter 01:1-2
* Acts 02:8-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josephot')">Joseph (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/pharaoh')">Pharaoh</a>)
* Genesis 37:34-36
* Genesis 39:1-2
* Genesis 39:13-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christian')">Christian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/corinth')">Corinth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephesus')">Ephesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)
* 1 Corinthians 16:19-20
* 2 Timothy 04:19-22
* Acts 18:1-3
* Acts 18:24-26
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ammon')">Ammon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>)
* 1 Chronicles 20:1
* 2 Samuel 12:26-28
* Deuteronomy 03:11
* Ezekiel 25:3-5
* Jeremiah 49:1-2
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/laban')">Laban</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/leah')">Leah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josephot')">Joseph (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* Genesis 29:4-6
* Genesis 29:19-20
* Genesis 29:28-30
* Genesis 31:4-6
* Genesis 33:1-3
* Matthew 02:17-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jericho')">Jericho</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prostitute')">prostitute</a>)
* Hebrews 11:29-31
* James 02:25-26
* Joshua 02:20-21
* Joshua 06:17-19
* Matthew 01:4-6
* __Open Bible Stories - 15:01__ In that city there lived a prostitute named __Rahab__ who hid the spies and later helped them to escape. She did this because she believed God. They promised to protect __Rahab__ and her family when the Israelites would destroy Jericho. 
* __Open Bible Stories - 15:05__ The Israelites destroyed everything in the city as God had commanded. __Rahab__ and her family were the only people in the city that they did not kill. They became part of the Israelites.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/benjamin')">Benjamin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Chronicles 27:25-27
* 1 Samuel 02:11
* 2 Chronicles 16:1
* Jeremiah 31:15
* Joshua 18:25-28
* Matthew 02:17-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaziah')">Ahaziah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gad')">Gad</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoshaphat')">Jehoshaphat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehu')">Jehu</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joram')">Joram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/refuge')">refuge</a>)
* 1 Chronicles 06:71-73
* 1 Kings 22:3-4
* 2 Chronicles 18:1-3
* 2 Kings 08:28-29
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaac')">Isaac</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nahor')">Nahor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/negev')">Negev</a>)
* Genesis 24:15-16
* Genesis 24:45-46
* Genesis 24:56-58
* Genesis 24:63-65
* Genesis 25:27-28
* Genesis 26:6-8
* __Open Bible Stories - 06:02__ After a very long journey to the land where Abraham's relatives lived, God led the servant to __Rebekah__. She was the granddaughter of Abraham's brother.
* __Open Bible Stories - 06:06__ God told __Rebekah__, "There are two nations inside of you."
* __Open Bible Stories - 07:01__ As the boys grew up, __Rebekah__ loved Jacob, but Isaac loved Esau.
* __Open Bible Stories - 07:03__ Isaac wanted to give his blessing to Esau. But before he did, __Rebekah__ and Jacob tricked him by having Jacob pretend to be Esau.
* __Open Bible Stories - 07:06__ But __Rebekah__ heard of Esau's plan. So she sent Jacob far away to live with her relatives.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/arabia')">Arabia</a>**.** <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>)
* Acts 07:35-37
* Exodus 13:17-18
* Joshua 04:22-24
* Numbers 14:23-25
* __Open Bible Stories - 12:04__  When the Israelites saw the Egyptian army coming, they realized they were trapped between Pharaoh's army and the __Red Sea__.
* __Open Bible Stories - 12:05__  Then God told Moses, "Tell the people to move toward the __Red Sea__."
* __Open Bible Stories - 13:01__  After God led the Israelites through the __Red Sea__, he led them through the wilderness to a mountain called Sinai.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 1 Chronicles 03:10-12
* 1 Kings 11:41-43
* 1 Kings 14:21-22
* Matthew 01:7-8
* __Open Bible Stories - 18:05__ After Solomon died, his son, __Rehoboam__, became king. __Rehoboam__ was a foolish man.
* __Open Bible Stories - 18:06__ __Rehoboam__ answered foolishly and told them, "You thought my father Solomon made you work hard, but I will make you work harder than he did, and I will punish you more harshly than he did."
* __Open Bible Stories - 18:07__ Ten of the tribes of the nation of Israel rebelled against __Rehoboam__. Only two tribes remained faithful to him.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josephot')">Joseph (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/leah')">Leah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* Genesis 29:31-32
* Genesis 35:21-22
* Genesis 42:21-22
* Genesis 42:37-38
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/benjamin')">Benjamin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judea')">Judea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/naaman')">Naaman</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zebulun')">Zebulun</a>)
* 2 Kings 05:17-19
* 2 Samuel 04:5-7
* Judges 20:45-46
* Judges 21:13-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/pilate')">Pilate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>)
* 2 Timothy 01:15-18
* Acts 22:25-26
* Acts 28:13-15
* John 11:47-48
* __Open Bible Stories - 23:04__ When the time was near for Mary to give birth, the __Roman__ government told everyone to go for a census to the town where their ancestors had lived. 
* __Open Bible Stories - 32:06__ Then Jesus asked the demon, "What is your name?" He replied, "My name is Legion, because we are many." (A "legion" was a group of several thousand soldiers in the __Roman__ army.)
* __Open Bible Stories - 39:09__ Early the next morning, the Jewish leaders brought Jesus to the __Roman__ governor, Pilate, hoping to have Jesus killed.
* __Open Bible Stories - 39:12__ The __Roman__ soldiers whipped Jesus and put a royal robe and a crown made of thorns on him. Then they mocked him by saying, "Look, the King of the Jews!"
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/boaz')">Boaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/judgeposition')">judge</a>])
* Matthew 01:4-6
* Ruth 01:3-5
* Ruth 03:8-9
* Ruth 04:5-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ammon')">Ammon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/arabah')">Arabah</a>, , <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moab')">Moab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/negev')">Negev</a>)
* 2 Chronicles 20:1-2
* Deuteronomy 03:17
* Joshua 03:14-16
* Numbers 34:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/galilee')">Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judea')">Judea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sharon')">Sharon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>)
* Acts 08:1-3
* Acts 08:4-5
* John 04:4-5
* Luke 09:51-53
* Luke 10:33-35
* __Open Bible Stories - 20:04__ Then the Assyrians brought foreigners to live in the land where the kingdom of Israel had been. The foreigners rebuilt the destroyed cities and married the Israelites who were left there. The descendants of the Israelites who married foreigners were called __Samaritans__.
* __Open Bible Stories - 27:08__ "The next person to walk down that road was a __Samaritan__. (__Samaritans__ were the descendants of Jews who had married people from other nations. __Samaritans__ and Jews hated each other.)"
* __Open Bible Stories - 27:09__ "The __Samaritan__ then lifted the man onto his own donkey and took him to a roadside inn where he took care of him."
* __Open Bible Stories - 45:07__ He (Philip) went to __Samaria__ where he preached about Jesus and many people were saved.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/deliverer')">deliver</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* Hebrews 11:32-34
* Judges 13:24-25
* Judges 16:1-2
* Judges 16:30-31
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/hannah')">Hannah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Samuel 01:19-20
* 1 Samuel 09:23-24
* 1 Samuel 12:16-18
* Acts 03:24-26
* Acts 13:19-20
* Hebrews 11:32-34
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaac')">Isaac</a>)
* Genesis 11:29-30
* Genesis 11:31-32
* Genesis 17:15-16
* Genesis 25:9-11
* __Open Bible Stories - 05:01__ "So Abram's wife, __Sarai__, said to him, "Since God has not allowed me to have children and now I am too old to have children, here is my servant, Hagar. Marry her also so she can have a child for me."
* __Open Bible Stories - 05:04__ "'Your wife, __Sarai__, will have a son--he will be the son of promise.'"
* __Open Bible Stories - 05:04__ "God also changed __Sarai's__ name to __Sarah__, which means "princess."
* __Open Bible Stories - 05:05__ "About a year later, when Abraham was 100 years old and __Sarah__ was 90, __Sarah__ gave birth to Abraham's son. They named him Isaac as God had told them to do."
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>)
* 1 Chronicles 10:1-3
* 1 Samuel 09:1-2
* 2 Samuel 01:1-2
* Acts 13:21-22
* Psalm 018:1
* __Open Bible Stories - 17:01__ __Saul__ was the first king of Israel. He was tall and handsome, just like the people wanted. __Saul__ was a good king for the first few years that he ruled over Israel. But then he became a wicked man who did not obey God, so God chose a different man who would one day be king in his place.
* __Open Bible Stories - 17:04__ __Saul__ became jealous of the people's love for David. __Saul__ tried many times to kill him, so David hid from __Saul__. 
* __Open Bible Stories - 17:05__ Eventually, __Saul__ died in battle, and David became king of Israel.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/capernaum')">Capernaum</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/galilee')">Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>)
* John 06:1-3
* Luke 05:1-3
* Mark 01:16-18
* Matthew 04:12-13
* Matthew 04:18-20
* Matthew 08:18-20
* Matthew 13:1-2
* Matthew 15:29-31
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hezekiah')">Hezekiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/mock')">mock</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nineveh')">Nineveh</a>)
* 2 Chronicles 32:1
* 2 Chronicles 32:16-17
* 2 Kings 18:13-15
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abel')">Abel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/cain')">Cain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/call')">call</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/flood')">flood</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>)
* 1 Chronicles 01:1-4
* Luke 03:36-38
* Numbers 24:17
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/caesarea')">Caesarea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/carmel')">Carmel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joppa')">Joppa</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>)
* 1 Chronicles 05:16-17
* Acts 09:33-35
* Isaiah 33:9
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/arabia')">Arabia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/beersheba')">Beersheba</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ethiopia')">Ethiopia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 1 Chronicles 01:8-10
* 1 Kings 10:1-2
* Isaiah 60:6-7
* Psalms 072:8-10
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/tw/names/hamor')">Hamor</a>
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esau')">Esau</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hamor')">Hamor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hivite')">Hivite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>)
* Acts 07:14-16
* Genesis 12:6-7
* Genesis 33:18-20
* Genesis 37:12-14
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/arabia')">Arabia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/flood')">flood</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>)
* Genesis 05:32
* Genesis 06:9-10
* Genesis 07:13-14
* Genesis 10:1
* Genesis 10:30-31
* Genesis 11:10-11
* Luke 03:36-38
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethel')">Bethel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/dedicate')">dedicate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hannah')">Hannah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jordanriver')">Jordan River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samuel')">Samuel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 1 Kings 02:26-27
* 1 Samuel 01:9-10
* Joshua 18:1-2
* Judges 18:30-31
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/absalom')">Absalom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/benjamin')">Benjamin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* 1 Chronicles 06:16-18
* 1 Kings 01:7-8
* 2 Samuel 16:13-14
* Zechariah 12:12-14
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babel')">Babel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/chaldeans')">Chaldea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mesopotamia')">Mesopotamia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/patriarchs')">patriarchs</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ur')">Ur</a>)
* Genesis 10:8-10
* Genesis 14:1-2
* Genesis 14:7-9
* Isaiah 11:10-11
* Zechariah 05:10-11
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/phonecia')">Phoenicia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/tyre')">Tyre</a>)
* Acts 12:20-21
* Acts 27:3-6
* Genesis 10:15-18
* Genesis 10:19-20
* Mark 03:7-8
* Matthew 11:20-22
* Matthew 15:21-23
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/antioch')">Antioch</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/barnabas')">Barnabas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philippi')">Philippi</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prison')">prison</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/testimony')">testimony</a>)
* 1 Peter 05:12-14
* 1 Thessalonians 01:1
* 2 Thessalonians 01:1-2
* Acts 15:22-23
* __Open Bible Stories - 47:01__ One day, Paul and his friend __Silas__ went to the town of Philippi to proclaim the good news about Jesus. 
* __Open Bible Stories - 47:02__ She (Lydia) invited Paul and __Silas__ to stay at her house, so they stayed with her and her family.
* __Open Bible Stories - 47:03__ Paul and __Silas__ often met with people at the place of prayer. 
* __Open Bible Stories - 47:07__ So the owners of the slave girl took Paul and __Silas__ to the Roman authorities, who beat them  and threw them into jail.
* __Open Bible Stories - 47:08__ They put Paul and __Silas__ in the most secure part of the prison and even locked up their feet. 
* __Open Bible Stories - 47:11__ The jailer trembled as he came to Paul and __Silas__ and asked, "What must I do to be saved?" 
* __Open Bible Stories - 47:13__ The next day the leaders of the city released Paul and __Silas__ from prison and asked them to leave Philippi. Paul and __Silas__ visited Lydia and some other friends and then left the city.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/dedicate')">dedicate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* Genesis 29:33-34
* Genesis 34:24-26
* Genesis 42:35-36
* Genesis 43:21-23
* Luke 02:25-26
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* Acts 01:12-14
* Luke 06:14-16
* Mark 03:17-19
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/horeb')">Horeb</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promisedland')">Promised Land</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tencommandments')">Ten Commandments</a>)
* Acts 07:29-30
* Exodus 16:1-3
* Galatians 04:24-25
* Leviticus 27:34
* Numbers 01:17-19
* __Open Bible Stories - 13:01__ After God led the Israelites through the Red Sea, he led them through the wilderness to a mountain called __Sinai__.
* __Open Bible Stories - 13:03__ Three days later, after the people had prepared themselves spiritually, God came down on top of __Mount Sinai__ with thunder, lightning, smoke, and a loud trumpet blast.
* __Open Bible Stories - 13:11__ For many days, Moses was on top of __Mount Sinai__ talking with God.
* __Open Bible Stories - 15:13__ Then Joshua reminded the people of their obligation to obey the covenant that God had made with the Israelites at __Sinai__.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gomorrah')">Gomorrah</a>)
* Genesis 10:19-20
* Genesis 13:12-13
* Matthew 10:14-15
* Matthew 11:23-24
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bathsheba')">Bathsheba</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* Acts 07:47-50
* Luke 12:27-28
* Matthew 01:7-8
* Matthew 06:27-29
* Matthew 12:42
* __Open Bible Stories - 17:14__ Later,  David and Bathsheba had another son, and they named him __Solomon__.
* __Open Bible Stories - 18:01__ After many years, David died, and his son __Solomon__ began to rule. God spoke to __Solomon__ and asked him what he wanted most. When __Solomon__ asked for wisdom, God was pleased and made him the wisest man in the world. __Solomon__ learned many things and was a very wise judge. God also made him very wealthy.
* __Open Bible Stories - 18:02__ In Jerusalem, __Solomon__ built the Temple for which his father David had planned and gathered materials.
* __Open Bible Stories - 18:03__ But __Solomon__ loved women from other countries. ... When __Solomon__ was old, he also worshiped their gods.
* __Open Bible Stories - 18:04__ God was angry with __Solomon__ and, as a punishment for __Solomon's__ unfaithfulness, he promised to divide the nation of Israel into two kingdoms after __Solomon's__ death.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/appoint')">appoint</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/deacon')">deacon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/stone')">stone</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* Acts 06:5-6
* Acts 06:8-9
* Acts 06:10-11
* Acts 06:12-15
* Acts 07:59-60
* Acts 11:19-21
* Acts 22:19-21
* 1 Kings 07:46-47
* Exodus 12:37-40
* Joshua 13:27-28
* Judges 08:4-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/aram')">Aram</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/commander')">commander</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/damascus')">Damascus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elisha')">Elisha</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/leprosy')">leprosy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/naaman')">Naaman</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/persecute')">persecute</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* Acts 15:22-23
* Acts 15:39-41
* Acts 20:1-3
* Galatians 01:21-24
* Matthew 04:23-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/absalom')">Absalom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/amnon')">Amnon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
* 1 Chronicles 02:3-4
* 2 Samuel 13:1-2
* 2 Samuel 14:25-27
* Genesis 38:6-7
* Genesis 38:24-26
* Matthew 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/esther')">Esther</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/japheth')">Japheth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jonah')">Jonah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nineveh')">Nineveh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/phonecia')">Phoenicia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wisemen')">wise men</a>)
* Genesis 10:2-5
* Isaiah 02:14-16
* Jeremiah 10:8-10
* Jonah 01:1-3
* Psalms 048:7-8
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/cilicia')">Cilicia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/province')">province</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>)
* Acts 09:10-12
* Acts 09:28-30
* Acts 11:25-26
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/haran')">Haran</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lot')">Lot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mesopotamia')">Mesopotamia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nahor')">Nahor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sarah')">Sarah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shem')">Shem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ur')">Ur</a>)
* 1 Chronicles 01:24-27
* Luke 03:33-35
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/macedonia')">Macedonia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* 1 Thessalonians 01:1
* 2 Thessalonians 01:1-2
* 2 Timothy 04:9-10
* Acts 17:1-2
* Philippians 04:14-17
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godthefather')">God the Father</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/thetwelve')">the twelve</a>)
* Acts 01:12-14
* John 11:15-16
* Luke 06:14-16
* Mark 03:17-19
* Matthew 10:2-4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/appoint')">appoint</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/greek')">Greek</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/minister')">minister</a>)
* 1 Thessalonians 03:1-3
* 1 Timothy 01:1-2
* Acts 16:1-3
* Colossians 01:1-3
* Philemon 01:1-3
* Philippians 01:1-2
* Philippians 02:19-21
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/inherit')">inherit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/manasseh')">Manasseh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/shechem')">Shechem</a>)
* Numbers 27:1
* Numbers 36:10-12
* Song of Solomon 06:4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/appoint')">appoint</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/circumcise')">circumcise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/crete')">Crete</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/elder')">elder</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/courage')">encourage</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/instruct')">instruct</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/minister')">minister</a>)
* 2 Timothy 04:9-10
* Galatians 02:1-2
* Galatians 02:3-5
* Titus 01:4-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asia')">Asia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/preach')">preach</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/province')">province</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/raise')">raise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/scroll')">scroll</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/timothy')">Timothy</a>)
* 2 Corinthians 02:12-13
* 2 Timothy 04:11-13
* Acts 16:6-8
* Acts 20:4-6
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/cain')">Cain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezekiel')">Ezekiel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaiah')">Isaiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/japheth')">Japheth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lamech')">Lamech</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peoplegroup')">people group</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* 1 Chronicles 01:5-7
* Ezekiel 27:12-13
* Genesis 10:2-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asia')">Asia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/beloved')">beloved</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/colossae')">Colossae</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ephesus')">Ephesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/minister')">minister</a>)
* 2 Timothy 04:11-13
* Colossians 04:7-9
* Titus 03:12-13
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cedar')">cedar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/phonecia')">Phoenicia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sidon')">Sidon</a>)
* Acts 12:20-21
* Mark 03:7-8
* Matthew 11:20-22
* Matthew 15:21-23
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/chaldeans')">Chaldea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/euphrates')">Euphrates River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/haran')">Haran</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lot')">Lot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mesopotamia')">Mesopotamia</a>)
* Genesis 11:27-28
* Genesis 11:31-32
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahaz')">Ahaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/bathsheba')">Bathsheba</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hittite')">Hittite</a>)
* 1 Kings 15:4-6
* 2 Samuel 11:2-3
* 2 Samuel 11:26-27
* Nehemiah 03:3-5
* __Open Bible Stories - 17:12__ Bathsheba's husband, a man named __Uriah__, was one of David's best soldiers. David called __Uriah__ back from the battle and told him to go be with his wife. But __Uriah__ refused to go home while the rest of the soldiers were in battle. So David sent __Uriah__ back to the battle and told the general to place him where the enemy was strongest so that he would be killed.
* __Open Bible Stories - 17:13__ After __Uriah__ was killed, David married Bathsheba.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/leprosy')">leprosy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/reign')">reign</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/watchtower')">watchtower</a>)
* 2 Kings 14:20-22
* Amos 01:1-2
* Hosea 01:1-2
* Isaiah 06:1-2
* Matthew 01:7-8
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahasuerus')">Ahasuerus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esther')">Esther</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>)
* Esther 01:9-11
* Esther 02:1-2
* Esther 02:17-18
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promise')">promise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tax')">tax</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tax')">tax collector</a>)
* Luke 19:1-2
* Luke 19:5-7
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jotham')">Jotham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/reign')">reign</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 1 Chronicles 24:1-3
* 1 Kings 01:26-27
* 2 Samuel 15:24-26
* Matthew 01:12-14
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fisherman')">fishermen</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamessonofzebedee')">James (son of Zebedee)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johntheapostle')">John (the apostle)</a>)
* John 21:1-3
* Luke 05:8-11
* Mark 01:19-20
* Matthew 04:21-22
* Matthew 20:20-21
* Matthew 26:36-38
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/leah')">Leah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saltsea')">Salt Sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* Exodus 01:1-5
* Genesis 30:19-21
* Isaiah 09:1-2
* Judges 04:10
* Matthew 04:12-13
* Matthew 04:14-16
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elizabeth')">Elizabeth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* Luke 01:5-7
* Luke 01:21-23
* Luke 01:39-41
* Luke 03:1-2
* __Open Bible Stories - 22:01__ Suddenly an angel came with a message from God to an old priest named __Zechariah__. __Zechariah__ and his wife, Elizabeth, were godly people, but she had not been able to have any children.
* __Open Bible Stories - 22:02__ The angel said to __Zechariah__, "Your wife will have a son. You will name him John."
* __Open Bible Stories - 22:03__ Immediately, __Zechariah__ was unable to speak.
* __Open Bible Stories - 22:07__ Then God allowed __Zechariah__ to speak again.
(Translation Suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/darius')">Darius</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoshaphat')">Jehoshaphat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeroboam')">Jeroboam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zerubbabel')">Zerubbabel</a>)
* Ezra 05:1-2
* Matthew 23:34-36
* Zechariah 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahab')">Ahab</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezekiel')">Ezekiel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoiachin')">Jehoiachin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josiah')">Josiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>)
* 1 Chronicles 03:15-16
* Jeremiah 37:1-2
* Jeremiah 39:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josiah')">Josiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* 2 Kings 25:18-19
* Jeremiah 52:24-25
* Zechariah 06:9-11
* Zephaniah 01:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/captive')">captive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/cyrus')">Cyrus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoiakim')">Jehoiakim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/joshua')">Joshua</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nehemiah')">Nehemiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zedekiah')">Zedekiah</a>)
* 1 Chronicles 03:19-21
* Ezra 02:1-2
* Ezra 03:8-9
* Luke 03:27-29
* Matthew 01:12-14
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/lot')">Lot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sodom')">Sodom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/gomorrah')">Gomorrah</a>)
* Deuteronomy 34:1-3
* Genesis 13:10-11
* Genesis 14:1-2
* Genesis 19:21-22
* Genesis 19:23-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/inherit')">inherit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tribe')">tribe</a>) 
* Acts 26:6-8
* Genesis 49:28-30
* Luke 22:28-30
* Matthew 19:28
(See Also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hades')">Hades</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hell')">hell</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>)
* Luke 08:30-31
* Romans 10:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>)
* Deuteronomy 10:3-4
* Exodus 25:3-7
* Exodus 38:6-7
* Isaiah 41:19-20
* Acts 19:38-41
* Hosea 04:4-5
* Jeremiah 02:9-11
* Luke 06:6-8
* Romans 08:33-34
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/glory')">glory</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>)
* Daniel 11:38-39
* Jeremiah 09:4-6
* Job 34:26-28
* Leviticus 22:31-33
* Psalm 029:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/guilt')">guilt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* Deuteronomy 25:1-2
* Exodus 21:28-30
* Exodus 23:6-9
* Isaiah 05:22-23
* Job 10:12-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gift')">gift</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/governor')">governor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/hananiah')">Hananiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mishael')">Mishael</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/azariah')">Azariah</a>)
* 1 Chronicles 18:14-17
* Daniel 06:1-3
* Esther 09:3-5
* Nehemiah 09:32-34
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>)
* 1 Timothy 05:14-16
* Isaiah 09:11-12
* Job 06:21-23
* Lamentations 04:12-13
* Luke 12:57-59
* Matthew 13:24-26
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/leprosy')">leprosy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/plague')">plague</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/suffer')">suffer</a>)
* 2 Thessalonians 01:6-8
* Amos 05:12-13
* Colossians 01:24-27
* Exodus 22:22-24
* Genesis 12:17-20
* Genesis 15:12-13
* Genesis 29:31-32
* 1 Chronicles 29:26-28
* 1 Corinthians 02:6-7
* Hebrews 06:4-6
* Job 05:26-27
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jehoshaphat')">Jehoshaphat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moab')">Moab</a>)
* Daniel 11:44-45
* Jeremiah 04:19-20
* Numbers 10:9
* Acts 03:1-3
* Matthew 06:1-2
* Matthew 06:3-4
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/incense')">incense</a>)
* Luke 01:11-13
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sign')">sign</a>)
* Acts 08:9-11
* Acts 09:20-22
* Galatians 01:6-7
* Mark 02:10-12
* Matthew 07:28-29
* Matthew 15:29-31
* Matthew 19:25-27
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/messenger')">messenger</a>)
* Ephesians 06:19-20
* Luke 14:31-33
* Luke 19:13-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wrath')">wrath</a>)
* Ephesians 04:25-27
* Exodus 32:9-11
* Isaiah 57:16-17
* John 06:52-53
* Mark 10:13-14
* Matthew 26:6-9
* Psalms 018:7-8
* Jeremiah 06:23-24
* Jeremiah 19:6-9
* Job 15:22-24
* Luke 16:24
* Psalms 116:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>)
* 1 Samuel 31:1-3
* 2 Chronicles 35:23-24
* Genesis 21:19-21
* Isaiah 21:16-17
* Job 16:13-14
* Proverbs 26:9-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peace')">peace</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 1 Samuel 31:9-10
* 2 Samuel 20:8
* Ephesians 06:10-11
* Jeremiah 51:3-4
* Luke 11:21-23
* Nehemiah 04:15-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/acknowledge')">acknowledge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/boast')">boast</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/proud')">proud</a>)
* 1 Corinthians 04:17-18
* 2 Peter 02:17-19
* Ezekiel 16:49-50
* Proverbs 16:5-6
* Psalm 056:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/fire')">fire</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sackcloth')">sackcloth</a>)
* 1 Kings 20:9-10
* Jeremiah 06:25-26
* Psalms 102:9-10
* Psalms 113:7-8
* The phrase, "all the assembly" could be translated as "all the people" or "the whole group of Israelites" or "everyone." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-hyperbole')">hyperbole</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/council')">council</a>)
* 1 Kings 08:14-16
* Acts 07:38-40
* Ezra 10:12-13
* Hebrews 12:22-24
* Leviticus 04:20-21
* Nehemiah 08:1-3
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/appoint')">appoint</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samuel')">Samuel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>)
* 1 Chronicles 06:48
* Daniel 12:12-13
* Jeremiah 43:11-13
* Joshua 18:1-2
* Numbers 04:27-28
* Psalms 078:54-55
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>)
* 1 John 03:7-8
* 2 Timothy 03:10-13
* Exodus 23:4-5
* Ezekiel 48:10-12
* Matthew 18:12-14
* Matthew 24:3-5
* Psalms 058:3-5
* Psalms 119:109-110
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/justice')">just</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>)
* 1 Samuel 24:12-13
* Ezekiel 25:15-17
* Isaiah 47:3-5
* Leviticus 19:17-18
* Psalms 018:46-47
* Romans 12:19-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fear')">fear</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/glory')">glory</a>)
* 1 Chronicles 17:19-21
* Genesis 28:16-17
* Hebrews 12:27-29
* Psalm 022:22-23
* Psalms 147:4-5
* 1 Kings 06:7-8
* 2 Kings 06:4-5
* Judges 09:48-49
* Luke 03:9
* Matthew 03:10-12
* Psalm 035:1-3
* Daniel 05:10
* Isaiah 05:11-12
* Jeremiah 16:7-9
* Luke 05:29-32
* Song of Solomon 02:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/thresh')">thresh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wheat')">wheat</a>)
* 1 Chronicles 11:12-14
* Job 31:38-40
* Judges 07:13-14
* Numbers 05:15
* Revelation 06:5-6
* 1 Samuel 02:5
* Galatians 04:26-27
* Genesis 11:29-30
* Job 03:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nileriver')">Nile River</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>)
* 2 Corinthians 11:32-33
* Acts 09:23-25
* Amos 08:1-3
* John 06:13-15
* Judges 06:19-20
* Matthew 14:19-21
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burden')">burden</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elisha')">Elisha</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/endure')">endure</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fruit')">fruit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/iniquity')">iniquity</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/report')">report</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/strength')">strength</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/testimony')">testimony</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/testimony')">testimony</a>)
* Lamentations 03:25-29
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/elisha')">Elisha</a>)
* The Old Testament book of Daniel and the New Testament book of Revelation describe visions which have beasts that represent evil powers and authorities that oppose God.  (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/livestock')">livestock</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/nation')">nation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/reveal')">reveal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/beelzebul')">Beelzebul</a>)
* 1 Corinthians 15:31-32
* 1 Samuel 17:44-45
* 2 Chronicles 25:18-19
* Jeremiah 16:1-4
* Leviticus 07:21
* Psalms 049:12-13
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/plead')">plead</a>)
* Luke 16:19-21
* Mark 06:56
* Matthew 14:34-36
* Psalm 045:12-13
* __Open Bible Stories - 10:04__ God sent frogs all over Egypt. Pharaoh __begged__ Moses to take away the frogs.
* __Open Bible Stories - 29:08__ "The king called the servant and said, 'You wicked servant! I forgave your debt because you __begged__ me."
* __Open Bible Stories - 32:07__ The demons __begged__ Jesus, "Please do not send us out of this region!" There was a herd of pigs feeding on a nearby hill. So, the demons __begged__ Jesus, "Please send us into the pigs instead!"
* __Open Bible Stories - 32:10__ The man who used to have the demons __begged__ to go along with Jesus.
* __Open Bible Stories - 35:11__ His father came out and __begged__ him to come and celebrate with them, but he refused."
* __Open Bible Stories - 44:01__ One day, Peter and John were going to the Temple. As they approached the Temple gate, they saw a crippled man who was __begging__ for money.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/judasiscariot')">Judas Iscariot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>)
* Acts 07:51-53
* John 06:64-65
* John 13:21-22
* Matthew 10:2-4
* Matthew 26:20-22
* __Open Bible Stories - 21:11__ Other prophets foretold that those who killed the Messiah would gamble for his clothes and he would be __betrayed__  by a friend. The prophet Zechariah foretold that the friend would be paid thirty silver coins as payment for __betraying__  the Messiah.
* __Open Bible Stories - 38:02__ After Jesus and the disciples arrived in Jerusalem, Judas went to the Jewish leaders and offered to __betray__  Jesus to them in exchange for money.
* __Open Bible Stories - 38:03__ The Jewish leaders, led by the high priest, paid Judas thirty silver coins to __betray__  Jesus.
* __Open Bible Stories - 38:06__ Then Jesus said to the disciples, "One of you will __betray__  me." â€¦ Jesus said, "The person to whom I give this piece of bread is the __betrayer__."
* __Open Bible Stories - 38:13__ When he returned the third time, Jesus said, "Wake up! My __betrayer__  is here."
* __Open Bible Stories - 38:14__ Then Jesus said, "Judas, do you __betray__  me with a kiss?"
* __Open Bible Stories - 39:08__ Meanwhile, Judas, the __betrayer__, saw that the Jewish leaders had condemned Jesus to die. He became full of sorrow and went away and killed himself.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judgmentday')">judgment day</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lastday')">last day</a>)
* Acts 20:4-6
* Daniel 10:4-6
* Ezra 06:13-15
* Ezra 06:19-20
* Matthew 09:14-15
* Acts 02:14-15
* John 04:51-52
* Luke 23:44-45
* Matthew 20:3-4
* 1 Samuel 20:32-34
* Acts 18:9-11
* Hebrews 11:23-26
* Numbers 10:10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/watch')">watch</a>)
* Luke 12:37-38
* Mark 06:48-50
* Matthew 14:25-27
* Psalms 090:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pentecost')">Pentecost</a>)
* Acts 20:7-8
* Deuteronomy 16:9-10
* Leviticus 23:15-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/biblicaltimemonth')">month</a>)
* 2 Kings 23:31-33
* Acts 19:8-10
* Daniel 08:1-2
* Exodus 12:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* 1 Peter 01:18-19
* 2 Peter 02:12-14
* Deuteronomy 15:19-21
* Numbers 06:13-15
* Song of Solomon 04:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/blood')">blood</a> <a style="cursor: pointer" onclick="return followLink('en/tw/other/slaughter')">slaughter</a>)
* 1 Chronicles 22:6-8
* Genesis 09:5-7
* Hebrews 09:21-22
* Isaiah 26:20-21
* Matthew 23:29-31
* Deuteronomy 29:20-21
* Exodus 32:30-32
* Genesis 07:23-24
* Psalm 051:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/confidence')">confidence</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/redeem')">redeem</a>)
* 1 John 02:27-29
* 1 Thessalonians 02:1-2
* 2 Corinthians 03:12-13
* Acts 04:13-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eternity')">everlasting</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lamb')">lamb</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/scroll')">scroll</a>)
* Philippians 04:1-3
* Psalms 069:28-29
* Revelation 03:5-6
* Revelation 20:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/humble')">humble</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* 2 Kings 05:17-19
* Exodus 20:4-6
* Genesis 24:26-27
* Genesis 44:14-15
* Isaiah 44:19
* Luke 24:4-5
* Matthew 02:11-12
* Revelation 03:9-11
* Genesis 21:14-16
* Habakkuk 03:9-10
* Job 29:20-22
* Lamentations 02:3-4
* Psalms 058:6-8
* Since bread was the main food for many people in biblical times, this term is also used in the Bible to refer to food in general. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">Synecdoche</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/passover')">Passover</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/unleavenedbread')">unleavened bread</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/yeast')">yeast</a>) 
* Acts 02:46-47
* Acts 27:33-35
* Exodus 16:13-15
* Luke 09:12-14
* Mark 06:37-38
* Matthew 04:1-4
* Matthew 11:18-19
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/armor')">armor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/pierce')">pierce</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/warrior')">warrior</a>)
* 1 Thessalonians 05:8-11
* Exodus 39:14-16
* Isaiah 59:17-18
* Revelation 09:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/adam')">Adam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>)
* 1 Kings 17:17-18
* Ecclesiastes 08:8-9
* Job 04:7-9
* Revelation 11:10-12
* Revelation 13:15-17
* 1 Samuel 08:1-3
* Ecclesiastes 07:7
* Isaiah 01:23
* Micah 03:9-11
* Proverbs 15:27-28
* Jesus is metaphorically called the "bridegroom" for the Church. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bridegroom')">bridegroom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>)
* Exodus 22:16-17
* Isaiah 62:5
* Joel 02:15-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bride')">bride</a>)
* Isaiah 62:5
* Joel 02:15-16
* John 03:29-30
* Luke 05:33-35
* Mark 02:18-19
* Mark 02:20-21
* Matthew 09:14-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/armor')">armor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 1 Kings 07:15-17
* 1 Samuel 17:37-38
* Daniel 02:44-45
* Exodus 25:3-7
* Revelation 01:14-16
* 2 Thessalonians 03:6-9
* Galatians 06:1-2
* Galatians 06:3-5
* Genesis 49:14-15
* Matthew 11:28-30
* Matthew 23:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/atonement')">atonement</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cow')">ox</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* Exodus 40:5-7
* Genesis 08:20-22
* Genesis 22:1-3
* Leviticus 03:3-5
* Mark 12:32-34
(See also:<a style="cursor: pointer" onclick="return followLink('en/tw/names/jericho')">Jericho</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tomb')">tomb</a>)
* 2 Kings 09:9-10
* Genesis 35:4-5
* Jeremiah 25:32-33
* Luke 16:22-23
* Matthew 27:6-8
* Psalm 079:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burden')">burden</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>)
* 1 Chronicles 05:20-22
* 2 Chronicles 09:1-2
* Exodus 09:1-4
* Mark 10:23-25
* Matthew 03:4-6
* Matthew 19:23-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/exile')">exile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prison')">prison</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/seize')">seize</a>)
* 2 Corinthians 10:5-6
* Isaiah 20:3-4
* Jeremiah 43:1-3
* Luke 04:18-19
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demonpossessed')">demon-possessed</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/lots')">lots</a>)
* Acts 07:17-19
* Mark 03:13-16
* Mark 09:28-29
* Matthew 07:21-23
* Matthew 09:32-34
* Matthew 12:24-25
* Matthew 17:19-21
(see: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/overtake')">overtake</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/suffer')">suffer</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/trouble')">trouble</a>)
* 2 Corinthians 12:1-2
* Acts 08:39-40
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/fir')">fir</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/purify')">pure</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 1 Chronicles 14:1-2
* 1 Kings 07:1-2
* Isaiah 02:12-13
* Zechariah 11:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/nation')">nation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Acts 05:35-37
* Exodus 30:11-14
* Exodus 38:24-26
* Luke 02:1-3
* Numbers 04:1-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wheat')">wheat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/winnow')">winnow</a>)
* Daniel 02:34-35
* Job 21:16-18
* Luke 03:17
* Matthew 03:10-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>) 
* 1 Kings 09:22
* 2 Chronicles 18:28-30
* Acts 08:29-31
* Acts 08:36-38
* Daniel 11:40-41
* Exodus 14:23-25
* Genesis 41:42-43
* __Open Bible Stories - 12:10__ So they followed the Israelites onto the path through the sea, but God caused the Egyptians to panic and caused their __chariots__ to get stuck.
* Also consider how this term is translated or written in a Bible translation in a local or national language. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>)
* 1 Chronicles 13:5-6
* 1 Kings 06:23-26
* Exodus 25:15-18
* Ezekiel 09:3-4
* Genesis 03:22-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/chiefpriests')">chief priests</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tax')">tax collector</a>)
* Daniel 01:11-13
* Ezekiel 26:15-16
* Luke 19:1-2
* Psalm 004:1
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/chief')">chief</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* Acts 09:13-16
* Acts 22:30
* Acts 26:12-14
* Luke 20:1-2
* Mark 08:31-32
* Matthew 16:21-23
* Matthew 26:3-5
* Matthew 26:59-61
* Matthew 27:41-42
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/exile')">exile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 1 Chronicles 27:23-24
* 2 Chronicles 33:18-20
* Esther 10:1-2
( See: <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/province')">province</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Acts 21:39-40
* Isaiah 03:1-3
* Luke 15:15-16
* Luke 19:13-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/family')">family</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jethro')">Jethro</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tribe')">tribe</a>)
* 1 Chronicles 06:33-35
* Genesis 10:2-5
* Genesis 36:15-16
* Genesis 36:29-30
* Genesis 36:40-43
* Joshua 15:20
* Numbers 03:38-39
* Luke 24:48-49
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/courage')">encourage</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>)
* 1 Thessalonians 05:8-11
* 2 Corinthians 01:3-4
* 2 Samuel 10:1-3
* Acts 20:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/centurion')">centurion</a>)
* 1 Chronicles 11:4-6
* 2 Chronicles 11:11-12
* Daniel 02:14-16
* Mark 06:21-22
* Proverbs 06:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promise')">promise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* 1 Chronicles 28:6-7
* 1 Peter 02:21-23
* Jeremiah 02:12-13
* Matthew 13:40-43
* Psalm 058:1-2
* Ezekiel 37:15-17
* Hebrews 01:8-9
* Proverbs 02:16-17
* Psalms 038:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/creation')">create</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/womb')">womb</a>)
* Genesis 21:1-4
* Hosea 02:4-5
* Job 15:34-35
* Luke 01:24-25
* Luke 02:21
* 2 Samuel 03:6-7
* Genesis 22:23-24
* Genesis 25:5-6
* Genesis 35:21-22
* Genesis 36:9-12
* Judges 19:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/bold')">bold</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hope')">hope</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/trust')">trust</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/oath')">oath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/trust')">trust</a>)
* 1 Chronicles 16:15-18
* 2 Corinthians 01:21-22
* 2 Kings 23:3
* Hebrews 06:16-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/devour')">devour</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wrath')">wrath</a>)
* 1 Kings 18:38-40
* Deuteronomy 07:16
* Jeremiah 03:23-25
* Job 07:8-10
* Numbers 11:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/dishonor')">dishonor</a>)
* Daniel 12:1-2
* Proverbs 15:5-6
* Psalms 031:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>)
* Ezekiel 20:42-44
* Galatians 06:6-8
* Genesis 06:11-12
* Matthew 12:33-35
* Psalm 014:1
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/assembly')">assembly</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/counselor')">counsel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pharisee')">Pharisee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sadducee')">Sadducee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/scribe')">scribe</a>)
* Acts 07:57-58
* Acts 24:20-21
* John 03:1-2
* Luke 22:66-68
* Mark 13:9-10
* Matthew 05:21-22
* Matthew 26:59-61
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/exhort')">exhort</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wise')">wise</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/confidence')">confidence</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/exhort')">exhort</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fear')">fear</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/strength')">strength</a>)
* Deuteronomy 01:37-38
* 2 Kings 18:19-21
* 1 Chronicles 17:25-27
* Matthew 09:20-22
* 1 Corinthians 14:1-4
* 2 Corinthians 07:13-14
* Acts 05:12-13
* Acts 16:40
* Hebrews 03:12-13
* Hebrews 13:5-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gentile')">Gentile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/judgeposition')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 2 Kings 20:4-5
* Exodus 27:9-10
* Jeremiah 19:14-15
* Luke 22:54-55
* Matthew 26:69-70
* Numbers 03:24-26
* Psalms 065:4
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/yoke')">yoke</a>)
* Genesis 15:9-11
* Exodus 24:5-6
* Numbers 19:1-2
* Deuteronomy 21:3-4
* 1 Samuel 01:24-25
* 1 Samuel 15:1-3
* 1 Samuel 16:2-3
* 1 Kings 01:9-10
* 2 Chronicles 11:13-15
* 2 Chronicles 15:10-11
* Matthew 22:4
* Luke 13:15-16
* Luke 14:4-6
* Hebrews 09:13-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/world')">world</a>)
* 1 Corinthians 11:9-10
* 1 Peter 04:17-19
* Colossians 01:15-17
* Galatians 06:14-16
* Genesis 01:1-2
* Genesis 14:19-20
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/creation')">create</a>)
* Daniel 04:10-12
* Ezekiel 01:7-9
* Joshua 10:28
* Leviticus 11:46-47
* Revelation 19:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/thief')">thief</a>)
* 2 Timothy 02:8-10
* Hosea 06:8-9
* Job 31:26-28
* Luke 23:32
* Matthew 27:23-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/glory')">glory</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/olive')">olive</a>)
* John 19:1-3
* Lamentations 05:15-16
* Matthew 27:27-29
* Philippians 04:1-3
* Psalms 021:3-4
* Revelation 03:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/call')">call</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/plead')">plead</a>)
* Job 27:8-10
* Mark 05:5-6
* Mark 06:48-50
* Psalm 022:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/artaxerxes')">Artaxerxes</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/captive')">captive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/pharaoh')">Pharaoh</a>)
* 1 Kings 10:3-5
* Nehemiah 01:10-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyplace')">holy place</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* Hebrews 10:19-22
* Leviticus 04:16-17
* Luke 23:44-45
* Matthew 27:51-53
* Numbers 04:5-6
* Genesis 17:12-14
* Judges 21:6-7
* Proverbs 23:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/cyprus')">Cyprus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fir')">fir</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lebanon')">Lebanon</a>)
* Acts 11:19-21
* Genesis 06:13-15
* Hosea 14:7-8
* Isaiah 44:14
* Isaiah 60:12-13
* Zechariah 11:1-3
* The term "darkness" can also be used as a metaphor for death. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/corrupt')">corrupt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/dominion')">dominion</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/light')">light</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/redeem')">redeem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>)
* 1 John 01:5-7
* 1 John 02:7-8
* 1 Thessalonians 05:4-7
* 2 Samuel 22:10-12
* Colossians 01:13-14
* Isaiah 05:29-30
* Jeremiah 13:15-17
* Joshua 24:7
* Matthew 08:11-13
* The expression "the dead" is a nominal adjective that refers to people who have died. Some languages will translate this as "dead people" or "people who have died."  (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-nominaladj')">nominal adjective</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 1 Corinthians 15:20-21
* 1 Thessalonians 04:16-18
* Acts 10:42-43
* Acts 14:19-20
* Colossians 02:13-15
* Colossians 02:20-23
* Genesis 02:15-17
* Genesis 34:27-29
* Matthew 16:27-28
* Romans 05:10-11
* Romans 05:12-13
* Romans 06:10-11
* __Open Bible Stories - 01:11__ God told Adam that he could eat from any tree in the garden except from the tree of the knowledge of good and evil. If he ate from this tree, he would __die__.
* __Open Bible Stories - 02:11__ "Then you will __die__, and your body will return to dirt."
* __Open Bible Stories - 07:10__ Then Isaac __died__, and Jacob and Esau buried him.
* __Open Bible Stories - 37:05__ "Jesus replied, "I am the Resurrection and the Life. Whoever believes in me will live, even though he __dies__. Everyone who believes in me will never __die__."
* __Open Bible Stories - 40:08__ Through his __death__, Jesus opened a way for people to come to God.
* __Open Bible Stories - 43:07__ "Although Jesus __died__, God raised him from the dead."
* __Open Bible Stories - 48:02__ Because they sinned, everyone on earth gets sick and everyone __dies__.
* __Open Bible Stories - 50:17__ He (Jesus) will wipe away every tear and there will be no more suffering, sadness, crying, evil, pain, or __death__.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* 1 John 01:8-10
* 1 Timothy 02:13-15
* 2 Thessalonians 02:3-4
* Genesis 03:12-13
* Genesis 31:26-28
* Leviticus 19:11-12
* Matthew 27:62-64
* Micah 06:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/preach')">proclaim</a>)
* 1 Chronicles 16:23-24
* 1 Corinthians 15:31-32
* 1 Samuel 24:17-18
* Amos 02:15-16
* Ezekiel 05:11-12
* Matthew 07:21-23
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/declare')">declare</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/preach')">proclaim</a>)
* 1 Chronicles 15:13-15
* 1 Kings 08:57-58
* Acts 17:5-7
* Daniel 02:12-13
* Esther 01:21-22
* Luke 02:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/commit')">commit</a>)
* 1 Chronicles 15:11-12
* 1 Corinthians 06:9-11
* 1 Kings 07:51
* 1 Timothy 04:3-5
* 2 Chronicles 02:4-5
* John 17:18-19
* Luke 02:22-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
* 2 Samuel 22:34-35
* Genesis 49:19-21
* Job 39:1-2
* Psalms 018:33-34
* Song of Solomon 02:7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>)
* 2 Kings 23:8-9
* Exodus 20:24-26
* Genesis 34:27-29
* Genesis 49:3-4
* Isaiah 43:27-28
* Leviticus 11:43-45
* Mark 07:14-16
* Matthew 15:10-11
* Proverbs 08:30-31
* Psalm 001:1-2
* Psalms 119:69-70
* Song of Solomon 01:1-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>)
* 2 Corinthians 01:8-10
* Acts 07:35-37
* Galatians 01:3-5
* Judges 10:10-12
* __Open Bible Stories - 16:03__ Then God provided a __deliverer__  who rescued them from their enemies and brought peace to the land.
* __Open Bible Stories - 16:16__ They (Israel) finally asked God for help again, and God sent them another __deliverer__.
* __Open Bible Stories - 16:17__ Over many years, God sent many __deliverers__  who saved the Israelites from their enemies.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jacob')">Jacob</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Kings 09:4-5
* Acts 13:23-25
* Deuteronomy 02:20-22
* Genesis 10:1
* Genesis 28:12-13
* __Open Bible Stories - 02:09__ "The woman's __descendant__ will crush your head, and you will wound his heel."
* __Open Bible Stories - 04:09__ "I give the land of Canaan to your __descendants__."
* __Open Bible Stories - 05:10__ "Your __descendants__ will be more than the stars in the sky."
* __Open Bible Stories - 17:07__ "Someone from your family will always rule as king over Israel, and the Messiah will be one of your __descendants__!"
* __Open Bible Stories - 18:13__ The kings of Judah were __descendants__ of David.
* __Open Bible Stories - 21:04__ God promised King David that the Messiah would be one of David's own __descendants__.
* __Open Bible Stories - 48:13__ God promised David that the Messiah would be one of his __descendants__. Jesus, the Messiah, was that special __descendant__ of David.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/defile')">defile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/dishonor')">dishonor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/profane')">profane</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/purify')">pure</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>)
* Acts 24:4-6
* Isaiah 30:22
* Psalms 074:7-8
* Psalms 089:38-40
* Acts 13:16-18
* Acts 21:37-38
* Exodus 04:27-28
* Genesis 37:21-22
* John 03:14-15
* Luke 01:80
* Luke 09:12-14
* Mark 01:1-3
* Matthew 04:1-4
* Matthew 11:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/devastated')">devastate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruin')">ruin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/waste')">waste</a>)
* 2 Kings 22:17-19
* Acts 01:20
* Daniel 09:17-19
* Lamentations 03:9-11
* Luke 11:16-17
* Matthew 12:24-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/captive')">captive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eternity')">everlasting</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hell')">hell</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>)
* 1 Thessalonians 05:8-11
* Ecclesiastes 02:13-14
* Hebrews 09:27-28
* Philippians 03:17-19
* Psalms 009:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/firstborn')">firstborn</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/passover')">Passover</a>)
* Exodus 12:23
* Hebrews 11:27-28
* Jeremiah 06:25-26
* Judges 16:23-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/divination')">divination</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>)
* Genesis 43:32-34
* Jeremiah 07:29-30
* Leviticus 11:9-10
* Luke 16:14-15
* Revelation 17:3-5
* Daniel 08:24-25
* Jeremiah 04:13-15
* Numbers 21:29-30
* Zephaniah 01:12-13
* 1 Peter 05:8-9
* Amos 01:9-10
* Exodus 24:16-18
* Ezekiel 16:20-22
* Luke 15:28-30
* Matthew 23:13-15
* Psalms 021:9-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wise')">wise</a>)
* 1 Kings 03:7-9
* Genesis 41:33-34
* Proverbs 01:4-6
* Psalms 019:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/dishonor')">dishonor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shame')">shame</a>)
* 1 Timothy 03:6-7
* Genesis 34:6-7
* Hebrews 11:23-26
* Lamentations 02:1-2
* Psalms 022:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disgrace')">disgrace</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>)
* 1 Corinthians 04:10-11
* 1 Samuel 20:32-34
* 2 Corinthians 06:8-10
* Ezekiel 22:6-9
* John 08:48-49
* Leviticus 18:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>)
* 1 Kings 13:20-22
* Acts 26:19-21
* Colossians 03:5-8
* Luke 01:16-17
* Luke 06:49
* Psalms 089:30-32
* __Open Bible Stories - 02:11__ God said to the man, "You listened to your wife and __disobeyed__  me."
* __Open Bible Stories - 13:07__ If the people obeyed these laws, God promised that he would bless and protect them. If they __disobeyed__  them, God would punish them.
* __Open Bible Stories - 16:02__ Because the Israelites kept __disobeying__  God, he punished them by allowing their enemies to defeat them.
* __Open Bible Stories - 35:12__ "The older son said to his father, 'All these years I have worked faithfully for you! I never __disobeyed__  you, and still you did not give me one small goat so I could celebrate with my friends.'"
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/persecute')">persecute</a>)
* 1 Peter 01:1-2
* Ezekiel 12:14-16
* Ezekiel 30:22-24
* Psalms 018:13-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/magic')">magic</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sorcery')">sorcery</a>)
* 1 Samuel 06:1-2
* Acts 16:16-18
* Ezekiel 12:24-25
* Genesis 44:3-5
* Jeremiah 27:9-11
* 1 Chronicles 08:8-11
* Leviticus 21:7-9
* Luke 16:18
* Mark 10:1-4
* Matthew 05:31-32
* Matthew 19:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/teach')">teach</a>)
* 1 Timothy 01:3-4
* 2 Timothy 03:16-17
* Mark 07:6-7
* Matthew 15:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
* 1 Kings 01:32-34
* 1 Samuel 09:3-4
* 2 Kings 04:21-22
* Deuteronomy 05:12-14
* Luke 13:15-16
* Matthew 21:1-3
* Ezekiel 07:5-7
* Ezekiel 30:8-9
* Isaiah 06:4-5
* Psalms 092:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/passover')">Passover</a>)
* 1 Kings 06:31-32
* Deuteronomy 11:20-21
* Exodus 12:5-8
* Isaiah 57:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/olive')">olive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/innocent')">innocent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/purify')">pure</a>)
* Genesis 08:8-9
* Luke 02:22-24
* Mark 01:9-11
* Matthew 03:16-17
* Matthew 21:12-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/vision')">vision</a>)
* Acts 02:16-17
* Daniel 01:17-18
* Daniel 02:1-2
* Genesis 37:5-6
* Genesis 40:4-5
* Matthew 02:13-15
* Matthew 02:19-21
* __Open Bible Stories - 08:02__ Joseph's brothers hated him because their father loved him most and because Joseph had __dreamed__ that he would be their ruler.
* __Open Bible Stories - 08:06__ One night, the Pharaoh, which is what the Egyptians called their kings, had two __dreams__ that disturbed him greatly. None of his advisors could tell him the meaning of the __dreams__.
* __Open Bible Stories - 08:07__ God had given Joseph the ability to interpret __dreams__, so Pharaoh had Joseph brought to him from the prison. Joseph interpreted the __dreams__ for him and said, "God is going to send seven years of plentiful harvests followed by seven years of famine."
* __Open Bible Stories - 16:11__ So that night, Gideon went down to the camp and heard a Midianite soldier telling his friend about something he had __dreamed__. The man's friend said, "This __dream__ means that Gideon's army will defeat the Midianite army!"
* __Open Bible Stories - 23:01__ He (Joseph) did not want to shame her (Mary), so he planned to quietly divorce her. Before he could do that, an angel came and spoke to him in a __dream__.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grainoffering')">grain offering</a>)
* Exodus 25:28-30
* Ezekiel 45:16-17
* Genesis 35:14-15
* Jeremiah 07:16-18
* Numbers 05:15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/wine')">wine</a>)
* 1 Corinthians 05:11-13
* 1 Samuel 25:36
* Jeremiah 13:12-14
* Luke 07:33-35
* Luke 21:34-35
* Proverbs 23:19-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/gate')">gate</a>)
* 1 Kings 14:9-10
* 2 Kings 06:24-26
* Isaiah 25:9-10
* Jeremiah 08:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/free')">free</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
* 2 Samuel 01:23-24
* Daniel 07:4-5
* Jeremiah 04:13-15
* Leviticus 11:13-16
* Revelation 04:7-8
* This term is often used figuratively to refer to the people who live on the earth. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metonymy')">metonymy</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/world')">world</a>)
* 1 Kings 01:38-40
* 2 Chronicles 02:11-12
* Daniel 04:35
* Luke 12:51-53
* Matthew 06:8-10
* Matthew 11:25-27
* Zechariah 06:5-6
* 1 Chronicles 11:1-3
* 1 Timothy 03:1-3
* 1 Timothy 04:14-16
* Acts 05:19-21
* Acts 14:23-26
* Mark 11:27-28
* Matthew 21:23-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/perseverance')">persevere</a>)
* 2 Timothy 02:11-13
* James 01:1-3
* James 01:12-13
* Luke 21:16-19
* Matthew 13:20-21
* Revelation 01:9-11
* Romans 05:3-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/free')">free</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>)
* Galatians 04:3-5
* Galatians 04:24-25
* Genesis 15:12-13
* Jeremiah 30:8-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jealous')">jealous</a>)
* 1 Corinthians 13:4-7
* 1 Peter 02:1-3
* Exodus 20:15-17
* Mark 07:20-23
* Proverbs 03:31-32
* Romans 01:29-31
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>)
* 1 Peter 02:13-17
* Isaiah 09:16-17
* Luke 13:25-27
* Malachi 03:13-15
* Matthew 07:21-23
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>)
* 2 Kings 24:13-14
* Daniel 02:25-26
* Ezekiel 01:1-3
* Isaiah 20:3-4
* Jeremiah 29:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/arrogant')">arrogant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/joy')">joy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/praise')">praise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/joy')">rejoice</a>)
* 1 Samuel 02:1
* Isaiah 13:1-3
* Job 06:10-11
* Psalm 068:1-3
* Zephaniah 02:15
* Deuteronomy 05:4-6
* Genesis 33:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fulfill')">fulfill</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* 1 John 04:1-3
* 2 Peter 02:1-3
* Acts 13:6-8
* Luke 06:26
* Matthew 07:15-17
* Matthew 24:23-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/testimony')">testimony</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* Deuteronomy 19:17-19
* Exodus 20:15-17
* Matthew 15:18-20
* Matthew 19:18-19
* Proverbs 14:5-6
* Psalms 027:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/clan')">clan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/house')">house</a>)
* 1 Kings 08:1-2
* 1 Samuel 18:17-18
* Exodus 01:20-22
* Joshua 02:12-13
* Luke 02:4-5
* 1 Chronicles 21:11-12
* Acts 07:11-13
* Genesis 12:10-13
* Genesis 45:4-6
* Jeremiah 11:21-23
* Luke 04:25-27
* Matthew 24:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/jewishleaders')">Jewish leaders</a>)
* 1 Kings 21:8-10
* 2 Chronicles 20:3-4
* Acts 13:1-3
* Jonah 03:4-5
* Luke 05:33-35
* Mark 02:18-19
* Matthew 06:16-18
* Matthew 09:14-15
* __Open Bible Stories - 25:01__ Immediately after Jesus was baptized, the Holy Spirit led him out into the wilderness, where he __fasted__  for forty days and forty nights.
* __Open Bible Stories - 34:08__ "'For example, I __fast__  two times every week and I give you ten percent of all the money and goods that I receive.'"
* __Open Bible Stories - 46:10__ One day, while the Christians at Antioch were __fasting__  and praying, the Holy Spirit said to them, "Set apart for me Barnabas and Saul to do the work I have called them to do."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godthefather')">God the Father</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/son')">son</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sonofgod')">Son of God</a>)
* Acts 07:1-3
* Acts 07:31-32
* Acts 07:44-46
* Acts 22:3-5
* Genesis 31:29-30
* Genesis 31:41-42
* Genesis 31:51-53
* Hebrews 07:4-6
* John 04:11-12
* Joshua 24:3-4
* Malachi 03:6-7
* Mark 10:7-9
* Matthew 01:7-8
* Matthew 03:7-9
* Matthew 10:21-23
* Matthew 18:12-14
* Romans 04:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/festival')">festival</a>)
* 2 Peter 02:12-14
* Genesis 26:30-31
* Genesis 29:21-22
* Genesis 40:20-23
* Jude 01:12-13
* Luke 02:41-44
* Luke 14:7-9
* Matthew 22:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fulfill')">fulfill</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grainoffering')">grain offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/guiltoffering')">guilt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peaceoffering')">peace offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/unleavenedbread')">unleavened bread</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/vow')">vow</a>)
* 1 Chronicles 21:25-27
* 2 Chronicles 29:35-36
* Exodus 24:5-6
* Leviticus 03:3-5
* Numbers 06:13-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/feast')">feast</a>)
* 1 Chronicles 23:30-31
* 2 Chronicles 08:12-13
* Exodus 05:1-2
* John 04:43-45
* Luke 22:1-2
* Habakkuk 03:17
* James 03:11-12
* Luke 13:6-7
* Mark 11:13-14
* Matthew 07:15-17
* Matthew 21:18-19
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/cedar')">cedar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cypress')">cypress</a>)
* Ezekiel 27:4-5
* Isaiah 37:24-25
* Isaiah 41:19-20
* Isaiah 44:14
* Isaiah 60:12-13
* Psalms 104:16-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/purify')">pure</a>)
* 1 Kings 16:18-20
* 2 Kings 01:9-10
* 2 Thessalonians 01:6-8
* Acts 07:29-30
* John 15:5-7
* Luke 03:15-16
* Matthew 03:10-12
* Nehemiah 01:3
* When "first-born" occurs in the text alone, it could also be translated as "firstborn male" or "firstborn son," since that is what is implied. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-explicit')">Assumed Knowledge and Implicit Information</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/inherit')">inherit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/son')">son</a>)
* Colossians 01:15-17
* Genesis 04:3-5
* Genesis 29:26-27
* Genesis 43:32-34
* Luke 02:6-7
* Revelation 01:4-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/firstborn')">firstborn</a>)
* 2 Chronicles 31:4-5
* 2 Thessalonians 02:13-15
* Exodus 23:16-17
* James 01:17-18
* Jeremiah 02:1-3
* Psalms 105:34-36
* Ezekiel 47:9-10
* Isaiah 19:7-8
* Luke 05:1-3
* Matthew 04:18-20
* Matthew 13:47-48
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/goat')">goat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cow')">ox</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/pig')">pig</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, )
* 1 Kings 10:28-29
* 2 Chronicles 17:10-11
* Deuteronomy 14:22-23
* Luke 02:8-9
* Matthew 08:30-32
* Matthew 26:30-32
* This term can be used as a metaphor, as in "do not let the flood sweep over me," which means "do not let these overwhelming disasters happen to me" or "don't let me be devastated by disasters" or "don't let your anger devastate me." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ark')">ark</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/noah')">Noah</a>)
* Daniel 11:10
* Genesis 07:6-7
* Luke 06:46-48
* Matthew 07:24-25
* Matthew 07:26-27
* Matthew 24:37-39
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/flock')">flock</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>)
* 1 Corinthians 14:7-9
* 1 Kings 01:38-40
* Daniel 03:3-5
* Luke 07:31-32
* Matthew 09:23-24
* Matthew 11:16-17
* Acts 07:47-50
* Isaiah 66:1
* Luke 20:41-44
* Matthew 05:33-35
* Matthew 22:43-44
* Psalm 110:1
* 2 Chronicles 02:17-18
* Acts 07:29-30
* Deuteronomy 01:15-16
* Genesis 15:12-13
* Genesis 17:24-27
* Luke 17:17-19
* Matthew 17:24-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/know')">know</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/predestine')">predestine</a>)
* Romans 08:28-30
* Romans 11:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prostitute')">prostitute</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>)
* Acts 15:19-21
* Acts 21:25-26
* Colossians 03:5-8
* Ephesians 05:3-4
* Genesis 38:24-26
* Hosea 04:13-14
* Matthew 05:31-32
* Matthew 19:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/cornerstone')">cornerstone</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/creation')">create</a>)
* 1 Kings 06:37-38
* 2 Chronicles 03:1-3
* Ezekiel 13:13-14
* Luke 14:28-30
* Matthew 13:34-35
* Matthew 25:34-36
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/flood')">flood</a>)
* 2 Peter 02:17-19
* Genesis 07:11-12
* Genesis 08:1-3
* Genesis 24:12-14
* Genesis 24:42-44
* James 03:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/learnedmen')">learned men</a>)
* 1 Chronicles 09:28-29
* Exodus 30:34-36
* Matthew 02:11-12
* Numbers 05:15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bond')">bind</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/enslave')">enslave</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>)
* Galatians 04:26-27
* Galatians 05:1-2
* Isaiah 61:1
* Leviticus 25:10
* Romans 06:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezra')">Ezra</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/feast')">feast</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grainoffering')">grain offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/guiltoffering')">guilt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sinoffering')">sin offering</a>)
* 1 Chronicles 29:6-7
* 2 Chronicles 35:7-9
* Deuteronomy 12:17
* Exodus 36:2-4
* Leviticus 07:15-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grape')">grape</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vine')">vine</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/womb')">womb</a>)
* Galatians 05:22-24
* Genesis 01:11-13
* Luke 08:14-15
* Matthew 03:7-9
* Matthew 07:15-17
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/image')">image</a>)
* 1 Kings 08:51-53
* Genesis 19:26-28
* Proverbs 17:3-4
* Psalms 021:9-10
* Revelation 09:1-2
* Acts 09:23-25
* Acts 10:17-18
* Deuteronomy 21:18-19
* Genesis 19:1-3
* Genesis 24:59-60
* Matthew 07:13-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>)
* Acts 15:19-21
* Exodus 03:13-15
* Genesis 15:14-16
* Genesis 17:7-8
* Mark 08:11-13
* Matthew 11:16-17
* Matthew 23:34-36
* Matthew 24:34-35
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/goliath')">Goliath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>)
* Genesis 06:4
* Numbers 13:32-33
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/loins')">loins</a>)
* 1 Peter 01:13-14
* Job 38:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/boaz')">Boaz</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/harvest')">harvest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ruth')">Ruth</a>)
* Deuteronomy 24:21-22
* Isaiah 17:4-5
* Job 24:5-7
* Ruth 02:1-2
* Ruth 02:15-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/flock')">flock</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wine')">wine</a>)
* Exodus 12:3-4
* Genesis 30:31-32
* Genesis 31:10-11
* Genesis 37:31-33
* Leviticus 03:12-14
* Matthew 25:31-33
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/silver')">silver</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 1 Peter 01:6-7
* 1 Timothy 02:8-10
* 2 Chronicles 01:14-15
* Acts 03:4-6
* Daniel 02:31-33
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/slander')">slander</a>)
* 1 Timothy 05:11-13
* 2 Corinthians 12:20-21
* Leviticus 19:15-16
* Proverbs 16:27-28
* Romans 01:29-31
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/province')">province</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>)
* Acts 07:9-10
* Acts 23:22-24
* Acts 26:30-32
* Mark 13:9-10
* Matthew 10:16-18
* Matthew 27:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/head')">head</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wheat')">wheat</a>)
* Genesis 42:1-4
* Genesis 42:26-28
* Genesis 43:1-2
* Luke 06:1-2
* Mark 02:23-24
* Matthew 13:7-9
* Ruth 01:22
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/guiltoffering')">guilt offering</a> , <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sinoffering')">sin offering</a>)
* 1 Chronicles 23:27-29
* Exodus 29:41-42
* Judges 13:19-20
* Leviticus 02:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/vine')">vine</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vineyard')">vineyard</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wine')">wine</a>)
* Deuteronomy 23:24-25
* Hosea 09:10
* Job 15:31-33
* Luke 06:43-44
* Matthew 07:15-17
* Matthew 21:33-34
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/cry')">cry</a>)
* 2 Corinthians 05:1-3
* Hebrews 13:15-17
* Job 23:1-2
* Psalms 032:3-4
* Psalms 102:5-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grainoffering')">grain offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sinoffering')">sin offering</a>)
* 1 Samuel 06:3-4
* 2 Kings 12:15-16
* Leviticus 05:5-6
* Numbers 06:12
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
* Matthew 27:27-29
* Matthew 28:8-10
* Psalms 078:47-49
* Psalms 148:7-8
* Revelation 08:6-7
* The term "hand" is often used in reference to God's power and action, such as when God says "Has not my hand made all these things?" (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metonymy')">metonymy</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/adversary')">adversary</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bless')">bless</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/captive')">captive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>)
* Acts 07:22-25
* Acts 08:14-17
* Acts 11:19-21
* Genesis 09:5-7
* Genesis 14:19-20
* John 03:34-36
* Mark 07:31-32
* Matthew 06:3-4
* 2 Samuel 17:23
* Acts 10:39-41
* Galatians 03:13-14
* Genesis 40:20-23
* Matthew 27:3-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heart')">heart</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/laborpains')">labor pains</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/stiffnecked')">stiff-necked</a>)
* 2 Corinthians 11:22-23
* Deuteronomy 15:7-8
* Exodus 14:4-5
* Hebrews 04:6-7
* John 12:39-40
* Matthew 19:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fir')">fir</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/psalm')">psalm</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/saul')">Saul (OT)</a>)
* 1 Chronicles 15:16-18
* Amos 05:23-24
* Daniel 03:3-5
* Psalm 033:1-3
* Revelation 05:8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/firstfruit')">firstfruits</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/festival')">festival</a>)
* 1 Corinthians 09:9-11
* 2 Samuel 21:7-9
* Galatians 06:9-10
* Isaiah 17:10-11
* James 05:7-8
* Leviticus 19:9-10
* Matthew 09:37-38
* Ruth 01:22
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/boast')">boast</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/proud')">proud</a>)
* 2 Timothy 03:1-4
* Isaiah 02:17-19
* Proverbs 16:17-18
* Proverbs 21:23-24
* Psalm 131:1
* Another figurative use for "head" is when it is used to represent the whole person, as in "this gray head," referring to an elderly person, or as in "the head of Joseph," which refers to Joseph. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>)
* 1 Chronicles 01:51-54
* 1 Kings 08:1-2
* 1 Samuel 09:22
* Colossians 02:10-12
* Colossians 02:18-19
* Numbers 01:4-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>)
* Acts 05:14-16
* Acts 08:6-8
* Luke 05:12-13
* Luke 06:17-19
* Luke 08:43-44
* Matthew 04:23-25
* Matthew 09:35-36
* Matthew 13:15
* __Open Bible Stories - 19:14__ One of the miracles happened to Naaman, an enemy commander, who had a horrible skin disease. He had heard of Elisha so he went and asked Elisha to __heal__ him.
* __Open Bible Stories - 21:10__ He (Isaiah) also predicted that the Messiah would __heal__ sick people and those who could not hear, see, speak, or walk.
* __Open Bible Stories - 26:06__ Jesus continued saying, "And during the time of the prophet Elisha, there were many people in Israel with skin diseases. But Elisha did not __heal__ any of them. He only __healed__ the skin disease of Naaman, a commander of Israel's enemies."
* __Open Bible Stories - 26:08__ They brought many people who were sick or handicapped, including those who could not see, walk, hear, or speak, and Jesus __healed__ them.
* __Open Bible Stories - 32:14__ She had heard that Jesus had __healed__ many sick people and thought, "I'm sure that if I can just touch Jesus' clothes, then I will be __healed__, too!"
* __Open Bible Stories - 44:03__ Immediately, God __healed__ the lame man, and he began to walk and jump around, and to praise God.
* __Open Bible Stories - 44:08__ Peter answered them, "This man stands before you __healed__ by the power of Jesus the Messiah."
* __Open Bible Stories - 49:02__ ] Jesus did many miracles that prove he is God. He walked on water, calmed storms, __healed__ many sick people, drove out demons, raised the dead to life, and turned five loaves of bread and two small fish into enough food for over 5,000 people.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/firstborn')">firstborn</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/inherit')">inherit</a>)
* Galatians 04:1-2
* Galatians 04:6-7
* Genesis 15:1-3
* Genesis 21:10-11
* Luke 20:13-14
* Mark 12:6-7
* Matthew 21:38-39
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* 1 Samuel 09:12-13
* 2 Kings 16:3-4
* Amos 04:12-13
* Deuteronomy 33:29
* Ezekiel 06:1-3
* Habakkuk 03:18-19
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>)
* Matthew 04:5-6
* Matthew 27:51-53
* Revelation 21:1-2
* Revelation 21:9-10
* Revelation 22:18-19
* This term is often used figuratively to describe something that is sweet or very pleasurable. For example, God's words and decrees are said to be "sweeter than honey." (See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-simile')">Simile</a>, <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jonathan')">Jonathan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samson')">Samson</a>)
* 1 Kings 14:1-3
* Deuteronomy 06:3
* Exodus 13:3-5
* Joshua 05:6-7
* Proverbs 05:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/camel')">camel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cow')">cow, ox</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/donkey')">donkey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/goat')">goat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/pig')">pig</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>)
* Deuteronomy 14:6-7
* Ezekiel 26:9-11
* Leviticus 11:3-4
* Psalms 069:30-31
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cow')">cow</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/deer')">deer</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/goat')">goat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a> <a style="cursor: pointer" onclick="return followLink('en/tw/other/royal')">royal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/trumpet')">trumpet</a>)
* 1 Chronicles 15:27-28
* 1 Kings 01:38-40
* 2 Samuel 22:3-4
* Jeremiah 17:1-2
* Psalms 022:20-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fear')">fear</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/terror')">terror</a>)
* Deuteronomy 28:36-37
* Ezekiel 23:33-34
* Jeremiah 02:12-13
* Job 21:4-6
* Psalms 055:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/chariot')">chariot</a>, , <a style="cursor: pointer" onclick="return followLink('en/tw/other/donkey')">donkey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>)
* 1 Chronicles 18:3-4
* 2 Kings 02:11-12
* Exodus 14:23-25
* Ezekiel 23:5-7
* Zechariah 06:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/chariot')">chariot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/horse')">horse</a>)
* 1 Kings 01:5-6
* Daniel 11:40-41
* Exodus 14:23-25
* Genesis 50:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/biblicaltimehour')">hour</a>)
* 1 Corinthians 15:29-30
* Acts 10:30-33
* Mark 14:35-36
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/houseofgod')">house of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/household')">household</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* Acts 07:41-42
* Acts 07:47-50
* Genesis 39:3-4
* Genesis 41:39-41
* Luke 08:38-39
* Matthew 10:5-7
* Matthew 15:24-26
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/house')">house</a>)
* Acts 07:9-10
* Galatians 06:9-10
* Genesis 07:1-3
* Genesis 34:18-19
* John 04:53-54
* Matthew 10:24-25
* Matthew 10:34-36
* Philippians 04:21-23
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/disgrace')">disgrace</a> **·** <a style="cursor: pointer" onclick="return followLink('en/tw/kt/humble')">humble</a> **·** <a style="cursor: pointer" onclick="return followLink('en/tw/other/shame')">shame</a>)
* Deuteronomy 21:13-14
* Ezra 09:5-6
* Proverbs 25:7-8
* Psalms 006:8-10
* Psalms 123:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/god')">God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/imageofgod')">image of God</a>)
* 1 Kings 14:9-10
* Acts 07:43
* Isaiah 21:8-9
* Matthew 22:20-22
* Romans 01:22-23
* 3 John 01:11-12
* Matthew 23:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/altarofincense')">altar of incense</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/frankincense')">frankincense</a>)
* 1 Kings 03:1-3
* 2 Chronicles 13:10-11
* 2 Kings 14:4-5
* Exodus 25:3-7
* Luke 01:8-10
* Deuteronomy 19:17-19
* Ezekiel 20:1
* Ezekiel 20:30-32
* Ezra 07:14-16
* Job 10:4-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/decree')">decree</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/teach')">teach</a>)
* Exodus 14:4-5
* Genesis 26:4-5
* Hebrews 11:20-22
* Matthew 10:5-7
* Matthew 11:1-3
* Proverbs 01:28-30
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/josephot')">Joseph (OT)</a>)
* 1 Kings 09:4-5
* Job 02:3
* Job 04:4-6
* Proverbs 10:8-9
* Psalm 026:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/dream')">dream</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vision')">vision</a>)
* 1 Corinthians 12:9-11
* Daniel 04:4-6
* Genesis 40:4-5
* Judges 07:15-16
* Luke 12:54-56
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/chiefpriests')">chief priests</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/council')">council</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pharisee')">Pharisee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sadducee')">Sadducee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/scribe')">scribe</a>)
* Exodus 16:22-23
* John 02:17-19
* John 05:10-11
* John 05:16-18
* Luke 19:47-48
* __Open Bible Stories - 24:03__ Many __religious leaders__ also came to be baptized by John, but they did not repent or confess their sins.
* __Open Bible Stories - 37:11__ But the __religious leaders of the Jews__ were jealous, so they gathered together to plan how they could kill Jesus and Lazarus.
* __Open Bible Stories - 38:02__ He (Judas) knew that the __Jewish leaders__ denied that Jesus was the Messiah and that they were plotting to kill him.
* __Open Bible Stories - 38:03__ The __Jewish leaders__, led by the high priest, paid Judas thirty silver coins to betray Jesus.
* __Open Bible Stories - 39:05__ The __Jewish leaders__ all answered the high priest, "He (Jesus) deserves to die!"
* __Open Bible Stories - 39:09__ Early the next morning, the __Jewish leaders__ brought Jesus to Pilate, the Roman governor.
* __Open Bible Stories - 39:11__ But the __Jewish leaders__ and the crowd shouted, "Crucify him!"
* __Open Bible Stories - 40:09__ Then Joseph and Nicodemus, two __Jewish leaders__ who believed Jesus was the Messiah, asked Pilate for Jesus' body.
* __Open Bible Stories - 44:07__ The next day, the __Jewish leaders__ brought Peter and John to the high priest and the other __religious leaders__.
* A "joyful city" or "joyful house" could be translated as "city where joyful people live" or "house full of joyful people" or "city whose people are very happy." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metonymy')">metonymy</a>)
* Nehemiah 08:9-10
* Psalm 048:1-3
* Isaiah 56:6-7
* Jeremiah 15:15-16
* Matthew 02:9-10
* Luke 15:6-7
* Luke 19:37-38
* John 03:29-30
* Acts 16:32-34
* Romans 05:1-2
* Romans 15:30-32
* Galatians 05:22-24
* Philippians 04:10-13
* 1 Thessalonians 01:6-7
* 1 Thessalonians 05:15-18
* Philemon 01:4-7
* James 01:1-3
* 3 John 01:1-4
* __Open Bible Stories - 33:07__ "The rocky ground is a person who hears God's word and accepts it with __joy__."
* __Open Bible Stories - 34:04__ "The kingdom of God is also like hidden treasure that someone hid in a field.. Another man found the treasure and then buried it again. He was so filled with __joy__, that he went and sold everything he had and used the money to buy that field."
* __Open Bible Stories - 41:07__ The women were full of fear and great __joy__. They ran to tell the disciples the good news.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>)
* Galatians 01:13-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/governor')">governor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>)
* 2 Timothy 04:6-8
* Acts 07:26-28
* Luke 11:18-20
* Luke 12:13-15
* Luke 18:1-2
* Matthew 05:25-26
* Ruth 01:1-2
* Romans 16:9-11
* Ruth 02:19-20
* Ruth 03:8-9
* Genesis 01:20-21
* Genesis 01:24-25
* Mark 09:28-29
* Matthew 13:47-48
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/herodantipas')">Herod Antipas</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingdomofgod')">kingdom of God</a>)
* 1 Timothy 06:15-16
* 2 Kings 05:17-19
* 2 Samuel 05:3-5
* Acts 07:9-10
* Acts 13:21-22
* John 01:49-51
* Luke 01:5-7
* Luke 22:24-25
* Matthew 05:33-35
* Matthew 14:8-9
* __Open Bible Stories - 08:06__  One night, the Pharaoh, which is what the Egyptians called their kings, had two dreams that disturbed him greatly.
* __Open Bible Stories - 16:01__  The Israelites had no __king__, so everyone did what they thought was right for them.
* __Open Bible Stories - 16:18__  Finally, the people asked God for a __king__ like all the other nations had.
* __Open Bible Stories - 17:05__  Eventually, Saul died in battle, and David became __king__ of Israel. He was a good __king__, and the people loved him.
* __Open Bible Stories - 21:06__  God's prophets also said that the Messiah would be a prophet, a priest, and a __king__.
* __Open Bible Stories - 48:14__  David was the __king__ of Israel, but Jesus is the __king__ of the entire universe!
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingdomofgod')">kingdom of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofisrael')">kingdom of Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/kingdomofjudah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* 1 Thessalonians 02:10-12
* 2 Timothy 04:17-18
* Colossians 01:13-14
* John 18:36-37
* Mark 03:23-25
* Matthew 04:7-9
* Matthew 13:18-19
* Matthew 16:27-28
* Revelation 01:9-11
* __Open Bible Stories - 13:02__ God said to Moses and the people of Israel, "If you will obey me and keep my covenant, you will be my prized possession, a __kingdom__  of priests, and a holy nation."
* __Open Bible Stories - 18:04__ God was angry with Solomon and, as a punishment for Solomon's unfaithfulness, he promised to divide the nation of Israel in two __kingdoms__  after Solomon's death.
* __Open Bible Stories - 18:07__ Ten of the tribes of the nation of Israel rebelled against Rehoboam. Only two tribes remained faithful to him. These two tribes became the __kingdom__  of Judah.
* __Open Bible Stories - 18:08__ The other ten tribes of the nation of Israel that rebelled against Rehoboam appointed a man named Jeroboam to be their king. They set up their __kingdom__  in the northern part of the land and were called the __kingdom__  of Israel.
* __Open Bible Stories - 21:08__ A king is someone who rules over a __kingdom__  and judges the people.
* 1 Thessalonians 05:25-28
* Genesis 27:26-27
* Genesis 29:11-12
* Genesis 31:26-28
* Genesis 45:14-15
* Genesis 48:8-10
* Luke 22:47-48
* Mark 14:43-46
* Matthew 26:47-48
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/reveal')">reveal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/understand')">understand</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wise')">wise</a>)
* 1 Corinthians 02:12-13
* 1 Samuel 17:46-47
* 2 Corinthians 02:14-15
* 2 Peter 01:3-4
* Deuteronomy 04:39-40
* Genesis 19:4-5
* Luke 01:76-77
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/hard')">hard</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/laborpains')">labor pains</a>)
* 1 Thessalonians 02:7-9
* 1 Thessalonians 03:4-5
* Galatians 04:10-11
* James 05:4-6
* John 04:37-38
* Luke 10:1-2
* Matthew 10:8-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/labor')">labor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lastday')">last day</a>)
* 1 Samuel 04:19-20
* Galatians 04:19-20
* Isaiah 13:6-8
* Jeremiah 13:20-21
* Psalms 048:4-6
* Romans 08:20-22
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/lampstand')">lampstand</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/light')">light</a>)
* 1 Kings 11:34-36
* Exodus 25:3-7
* Luke 08:16-18
* Matthew 05:15-16
* Matthew 06:22-24
* Matthew 25:1-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bronze')">bronze</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/gold')">gold</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/lamp')">lamp</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/light')">light</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/silver')">silver</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* Daniel 05:5-6
* Exodus 37:17-19
* Mark 04:21-23
* Matthew 05:15-16
* Revelation 01:12-13
* Revelation 01:19-20
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>)
* Deuteronomy 04:1-2
* Esther 03:8-9
* Exodus 12:12-14
* Genesis 26:4-5
* John 18:31-32
* Romans 07:1
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sabbath')">Sabbath</a>)
* Matthew 07:21-23
* Matthew 12:1-2
* Matthew 12:3-4
* Matthew 12:9-10
* Mark 03:3-4
* Luke 06:1-2
* Acts 02:22-24
* Acts 10:27-29
* Acts 22:25-26
* 2 Thessalonians 02:3-4
* Titus 02:14
* 1 John 03:4-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/bethlehem')">Bethlehem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>)
* Daniel 02:27-28
* Daniel 05:7
* Matthew 02:1-3
* Matthew 02:7-8
* Matthew 02:16
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/beast')">beast</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prey')">prey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vision')">vision</a>)
* Daniel 07:6-7
* Hosea 13:7-8
* Revelation 13:1-2
* Song of Solomon 04:8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/miriam')">Miriam</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/naaman')">Naaman</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>)
* Luke 05:12-13
* Luke 17:11-13
* Mark 01:40-42
* Mark 14:3-5
* Matthew 08:1-3
* Matthew 10:8-10
* Matthew 11:4-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/courage')">encourage</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/exhort')">exhort</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/teach')">teach</a>)
* 1 Thessalonians 05:25-28
* 2 Thessalonians 02:13-15
* Acts 09:1-2
* Acts 28:21-22
There are several figurative uses of the term "light" in the Bible. It is often used as a metaphor for righteousness, holiness, and truth. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/darkness')">darkness</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* 1 John 01:5-7
* 1 John 02:7-8
* 2 Corinthians 04:5-6
* Acts 26:15-18
* Isaiah 02:5-6
* John 01:4-5
* Matthew 05:15-16
* Matthew 06:22-24
* Nehemiah 09:12-13
* Revelation 18:23-24
* The word "like" is also often used in a figurative expressions called a "simile" in which something is compared to something else, usually highlighting a shared characteristic. For example, "his clothes shined like the sun" and "the voice boomed like thunder." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-simile')">Simile</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/beast')">beast</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/flesh')">flesh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/imageofgod')">image of God</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/image')">image</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/perish')">perish</a>)
* Ezekiel 01:4-6
* Mark 08:24-26
* Matthew 17:1-2
* Matthew 18:1-3
* Psalms 073:4-5
* Revelation 01:12-13
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/david')">David</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/leopard')">leopard</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samson')">Samson</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>)
* 1 Chronicles 11:22-23
* 1 Kings 07:27-29
* Proverbs 19:11-12
* Psalms 017:11-12
* Revelation 05:3-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/cow')">cow, ox</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/donkey')">donkey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/goat')">goat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/horse')">horse</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>) 
* 2 Kings 03:15-17
* Genesis 30:29-30
* Joshua 01:14-15
* Nehemiah 09:36-37
* Numbers 03:40-41
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/captive')">captive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/plague')">plague</a>)
* 2 Chronicles 06:28-31
* Deuteronomy 28:38-39
* Exodus 10:3-4
* Mark 01:4-6
* Proverbs 30:27-28
* In the Bible, the term "loins" often refers figuratively and euphemistically to a man's reproductive organs as the source of his descendants. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">euphemism</a>)
* The expression "will come from your loins" could also be translated as, "will be your offspring" or "will be born from your seed" or "God will cause to come from you." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">euphemism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/gird')">gird</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/offspring')">offspring</a>)
* 1 Peter 01:13-14
* 2 Chronicles 06:7-9
* Deuteronomy 33:11
* Genesis 37:34-36
* Job 15:27-28
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/elizabeth')">Elizabeth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahot')">Zechariah (OT)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/zechariahnt')">Zechariah (NT)</a>)                                                  
* Jonah 01:6-7
* Luke 01:8-10
* Luke 23:33-34
* Mark 15:22-24
* Matthew 27:35-37
* Psalms 022:18-19
* This wrong sexual relationship is often used in the Bible to refer to Israel's disobedience to God in worshiping idols. So the term "lovers" is also used in a figurative way to refer to the idols that the people of Israel worshiped. In these contexts, this term could possibly be translated by "immoral partners" or "partners in adultery" or "idols." [See  Metaphor]
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/love')">love</a>)
* Hosea 02:4-5
* Jeremiah 03:1-2
* Lamentations 01:1-2
* Luke 16:14-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/humble')">humble</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/proud')">proud</a>)
* Acts 20:17-21
* Ezekiel 17:13-14
* Luke 01:48-49
* Romans 12:14-16
 (See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>) 
* 1 John 02:15-17
* 2 Timothy 02:22-23
* Galatians 05:16-18
* Galatians 05:19-21
* Genesis 39:7-9
* Matthew 05:27-28
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/harp')">harp</a>)
* 1 Kings 10:11-12
* 1 Samuel 10:5-6
* 2 Chronicles 05:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/divination')">divination</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/pharaoh')">Pharaoh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sorcery')">sorcery</a>)
* Genesis 41:7-8
* Genesis 41:22-24
* Genesis 44:3-5
* Genesis 44:14-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/judgeposition')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>)
* Acts 16:19-21
* Acts 16:35-36
* Daniel 03:1-2
* Luke 12:57-59
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>)
* 1 Timothy 03:4-5
* Genesis 39:3-4
* Genesis 43:16-17
* Isaiah 55:10-11
* Luke 08:1-3
* Luke 16:1-2
* Matthew 20:8-10
* Titus 01:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* Ezekiel 44:30-31
* Joel 02:14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/reconcile')">reconcile</a>)
* 1 Timothy 02:5-7
* Galatians 03:19-20
* Hebrews 08:6-7
* Hebrews 12:22-24
* Luke 12:13-15
* Genesis 24:63-65
* Joshua 01:8-9
* Psalm 001:1-2
* Psalms 119:15-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/humble')">humble</a>)
* 1 Peter 03:15-17
* 2 Corinthians 10:1-2
* 2 Timothy 02:24-26
* Matthew 05:5-8
* Matthew 11:28-30
* Psalms 037:11-13
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heart')">heart</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/image')">image</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/seal')">seal</a>)
* Psalms 112:10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/body')">body</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pharisee')">Pharisee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/council')">council</a>)
* 1 Corinthians 06:14-15
* 1 Corinthians 12:14-17
* Numbers 16:1-3
* Romans 12:4-5
* Acts 10:3-6
* Exodus 12:12-14
* Isaiah 66:3
* Joshua 04:6-7
* Leviticus 23:23-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>)
* 1 Kings 19:1-3
* 1 Samuel 06:21
* 2 Kings 01:1-2
* Luke 07:27-28
* Matthew 11:9-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/almighty')">Almighty</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/miracle')">miracle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/strength')">strength</a>)
* Acts 07:22-25
* Genesis 06:4
* Mark 09:38-39
* Matthew 11:23-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heart')">heart</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/soul')">soul</a>)
* Luke 10:25-28
* Mark 06:51-52
* Matthew 21:28-30
* Matthew 22:37-38
* James 04:08
* 2 Peter 03:3-4
* Acts 02:12-13
* Galatians 06:6-8
* Genesis 39:13-15
* Luke 22:63-65
* Mark 10:32-34
* Matthew 09:23-24
* Matthew 20:17-19
* Matthew 27:27-29
* __Open Bible Stories - 21:12__ Isaiah prophesied that people would spit on, __mock__, and beat the Messiah. 
* __Open Bible Stories - 39:05__ The Jewish leaders all answered the high priest, "He deserves to die!" Then they blindfolded Jesus, spit on him, hit him, and __mocked__ him.
* __Open Bible Stories - 39:12__ The soldiers whipped Jesus, and put a royal robe and a crown made of thorns on him. Then they __mocked__ him by saying, "Look, the King of the Jews!"
* __Open Bible Stories - 40:04__ Jesus was crucified between two robbers. One of them __mocked__ Jesus, but the other said, "Do you have no fear of God?"
* __Open Bible Stories - 40:05__ The Jewish leaders and the other people in the crowd __mocked__ Jesus. They said to him, "If you are the Son of God, come down from the cross and save yourself! Then we will believe you."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/gold')">gold</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/silver')">silver</a>)
* Exodus 32:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/sackcloth')">sackcloth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* 1 Samuel 15:34-35
* 2 Samuel 01:11-13
* Genesis 23:1-2
* Luke 07:31-32
* Matthew 11:16-17
* Deuteronomy 08:1-2
* Genesis 09:5-7
* Genesis 22:15-17
* Hosea 04:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gentile')">Gentile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* Colossians 04:2-4
* Ephesians 06:19-20
* Luke 08:9-10
* Mark 04:10-12
* Matthew 13:10-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gentile')">Gentile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/greek')">Greek</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peoplegroup')">people group</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philistines')">Philistines</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* 1 Chronicles 14:15-17
* 2 Chronicles 15:6-7
* 2 Kings 17:11-12
* Acts 02:5-7
* Acts 13:19-20
* Acts 17:26-27
* Acts 26:4-5
* Daniel 03:3-5
* Genesis 10:2-5
* Genesis 27:29
* Genesis 35:11-13
* Genesis 49:10
* Luke 07:2-5
* Mark 13:7-8
* Matthew 21:43-44
* Romans 04:16-17
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/adversary')">adversary</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/parable')">parable</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peoplegroup')">people group</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>)
* Acts 07:26-28
* Ephesians 04:25-27
* Galatians 05:13-15
* James 02:8-9
* John 09:8-9
* Luke 01:56-58
* Matthew 05:43-45
* Matthew 19:18-19
* Matthew 22:39-40
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/biblicaltimemonth')">month</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/earth')">earth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/festival')">festival</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/horn')">horn</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>)
* 1 Chronicles 23:30-31
* 1 Samuel 20:4-5
* 2 Kings 04:23-24
* Ezekiel 45:16-17
* Isaiah 01:12-13
* 2 Chronicles 23:20-21
* Daniel 04:36-37
* Ecclesiastes 10:16-17
* Luke 19:11-12
* Psalm 016:1-3
* See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>)
* 1 Samuel 10:3-4
* Genesis 13:16-18
* Genesis 14:13-14
* Genesis 35:4-5
* Judges 06:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abimelech')">Abimelech</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/vow')">vow</a>)
* Genesis 21:22-24
* Genesis 24:1-4
* Genesis 31:51-53
* Genesis 47:29-31
* Luke 01:72-75
* Mark 06:26-29
* Matthew 05:36-37
* Matthew 14:6-7
* Matthew 26:71-72
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/citizen')">citizen</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>)
* Acts 05:29-32
* Acts 06:7
* Genesis 28:6-7
* James 01:22-25
* James 02:10-11
* Luke 06:46-48
* Matthew 07:26-27
* Matthew 19:20-22
* Matthew 28:20
* __Open Bible Stories - 03:04__ Noah __obeyed__  God. He and his three sons built the boat just the way God had told them.
* __Open Bible Stories - 05:06__ Again Abraham __obeyed__  God and prepared to sacrifice his son.
* __Open Bible Stories - 05:10__ "Because you (Abraham) have __obeyed __  me, all the families of the world will be blessed through your family"
* __Open Bible Stories - 05:10__ But the Egyptians did not believe God or __obey__  his commands.
* __Open Bible Stories - 13:07__ If the people __obeyed__  these laws, God promised that he would bless and protect them.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/seed')">seed</a>)
* Acts 17:28-29
* Exodus 13:11-13
* Genesis 24:5-7
* Isaiah 41:8-9
* Job 05:23-25
* Luke 03:7
* Matthew 12:33-35
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/olive')">olive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>)
* 2 Samuel 01:21-22
* Exodus 29:1-2
* Leviticus 05:11
* Leviticus 08:1-3
* Mark 06:12-13
* Matthew 25:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/lamp')">lamp</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mediterranean')">the sea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mountofolives')">Mount of Olives</a>)
* 1 Chronicles 27:28-29
* Deuteronomy 06:10-12
* Exodus 23:10-11
* Genesis 08:10-12
* James 03:11-12
* Luke 16:5-7
* Psalms 052:8-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/heaven')">heaven</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>)
* Lamentations 01:13-14
* Psalms 069:28-29
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bond')">bind</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/enslave')">enslave</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/persecute')">persecute</a>)
* 1 Samuel 10:17-19
* Deuteronomy 26:6-7
* Ecclesiastes 04:1
* Job 10:1-3
* Judges 02:18-19
* Nehemiah 05:14-15
* Psalms 119:133-134
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/decree')">decree</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>)
* 1 Kings 12:31-32
* 2 Samuel 17:13-14
* Exodus 28:40-41
* Numbers 03:3-4
* Psalms 111:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/decree')">decree</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ordain')">ordain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/statute')">statute</a>)
* Deuteronomy 04:13-14
* Exodus 27:20-21
* Leviticus 08:31-33
* Malachi 03:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/elder')">elder</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pastor')">pastor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>)
* 1 Chronicles 26:31-32
* 1 Timothy 03:1-3
* Acts 20:28-30
* Genesis 41:33-34
* Philippians 01:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bless')">bless</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/curse')">curse</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prey')">prey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>)
* 2 Kings 25:4-5
* John 12:34-36
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Corinthians 10:20-22
* 1 Corinthians 12:1-3
* 2 Kings 17:14-15
* 2 Kings 21:4-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/courtyard')">courtyard</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/highpriest')">high priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>)
* 2 Chronicles 28:7-8
* 2 Samuel 11:2-3
* Daniel 05:5-6
* Matthew 26:3-5
* Psalms 045:8-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/donkey')">donkey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/jerusalem')">Jerusalem</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peace')">peace</a>) 
* 1 Kings 06:29-30
* Ezekiel 40:14-16
* John 12:12-13
* Numbers 33:8-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/favor')">favor</a>)
* Deuteronomy 01:17-18
* Malachi 02:8-9
* Mark 12:13-15
* Matthew 22:15-17
* Romans 02:10-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/endure')">endure</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/perseverance')">persevere</a>)
* 1 Peter 03:18-20
* 2 Peter 03:8-9
* Hebrews 06:11-12
* Matthew 18:28-29
* Psalms 037:7
* Revelation 02:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor, father, forefather</a>)
* Acts 02:29-31
* Acts 07:6-8
* Acts 07:9-10
* Ezra 03:12-13
* 1 Thessalonians 05:1-3
* Acts 07:26-28
* Colossians 01:18-20
* Colossians 03:15-17
* Galatians 05:22-24
* Luke 07:48-50
* Luke 12:51-53
* Mark 04:38-39
* Matthew 05:9-10
* Matthew 10:11-13
* __Open Bible Stories - 15:06__ God had commanded the Israelites not to make a __peace__ treaty with any of the people groups in Canaan.  
* __Open Bible Stories - 15:12__ Then God gave Israel __peace__ along all its borders. 
* __Open Bible Stories - 16:03__ Then God provided a deliverer who rescued them from their enemies and brought __peace__ to the land. 
* __Open Bible Stories - 21:13__ He (Messiah) would die to receive the punishment for other people's sin. His punishment would bring __peace__ between God and people. 
* __Open Bible Stories - 48:14__ David was the king of Israel, but Jesus is the king of the entire universe! He will come again and rule his kingdom with justice and __peace__, forever.
* __Open Bible Stories - 50:17__ Jesus will rule his kingdom with __peace__ and justice, and he will be with his people forever.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fellowship')">fellowship</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fellowshipoffering')">fellowship offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grainoffering')">grain offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/unleavenedbread')">unleavened bread</a>)
* 1 Samuel 13:8-10
* Ezekiel 45:16-17
* Joshua 08:30-32
* Leviticus 09:3-5
* Proverbs 07:13-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/nation')">nation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tribe')">tribe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/world')">world</a>)
* 1 Kings 08:51-53
* 1 Samuel 08:6-7
* Deuteronomy 28:9-10
* Genesis 49:16-18
* Ruth 01:16-18
* __Open Bible Stories - 14:02__ God had promised Abraham, Isaac, and Jacob that he would give the Promised Land to their descendants, but now there were many __people groups__  living there. what follows is
* __Open Bible Stories - 21:02__ God promised Abraham that through him all __people groups__  of the world would receive a blessing. This blessing would be that the Messiah would come sometime in the future and provide the way of salvation for people from all the __people groups__  of the world.
* __Open Bible Stories - 42:08__ "It was also written in the scriptures that my disciples will proclaim that everyone should repent in order to receive forgiveness for their sins. They will do this starting in Jerusalem, and then go to all __people groups__  everywhere."
* __Open Bible Stories - 42:10__ "So go, make disciples of all __people groups__  by baptizing them in the name of the Father, the Son, and the Holy Spirit and by teaching them to obey everything I have commanded you."
* __Open Bible Stories - 48:11__ Because of this New Covenant, anyone from any __people group__  can become part of God's people by believing in Jesus.
* __Open Bible Stories - 50:03__ He (Jesus) said, "Go and make disciples of all __people groups__!" and, "The fields are ripe for harvest!"
* Hebrews 12:1-3
* James 03:1-2
* Matthew 05:46-48
* Psalms 019:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christian')">Christian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/oppress')">oppress</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>)
* Acts 07:51-53
* Acts 13:50-52
* Galatians 01:13-14
* John 05:16-18
* Mark 10:29-31
* Matthew 05:9-10
* Matthew 05:43-45
* Matthew 10:21-23
* Matthew 13:20-21
* Philippians 03:6-7
* __Open Bible Stories - 33:07__ "The rocky ground is a person who hears God's word and accepts it with joy. But when he experiences hardship or __persecution__, he falls away."
* __Open Bible Stories - 45:06__ That day many people in Jerusalem started __persecuting__ the followers of Jesus, so the believers fled to other places. 
* __Open Bible Stories - 46:02__ Saul heard someone say, "Saul! Saul! Why do you __persecute__ me?" Saul asked, "Who are you, Master?" Jesus replied to him, "I am Jesus. You are __persecuting__ me!"
* __Open Bible Stories - 46:04__ But Ananias said, "Master, I have heard how this man has __persecuted__ the believers."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/patient')">patient</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/trial')">trial</a>)
* Colossians 01:11-12
* Ephesians 06:17-18
* James 05:9-11
* Luke 08:14-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/corrupt')">corrupt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/deceive')">deceive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/turn')">turn</a>)
* 1 Kings 08:46-47
* 1 Samuel 20:30-31
* Job 33:27-28
* Luke 23:1-2
* Psalms 101:4-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/cross')">cross</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/simeon')">Simeon</a>)
* Job 16:13-14
* Job 20:23-25
* John 19:36-37
* Psalms 022:16-17
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>)
* 2 Peter 02:20-22
* Mark 05:11-13
* Matthew 07:6
* Matthew 08:30-32
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/foundation')">foundation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/image')">image</a>)
* 2 Kings 18:4-5
* Exodus 13:19-22
* Exodus 33:7-9
* Genesis 31:45-47
* Proverbs 09:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/abyss')">abyss</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/hell')">hell</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prison')">prison</a>)
* Genesis 37:21-22
* Job 33:16-18
* Luke 06:39-40
* Proverbs 01:12-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/hail')">hail</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/pharaoh')">Pharaoh</a>)
* 2 Samuel 24:13-14
* Exodus 09:13-14
* Genesis 12:17-20
* Luke 21:10-11
* Revelation 09:18-19
* 2 Corinthians 08:3-5
* Judges 06:31-32
* Luke 04:38-39
* Proverbs 18:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/promise')">promise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/oath')">oath</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/vow')">vow</a>)
* 2 Corinthians 05:4-5
* Exodus 22:25-27
* Genesis 38:17-18
* Nehemiah 10:28-29
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bronze')">bronze</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cow')">ox</a>)
* 1 Samuel 08:10-12
* Deuteronomy 21:3-4
* Luke 09:61-62
* Luke 17:7-8
* Psalm 141:5-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bronze')">bronze</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 2 Kings 25:16-17
* Deuteronomy 08:7-8
* Jeremiah 52:22-23
* Numbers 13:23-24
* <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* 1 Chronicles 06:70
* 1 Kings 09:17-19
* Acts 02:43-45
* Deuteronomy 04:5-6
* Genesis 31:36-37
* Matthew 13:44-46
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* 2 Corinthians 01:3-4
* Acts 02:46-47
* Acts 13:48-49
* Daniel 03:28
* Ephesians 01:3-4
* Genesis 49:8
* James 03:9-10
* John 05:41-42
* Luke 01:46-47
* Luke 01:64-66
* Luke 19:37-38
* Matthew 11:25-27
* Matthew 15:29-31
* __Open Bible Stories - 12:13__ The Israelites sang many songs to celebrate their new freedom and to __praise__ God because he saved them from the Egyptian army.
* __Open Bible Stories - 17:08__ When David heard these words, he immediately thanked and __praised__ God because he had promised David this great honor and many blessings. 
* __Open Bible Stories - 22:07__ Zechariah said, "__Praise__ God, because he has remembered his people!
* __Open Bible Stories - 43:13__ They (disciples) enjoyed __praising__ God together and they shared everything they had with each other.
* __Open Bible Stories - 47:08__ They put Paul and Silas in the most secure part of the prison and even locked up their feet. Yet in the middle of the night, they were singing songs of __praise__ to God.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/kingdomofgod')">kingdom of God</a>)
* 2 Timothy 04:1-2
* Acts 08:4-5
* Acts 10:42-43
* Acts 14:21-22
* Acts 20:25-27
* Luke 04:42-44
* Matthew 03:1-3
* Matthew 04:17
* Matthew 12:41
* Matthew 24:12-14
* Acts 09:20-22
* Acts 13:38-39
* Jonah 03:1-3
* Luke 04:18-19
* Mark 01:14-15
* Matthew 10:26-27
* __Open Bible Stories - 24:02__ He (John) __preached__ to them, saying, "Repent, for the Kingdom of God is near!"
* __Open Bible Stories - 30:01__ Jesus sent his apostles to __preach__ and to teach people in many different villages. 
* __Open Bible Stories - 38:01__ About three years after Jesus first began __preaching__ and teaching publicly, Jesus told his disciples that he wanted to celebrate this Passover with them in Jerusalem, and that he would be killed there.
* __Open Bible Stories - 45:06__ But in spite of this, they __preached__ about Jesus everywhere they went.
* __Open Bible Stories - 45:07__ He (Philip) went to Samaria where he preached about Jesus and many people were saved. 
* __Open Bible Stories - 46:06__ Right away, Saul began __preaching__ to the Jews in Damascus, saying, "Jesus is the Son of God!" 
* __Open Bible Stories - 46:10__ Then they sent them off to __preach__ the good news of Jesus in many other places. 
* __Open Bible Stories - 47:14__ Paul and other Christian leaders traveled to many cities, __preaching__ and teaching people the good news about Jesus. 
* __Open Bible Stories - 50:02__ When Jesus was living on earth he said, "My disciples will __preach__ the good news about the kingdom of God to people everywhere in the world, and then the end will come."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/gold')">gold</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/silver')">silver</a>)
* 2 Peter 01:1-2
* Acts 20:22-24
* Daniel 11:38-39
* Lamentations 01:7
* Luke 07:2-5
* Psalms 036:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/oppress')">oppress</a>)
* Jeremiah 12:7-9
* Psalms 104:21-22
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/savior')">Savior</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* Acts 05:29-32
* Genesis 12:14-16
* Genesis 49:26
* Luke 01:52-53
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/captive')">captive</a>)
* Acts 25:4-5
* Ephesians 04:1-3
* Luke 12:57-59
* Luke 22:33-34
* Mark 06:16-17
* Matthew 05:25-26
* Matthew 14:3-5
* Matthew 25:34-36
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/defile')">defile</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holy')">holy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/clean')">clean</a>)
* 2 Timothy 02:16-18
* Ezekiel 20:8-9
* Malachi 01:10-12
* Matthew 12:5-6
* Numbers 18:30-32
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worthy')">worthy</a>)
* Job 15:1-3
* Proverbs 10:16-17
* Jeremiah 02:7-8
* Ezekiel 18:12-13
* John 06:62-63
* Mark 08:35-37
* Matthew 16:24-26
* 2 Peter 02:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bless')">bless</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fruit')">fruit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 1 Chronicles 29:22-23
* Deuteronomy 23:5-6
* Job 36:10-12
* Leviticus 25:26-28
* Psalms 001:3
* This term could be translated by the word or phrase that is used in the project language to refer to a prostitute. Some languages may have a euphemistic term that is used for this. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">euphemism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fornication')">sexual immorality</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>)
* Genesis 34:30-31
* Genesis 38:21-23
* Luke 15:28-30
* Matthew 21:31-32
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/awe')">awe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/bow')">bow</a>)
* 2 Kings 17:36-38
* Genesis 43:28-29
* Revelation 19:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/arrogant')">arrogant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/humble')">humble</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/joy')">joy</a>)
* 1 Timothy 03:6-7
* 2 Corinthians 01:12-14
* Galatians 06:3-5
* Isaiah 13:19-20
* Luke 01:50-51
* __Open Bible Stories - 04:02__ They were very __proud__, and they did not care about what God said.
* __Open Bible Stories - 34:10__ Then Jesus said, "I tell you the truth, God heard the tax collector's prayer and declared him to be righteous. But he did not like the prayer of the religious leader. God will humble everyone who is __proud__, and he will lift up whoever humbles himself."
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/solomon')">Solomon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wise')">wise</a>)
* 1 Kings 04:32-34
* 1 Samuel 24:12-13
* 2 Peter 02:20-22
* Luke 04:23-24
* Proverbs 01:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/asia')">Asia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esther')">Esther</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/galatia')">Galatia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/galilee')">Galilee</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judea')">Judea</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/macedonia')">Macedonia</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mede')">Medes</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/syria')">Syria</a>)
* Acts 19:30-32
* Daniel 03:1-2
* Daniel 06:1-3
* Ecclesiastes 02:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/angry')">angry</a>)
* Ezekiel 20:27-29
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/shrewd')">shrewd</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wise')">wise</a>)
* Proverbs 08:4-5
* Proverbs 12:23-24
* Proverbs 27:11-12
The term "puffed up" is a figurative expression that refers to being proud or arrogant. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-idiom')">Idiom</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/arrogant')">arrogant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/proud')">proud</a>)
* 1 Corinthians 04:6-7
* 1 Corinthians 08:1-3
* 2 Corinthians 12:6-7
* Habakkuk 02:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/justice')">just</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* 1 John 04:17-18
* 2 Thessalonians 01:9-10
* Acts 04:21-22
* Acts 07:59-60
* Genesis 04:13-15
* Luke 23:15-17
* Matthew 25:44-46
* __Open Bible Stories - 13:07__ God also gave many other laws and rules to follow. If the people obeyed these laws, God promised that he would bless and protect them. If they disobeyed them, God would __punish__ them. 
* __Open Bible Stories - 16:02__ Because the Israelites kept disobeying God, he __punished__ them by allowing their enemies to defeat them. 
* __Open Bible Stories - 19:16__ The prophets warned the people that if they did not stop doing evil and start obeying God, then God would judge them as guilty, and he would __punish__ them. 
* __Open Bible Stories - 48:06__ Jesus was the perfect high priest because he took the __punishment__ for every sin that anyone has ever committed.
* __Open Bible Stories - 48:10__ When anyone believes in Jesus, the blood of Jesus takes away that person's sin, and God's __punishment__ passes over him.
* __Open Bible Stories - 49:09__ But God loved everyone in the world so much that he gave his only Son so that whoever believes in Jesus will not be __punished__ for his sins, but will live with God forever.
* __Open Bible Stories - 49:11__ Jesus never sinned, but he chose to be __punished__ and die as the perfect sacrifice to take away your sins and the sins of every person in the world.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/ephod')">ephod</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/philippi')">Philippi</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/royal')">royal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 2 Chronicles 02:13-14
* Daniel 05:7
* Daniel 05:29-31
* Proverbs 31:22-23
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/oppress')">oppress</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/persecute')">persecute</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/reject')">reject</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/colossae')">Colossae</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godly')">godly</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/light')">light</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/redeem')">redeem</a>)
* Daniel 01:3-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/ahasuerus')">Ahasuerus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/athaliah')">Athaliah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/esther')">Esther</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>. <a style="cursor: pointer" onclick="return followLink('en/tw/names/persia')">Persia</a> <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sheba')">Sheba</a>)
* 1 Kings 10:10
* 1 Kings 11:18-19
* 2 Kings 10:12-14
* Acts 08:26-28
* Esther 01:16-18
* Luke 11:31
* Matthew 12:42
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/fruit')">fruit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gift')">gift</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>)
* 1 Thessalonians 05:19-22
* Ezekiel 20:45-47
* Isaiah 01:31
* Jeremiah 21:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/angry')">angry</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/selfcontrol')">self-control</a>) 
* Acts 04:23-25
* Daniel 03:13-14
* Luke 04:28-30
* Numbers 25:10-11
* Proverbs 19:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/resurrection')">resurrection</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/appoint')">appoint</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/exalt')">exalt</a>)
* 2 Chronicles 06:40-42
* 2 Samuel 07:12-14
* Acts 10:39-41
* Colossians 03:1-4
* Deuteronomy 13:1-3
* Jeremiah 06:1-3
* Judges 02:18-19
* Luke 07:21-23
* Matthew 20:17-19
* __Open Bible Stories - 21:14__ The prophets foretold that the Messiah would die and that God would also __raise__  him from the dead.
* __Open Bible Stories - 41:05__ "Jesus is not here. He has __risen__  from the dead, just like he said he would!"
* __Open Bible Stories - 43:07__ "Although Jesus died, God __raised__  him from the dead. This fulfills the prophecy which says, 'You will not let your Holy One rot in the grave.' We are witnesses to the fact that God __raised__  Jesus to life again."
* __Open Bible Stories - 44:05__ " You killed the author of life, but God __raised__  him from the dead. "
* __Open Bible Stories - 44:08__ Peter answered them, "This man stands before you healed by the power of Jesus the Messiah. You crucified Jesus, but God __raised__  him to life again!"
* __Open Bible Stories - 48:04__ This meant that Satan would kill the Messiah, but God would __raise__  him to life again, and then the Messiah will crush the power of Satan forever.
* __Open Bible Stories - 49:02__ He (Jesus) walked on water, calmed storms, healed many sick people, drove out demons, __raised__  the dead to life, and turned five loaves of bread and two small fish into enough food for over 5,000 people.
* __Open Bible Stories - 49:12__ You must believe that Jesus is the Son of God, that he died on the cross instead of you, and that God __raised__  him to life again.
* This term is also used figuratively to refer to the consequences that come from a person's actions, as in the saying "a man reaps what he plants."  (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/goodnews')">good news</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/harvest')">harvest</a>)
* Galatians 06:9-10
* Matthew 06:25-26
* Matthew 13:29-30
* Matthew 13:36-39
* Matthew 25:24-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/governor')">governor</a>)
* 1 Kings 12:18-19
* 1 Samuel 12:14-15
* 1 Timothy 01:9-11
* 2 Chronicles 10:17-19
* Acts 21:37-38
* Luke 23:18-19
* __Open Bible Stories - 14:14__ After the Israelites had wandered in the wilderness for forty years, all of them who had __rebelled__ against God were dead. 
* __Open Bible Stories - 18:07__ Ten of the tribes of the nation of Israel __rebelled__ against Rehoboam. 
* __Open Bible Stories - 18:09__ Jeroboam __rebelled__ against God and caused the people to sin. 
* __Open Bible Stories - 18:13__ Most of the people of Judah also __rebelled__ against God and worshiped other gods. 
* __Open Bible Stories - 20:07__ But after a few years, the king of Judah __rebelled__ against Babylon. 
* __Open Bible Stories - 45:03__ Then he (Stephen) said, "You stubborn and __rebellious__ people always reject the Holy Spirit, just as your ancestors always rejected God and killed his prophets.
(See also <a style="cursor: pointer" onclick="return followLink('en/tw/other/admonish')">admonish</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>)
* Mark 01:23-26
* Mark 16:14-16
* Matthew 08:26-27
* Matthew 17:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>)
* 1 John 05:9-10
* 1 Thessalonians 01:6-7
* 1 Thessalonians 04:1-2
* Acts 08:14-17
* Jeremiah 32:33-35
* Luke 09:5-6
* Malachi 03:10-12
* Psalms 049:14-15
* __Open Bible Stories - 21:13__ The prophets also said that the Messiah would be perfect, having no sin. He would die to __receive__  the punishment for other people's sin. His punishment would bring peace between God and people.
* __Open Bible Stories - 45:05__ As Stephen was dying, he cried out, "Jesus, __receive__  my spirit."
* __Open Bible Stories - 49:06__ He (Jesus) taught that some people will receive him and be saved, but others will not.
* __Open Bible Stories - 49:10__ When Jesus died on the cross, he __received__  your punishment.
* __Open Bible Stories - 49:13__ God will save everyone who believes in Jesus and __receives__  him as their Master.
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nileriver')">Nile River</a>)
* 1 Kings 14:14-16
* Luke 07:24-26
* Matthew 11:7-8
* Matthew 12:19-21
* Psalm 068:30-31
* 2 Samuel 22:3-4
* Deuteronomy 32:37-38
* Isaiah 23:13-14
* Jeremiah 16:19-21
* Numbers 35:24-25
* Psalm 046:1-3
* Psalms 028:6-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/kingdom')">kingdom</a>)
* 2 Timothy 02:11-13
* Genesis 36:34-36
* Luke 01:30-33
* Luke 19:26-27
* Matthew 02:22-23
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/stiffnecked')">stiff-necked</a>)
* Galatians 04:12-14
* Hosea 04:6-7
* Isaiah 41:8-9
* John 12:48-50
* Mark 07:8-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>)
* Genesis 06:4
* Psalms 135:12-14
* Acts 05:22-23
* John 12:37-38
* Luke 05:15-16
* Luke 08:34-35
* Matthew 28:14-15
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/accuse')">accuse</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/rebuke')">rebuke</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shame')">shame</a>)
* 1 Timothy 05:7-8
* 1 Timothy 06:13-14
* Jeremiah 15:15-16
* Job 16:9-10
* Proverbs 18:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/remnant')">remnant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sabbath')">Sabbath</a>)
* 2 Chronicles 06:40-42
* Genesis 02:1-3
* Jeremiah 06:16-19
* Matthew 11:28-30
* Revelation 14:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/turn')">turn</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fear')">fear</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>)
* 1 Peter 01:15-17
* Hebrews 11:7
* Isaiah 44:17
* Psalms 005:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>)
* Deuteronomy 32:5-6
* Isaiah 40:9-10
* Luke 06:35-36
* Mark 09:40-41
* Matthew 05:11-12
* Matthew 06:3-4
* Psalms 127:3-5
* Revelation 11:18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/royal')">royal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tunic')">tunic</a>)
* Exodus 28:4-5
* Genesis 49:11-12
* Luke 15:22-24
* Luke 20:45-47
* Matthew 27:27-29
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/staff')">staff</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>)
* 1 Corinthians 04:19-21
* 1 Samuel 14:43-44
* Acts 16:22-24
* Exodus 27:9-10
* Revelation 11:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>. <a style="cursor: pointer" onclick="return followLink('en/tw/other/palace')">palace</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/purple')">purple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/queen')">queen</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/robe')">robe</a>)
* 1 Kings 10:13
* 2 Chronicles 18:28-30
* Amos 07:12-13
* Genesis 49:19-21
* 2 Chronicles 12:7-8
* 2 Kings 19:25-26
* Acts 15:15-18
* Isaiah 23:13-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/governor')">governor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/synagogue')">synagogue</a>)
* Acts 03:17-18
* Acts 07:35-37
* Luke 12:11-12
* Luke 23:35
* Mark 10:41-42
* Matthew 09:32-34
* Matthew 20:25-28
* Titus 03:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/perseverance')">persevere</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/refuge')">refuge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/turn')">turn</a>)
* 1 Corinthians 06:18
* Galatians 02:1-2
* Galatians 05:5-8
* Philippians 02:14-16
* Proverbs 01:15-17
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/ash')">ash</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/camel')">camel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/goat')">goat</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/humble')">humble</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/mourn')">mourn</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sign')">sign</a>)
* 2 Samuel 03:31-32
* Genesis 37:34-36
* Joel 01:8-10
* Jonah 03:4-5
* Luke 10:13-15
* Matthew 11:20-22
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/burntoffering')">burnt offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/drinkoffering')">drink offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fellowshipoffering')">fellowship offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/freewilloffering')">freewill offering</a> <a style="cursor: pointer" onclick="return followLink('en/tw/other/peaceoffering')">peace offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/priest')">priest</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sinoffering')">sin offering</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* 2 Timothy 04:6-8
* Acts 07:41-42
* Acts 21:25-26
* Genesis 04:3-5
* James 02:21-24
* Mark 01:43-44
* Mark 14:12-14
* Matthew 05:23-24
* __Open Bible Stories - 03:14__ After Noah got off the boat, he built an altar and __sacrificed__  some of each kind of animal which could be used for a __sacrifice__. God was happy with the __sacrifice__  and blessed Noah and his family.
* __Open Bible Stories - 05:06__ "Take Isaac, your only son, and kill him as a __sacrifice__  to me." Again Abraham obeyed God and prepared to __sacrifice__  his son.
* __Open Bible Stories - 05:09__ God had provided the ram to be the __sacrifice__  instead of Isaac.
* __Open Bible Stories - 13:09__ Anyone who disobeyed God's law could bring an animal to the Tent of Meeting as a __sacrifice__  to God. A priest would kill the animal and burn it on the altar. The blood of the animal that was __sacrificed__  covered the person's sin and made that person clean in God's sight.
* __Open Bible Stories - 17:06__ David wanted to build a temple where all the Israelites could worship God and offer him __sacrifices__.
* __Open Bible Stories - 48:06__ Jesus is the Great High Priest. Unlike other priests, he offered himself as the only __sacrifice__  that could to take away the sin of all the people in the world.
* __Open Bible Stories - 48:08__ But God provided Jesus, the Lamb of God, as a __sacrifice__  to die in our place.
* __Open Bible Stories - 49:11__ Because Jesus __sacrificed__  himself, God can forgive any sin, even terrible sins.
* Acts 07:33-34
* Deuteronomy 25:9-10
* John 01:26-28
* Joshua 05:14-15
* Mark 06:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>)
* Amos 01:5
* Esther 04:9-12
* Genesis 49:10
* Hebrews 01:8-9
* Numbers 21:17-18
* Psalms 045:5-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/seal')">seal</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/synagogue')">synagogue</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>)
* Jeremiah 29:1-3
* Luke 04:16-17
* Numbers 21:14-15
* Revelation 05:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>)
* Numbers 04:5-6
* Numbers 04:12-14
* Numbers 04:24-26
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tomb')">tomb</a>)
* Exodus 02:3-4
* Isaiah 29:11-12
* John 06:26-27
* Matthew 27:65-66
* Revelation 05:1-2
* For a man or woman's "seed," consider how the target expresses this in a way that will not offend or embarrass people.  (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">euphemism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/descendant')">descendant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/offspring')">offspring</a>)
* 1 Kings 18:30-32
* Genesis 01:11-13
* Jeremiah 02:20-22
* Matthew 13:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/justice')">just</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/true')">true</a>)
* 1 Chronicles 10:13-14
* Acts 17:26-27
* Hebrews 11:5-6
* Luke 11:9-10
* Psalms 027:7-8
(See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">euphemism</a>)
* Acts 16:19-21
* Exodus 15:14-15
* John 10:37-39
* Luke 08:28-29
* Matthew 26:47-48
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/psalm')">psalm</a>)
* Psalm 003:3-4
* Psalm 024:5-6
* Psalms 046:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/fruit')">fruit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>)
* 1 Corinthians 07:8-9
* 2 Peter 01:5-7
* 2 Timothy 03:1-4
* Galatians 05:22-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/appoint')">appoint</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/redeem')">redeem</a>)
* Acts 07:33-34
* Acts 08:14-17
* John 20:21-23
* Matthew 09:37-38
* Matthew 10:5-7
* Matthew 10:40-41
* Matthew 21:1-3
(Translation suggestions:  <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">How to Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/curse')">curse</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/deceive')">deceive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/eden')">Eden</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/offspring')">offspring</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prey')">prey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tempt')">tempt</a>)
* Genesis 03:1-3
* Genesis 03:4-6
* Genesis 03:12-13
* Mark 16:17-18
* Matthew 03:7-9
* Matthew 23:32-33
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/commit')">commit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/enslave')">enslave</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/household')">household</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">lord</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righteous')">righteous</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>,  <a style="cursor: pointer" onclick="return followLink('en/tw/other/law')">law</a>,)
* Acts 04:29-31
* Acts 10:7-8
* Colossians 01:7-8
* Colossians 03:22-25
* Genesis 21:10-11
* Luke 12:47-48
* Mark 09:33-35
* Matthew 10:24-25
* Matthew 13:27-28
* 2 Timothy 02:3-5
* Acts 06:2-4
* Genesis 25:23
* Luke 04:8
* Luke 12:37-38
* Luke 22:26-27
* Mark 08:7-10
* Matthew 04:10-11
* Matthew 06:24
* __Open Bible Stories - 06:01__ When Abraham was very old and his son, Isaac, had grown to be a man, Abraham sent one of his __servants__ back to the land where his relatives lived to find a wife for his son, Isaac.
* __Open Bible Stories - 08:04__ The __slave__ traders sold Joseph as a __slave__ to a wealthy government official.
* __Open Bible Stories - 09:13__ "I (God) will send you (Moses) to Pharaoh so that you can bring the Israelites out of their __slavery__ in Egypt."
* __Open Bible Stories - 19:10__ Then Elijah prayed, "O Yahweh, God of Abraham, Isaac, and Jacob, show us today that you are the God of Israel and that I am your __servant__."
* __Open Bible Stories - 29:03__ "Since the __servant__ could not pay the debt, the king said, 'Sell this man and his family as __slaves__ to make payment on his debt.'"
* __Open Bible Stories - 35:06__ "All my father's __servants__ have plenty to eat, and yet here I am starving."
* __Open Bible Stories - 47:04__ The __slave__ girl kept yelling as they walked, "These men are servants of the Most High God. 
* __Open Bible Stories - 50:04__ Jesus also said, "A __servant__ is not greater than his master."
In the Bible, these terms are euphemisms that refer to having sexual intercourse. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">Euphemism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/fornication')">sexual immorality</a>)
* 1 Corinthians 05:1-2
* 1 Samuel 01:19-20
* Deuteronomy 21:13-14
* Genesis 19:4-5
* Matthew 01:24-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/darkness')">darkness</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/light')">light</a>)
* 2 Kings 20:8-9
* Genesis 19:6-8
* Isaiah 30:1-2
* Jeremiah 06:4-5
* Psalms 017:8-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/humble')">humble</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/humiliate')">humiliate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaiah')">Isaiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>) 
* 1 Peter 03:15-17
* 2 Kings 02:17-18
* 2 Samuel 13:13-14
* Luke 20:11-12
* Mark 08:38
* Mark 12:4-5
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lamb')">lamb</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>)
* Acts 08:32-33
* Genesis 30:31-32
* John 02:13-14
* Luke 15:3-5
* Mark 06:33-34
* Matthew 09:35-36
* Matthew 10:5-7
* Matthew 12:11-12
* Matthew 25:31-33
* __Open Bible Stories - 09:12__ One day while Moses was taking care of his __sheep__, he saw a bush that was on fire.
* __Open Bible Stories - 17:02__ David was a shepherd from the town of Bethlehem. At different times while he was watching his father's __sheep__, David had killed both a lion and a bear that had attacked the __sheep__.
* __Open Bible Stories - 30:03__ To Jesus, these people were like __sheep__  without a shepherd.
* __Open Bible Stories - 38:08__ Jesus said, "All of you will all abandon me tonight. It is written, 'I will strike the shepherd and all the __sheep__  will be scattered.'"
* In the Old Testament, God was called the "shepherd" of his people because he took care of all their needs and protected them. He also led and guided them. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/church')">church</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/pastor')">pastor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* Genesis 49:24
* Luke 02:8-9
* Mark 06:33-34
* Mark 14:26-27
* Matthew 02:4-6
* Matthew 09:35-36
* Matthew 25:31-33
* Matthew 26:30-32
* __Open Bible Stories - 09:11__ Moses became a __shepherd__  in the wilderness far away from Egypt.to
* __Open Bible Stories - 17:02__ David was a __shepherd__  from the town of Bethlehem. At different times while he was watching his father's sheep, David had killed both a lion and a bear that had attacked the sheep.
* __Open Bible Stories - 23:06__ That night, there were some __shepherds__  in a nearby field guarding their flocks.
* __Open Bible Stories - 23:08__ The __shepherds__  soon arrived at the place where Jesus was and they found him lying in a feeding trough, just as the angel had told them.
* __Open Bible Stories - 30:03__ To Jesus, these people were like sheep without a __shepherd__.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faith')">faith</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 1 Kings 14:25-26
* 2 Chronicles 23:8-9
* 2 Samuel 22:36-37
* Deuteronomy 33:29
* Psalms 018:35-36
* 1 Chronicles 20:1
* 1 Kings 20:1-3
* 1 Samuel 11:1-2
* Jeremiah 33:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 1 Chronicles 18:9-11
* 1 Samuel 02:36
* 2 Kings 25:13-15
* Acts 03:4-6
* Matthew 26:14-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/altar')">altar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cow')">cow</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/forgive')">forgive</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* 2 Chronicles 29:20-21
* Exodus 29:35-37
* Ezekiel 44:25-27
* Leviticus 05:11
* Numbers 07:15-17
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/brother')">brother</a> <a style="cursor: pointer" onclick="return followLink('en/tw/kt/inchrist')">in Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 1 Chronicles 02:16-17
* Deuteronomy 27:22-23
* Philemon 01:1-3
* Romans 16:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/crucify')">crucify</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/golgotha')">Golgotha</a>)
* 2 Kings 09:35-37
* Jeremiah 02:14-17
* John 19:17-18
* Matthew 27:32-34
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/slaughter')">slaughter</a>)
* Ezekiel 28:23-24
* Isaiah 26:20-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/blasphemy')">blasphemy</a>)
* 1 Corinthians 04:12-13
* 1 Timothy 03:11-13
* 2 Corinthians 06:8-10
* Mark 07:20-23
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/cow')">cow</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/disobey')">disobey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/ezekiel')">Ezekiel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/slain')">slay</a>)
* Ezekiel 21:10-11
* Hebrews 07:1-3
* Isaiah 34:1-2
* Jeremiah 25:34-36
* 1 Kings 18:27-29
* 1 Thessalonians 04:13-15
* Acts 07:59-60
* Daniel 12:1-2
* Psalms 044:23-24
* Romans 13:11-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/free')">free</a>, , <a style="cursor: pointer" onclick="return followLink('en/tw/other/prey')">prey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tempt')">tempt</a>)
* Ecclesiastes 07:26
* Luke 21:34-35
* Mark 12:13-15
* Psalms 018:4-5
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(Translation suggestions: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-names')">Translate Names</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/lebanon')">Lebanon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/purify')">pure</a>)
* Exodus 04:6-7
* Job 37:4-6
* Matthew 28:3-4
* Psalms 147:15-16
* Revelation 01:14-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/adultery')">adultery</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/demon')">demon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/divination')">divination</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/magic')">magic</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* Acts 08:9-11
* Exodus 07:11-13
* Galatians 05:19-21
* Revelation 09:20-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/good')">good</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/reap')">reap</a>)
* Galatians 06:6-8
* Luke 08:4-6
* Matthew 06:25-26
* Matthew 13:3-6
* Matthew 13:18-19
* Matthew 25:24-25
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/prey')">prey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sword')">sword</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/warrior')">warrior</a>)
* 1 Samuel 13:19-21
* 2 Samuel 21:18-19
* Nehemiah 04:12-14
* Psalm 035:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/glory')">glory</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/majesty')">majesty</a>)
* 1 Chronicles 16:25-27
* Exodus 28:1-3
* Ezekiel 28:6-7
* Luke 04:5-7
* Psalms 089:44-45
* Revelation 21:26-27
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/pharaoh')">Pharaoh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/shepherd')">shepherd</a>)
* Exodus 04:1-3
* Exodus 07:8-10
* Luke 09:3-4
* Mark 06:7-9
* Matthew 10:8-10
* Matthew 27:27-29
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/decree')">decree</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ordinance')">ordinance</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 1 Kings 11:11-13
* Deuteronomy 06:20-23
* Ezekiel 33:14-16
* Numbers 19:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/arrogant')">arrogant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/proud')">proud</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/repent')">repent</a>)
* Acts 07:51-53
* Deuteronomy 09:13-14
* Exodus 13:14-16
* Jeremiah 03:17-18
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/consecrate')">consecrate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/dedicate')">dedicate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/famine')">famine</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/gold')">gold</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/silver')">silver</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* 2 Chronicles 16:2-3
* Luke 03:17
* Matthew 03:10-12
* Psalms 033:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/faithful')">faithful</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/perseverance')">persevere</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/righthand')">right hand</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/save')">save</a>)
* 2 Kings 18:19-21
* 2 Peter 02:10-11
* Luke 10:25-28
* Psalm 021:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/angry')">angry</a>)
* 1 Corinthians 03:3-5
* Habakkuk 01:3-4
* Philippians 01:15-17
* Proverbs 17:1-2
* Psalms 055:8-9
* Romans 13:13-14
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grape')">grape</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/nazirite')">Nazirite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/vow')">vow</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wine')">wine</a>)
* Isaiah 05:11-12
* Leviticus 10:8-11
* Luke 01:14-15
* Numbers 06:1-4
* This term was also used figuratively to refer to God as a stronghold or fortress for those who trust in him. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/refuge')">refuge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* 2 Corinthians 10:3-4
* 2 Kings 08:10-12
* 2 Samuel 05:8-10
* Acts 21:34-36
* Habakkuk 01:10-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/persecute')">persecute</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/stumblingblock')">stumbling block</a>)
* 1 Peter 02:7-8
* Hosea 04:4-5
* Isaiah 31:3
* Matthew 11:4-6
* Matthew 18:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/stumble')">stumble</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/sin')">sin</a>)
* 1 Corinthians 01:22-23
* Galatians 05:11-12
* Matthew 05:29-30
* Matthew 16:21-23
* Romans 09:32-33
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/submit')">submit</a>)
* 1 Corinthians 02:14-16
* 1 Kings 04:5-6
* 1 Peter 02:18-20
* Hebrews 02:5-6
* Proverbs 12:23-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/subject')">subject</a>)
* 1 Corinthians 14:34-36
* 1 Peter 03:1-2
* Hebrews 13:15-17
* Luke 10:17-20
* 1 Thessalonians 02:14-16
* 2 Thessalonians 01:3-5
* 2 Timothy 01:8-11
* Acts 07:11-13
* Isaiah 53:10-11
* Jeremiah 06:6-8
* Matthew 16:21-23
* Psalms 022:24-25
* Revelation 01:9-11
* Romans 05:3-5
* __Open Bible Stories - 09:13__ God said, "I have seen the __suffering__  of my people."
* __Open Bible Stories - 38:12__ Jesus prayed three times, "My Father, if it is possible, please let me not have to drink this cup of __suffering__."
* __Open Bible Stories - 42:03__ He (Jesus) reminded them that the prophets said the Messiah would __suffer__  and be killed, but would rise again on the third day.
* __Open Bible Stories - 42:07__ He (Jesus) said, "It was written long ago that the Messiah would __suffer__, die, and rise from the dead on the third day."
* __Open Bible Stories - 44:05__ "Although you did not understand what you were doing, God used your actions to fulfill the prophecies that the Messiah would __suffer__  and die."
* __Open Bible Stories - 46:04__ God said, "I have chosen him (Saul) to declare my name to the unsaved. I will show him how much he must __suffer__  for my sake."
* __Open Bible Stories - 50:17__ He (Jesus) will wipe away every tear and there will be no more __suffering__, sadness, crying, evil, pain, or death.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/gomorrah')">Gomorrah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/lot')">Lot</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/rebel')">rebel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sodom')">Sodom</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/godly')">godly</a>)
* Genesis 19:23-25
* Isaiah 34:8-10
* Luke 17:28-29
* Revelation 20:9-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/assyria')">Assyria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaiah')">Isaiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/judah')">Judah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>)
* 1 Kings 16:3-4
* Daniel 11:40-41
* Genesis 18:24-26
* Proverbs 21:7-8
* Psalms 090:5-6
* A sword is used as a metaphor for God's word. God's teachings in the Bible exposed people's innermost thoughts and convicted them of their sin. In a similar way, a sword cuts deeply, causing pain. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jamesbrotherofjesus')">James (brother of Jesus)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/johnthebaptist')">John (the Baptist)</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tongue')">tongue</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>)
* Acts 12:1-2
* Genesis 27:39-40
* Genesis 34:24-26
* Luke 02:33-35
* Luke 21:23-24
* Matthew 10:34-36
* Matthew 26:55-56
* Revelation 01:14-16
* Luke 20:21-22
* Mark 02:13-14
* Matthew 09:7-9
* Numbers 31:28-29
* Romans 13:6-7
* Luke 03:12-13
* Luke 05:27-28
* Matthew 05:46-48
* Matthew 09:10-11
* Matthew 11:18-19
* Matthew 17:26-27
* Matthew 18:17
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/instruct')">instruct</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/teacher')">teacher</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>)
* 1 Timothy 01:3-4
* Acts 02:40-42
* John 07:14-16
* Luke 04:31-32
* Matthew 04:23-25
* Psalms 032:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/disciple')">disciple</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/preach')">preach</a>)
* Ecclesiastes 01:12-15
* Ephesians 04:11-13
* Galatians 06:6-8
* Habakkuk 02:18-20
* James 03:1-2
* John 01:37-39
* Luke 06:39-40
* Matthew 12:38-40
* __Open Bible Stories - 27:01__ One day, an expert in the Jewish law came to Jesus to test him, saying, "__Teacher__, what must I do to inherit eternal life?"
* __Open Bible Stories - 28:01__ One day a rich young ruler came up to Jesus and asked him, "Good __Teacher__, what must I do to have eternal life?"
* __Open Bible Stories - 37:02__ After the two days had passed, Jesus said to his disciples, "Let's go back to Judea." "But __Teacher__," the disciples answered, "Just a short time ago the people there wanted to kill you!"
* __Open Bible Stories - 38:14__ Judas came to Jesus and said, "Greetings, __Teacher__," and kissed him.
* __Open Bible Stories - 49:03__ Jesus was also a great __teacher__, and he spoke with authority because he is the Son of God.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/arkofthecovenant')">ark of the covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/covenant')">covenant</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/desert')">desert</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/obey')">obey</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sinai')">Sinai</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* Deuteronomy 04:13-14
* Deuteronomy 10:3-4
* Exodus 34:27-28
* Luke 18:18-21
* __Open Bible Stories - 13:07__  Then God wrote these __Ten Commandments__ on two stone tablets and gave them to Moses.
* __Open Bible Stories - 13:13__  When Moses came down the mountain and saw the idol, he was so angry that he smashed the stones on which God had written the __Ten Commandments__. 
* __Open Bible Stories - 13:15__  Moses wrote the __Ten Commandments__ on new stone tablets to replace the ones he had broken.
* The term "tents" is sometimes used figuratively to refer generally to where people live. This could also be translated as "homes" or "dwellings" or "houses" or even "bodies." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/abraham')">Abraham</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/canaan')">Canaan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/curtain')">curtain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/paul')">Paul</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/sinai')">Sinai</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tentofmeeting')">tent of meeting</a>)
* 1 Chronicles 05:10
* Daniel 11:44-45
* Exodus 16:16-18
* Genesis 12:8-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/levite')">Levite</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/livestock')">livestock</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/melchizedek')">Melchizedek</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/minister')">minister</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sacrifice')">sacrifice</a>  <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/temple')">temple</a>)
* Genesis 14:19-20
* Genesis 28:20-22
* Hebrews 07:4-6
* Isaiah 06:13
* Luke 11:42
* Luke 18:11-12
* Matthew 23:23-24
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/pillar')">pillar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tabernacle')">tabernacle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tent')">tent</a>)
* 1 Kings 02:28-29
* Joshua 19:51
* Leviticus 01:1-2
* Numbers 04:31-32
* __Open Bible Stories - 13:08__ God gave the Israelites a detailed description of a tent he wanted them to make. It was called the __Tent of Meeting__, and it had two rooms, separated by a large curtain. 
* __Open Bible Stories - 13:09__ Anyone who disobeyed God's law could bring an animal to the altar in front of the __Tent of Meeting__ as a sacrifice to God. 
* __Open Bible Stories - 14:08__ God was very angry and came to the __Tent of Meeting__. 
* __Open Bible Stories - 18:02__ Instead of at the __Tent of Meeting__, people now worshiped God and offered sacrifices to him at the Temple.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/adversary')">adversary</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fear')">fear</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/judge')">judge</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/plague')">plague</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/yahweh')">Yahweh</a>)
* Deuteronomy 02:24-25
* Exodus 14:10-12
* Luke 21:7-9
* Mark 06:48-50
* Matthew 28:5-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bless')">bless</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/criminal')">crime</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/crucify')">crucify</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/darkness')">darkness</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/destroyer')">destroyer</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/samaria')">Samaria</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/satan')">Satan</a>)
* 2 Peter 03:10
* Luke 12:33-34
* Mark 14:47-50
* Proverbs 06:30-31
* Revelation 03:3-4
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/crown')">crown</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/fruit')">fruit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* Hebrews 06:7-8
* Matthew 13:7-9
* Matthew 13:22-23
* Numbers 33:55-56
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/chaff')">chaff</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/winnow')">winnow</a>)
* 2 Chronicles 03:1-3
* 2 Kings 13:6-7
* 2 Samuel 24:15-16
* Daniel 02:34-35
* Luke 03:17
* Matthew 03:10-12
* Ruth 03:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/gate')">gate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tent')">tent</a>)
* 1 Chronicles 09:17-19
* Ezekiel 09:3-4
* Isaiah 06:4-5
* Proverbs 17:19-20
* The word "throne" is often used figuratively to refer to the ruler, his reign, or his power. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metonymy')">metonymy</a>) 
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/authority')">authority</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/reign')">reign</a>)
* Colossians 01:15-17
* Genesis 41:39-41
* Luke 01:30-33
* Luke 22:28-30
* Matthew 05:33-35
* Matthew 19:28
* Revelation 01:4-6
* The phrase "times and seasons" is a figurative expression which states the same idea twice. This could also be translated as "certain events happening in certain time periods." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-doublet')">doublet</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/age')">age</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tribulation')">tribulation</a>)
* Acts 01:6-8
* Daniel 12:1-2
* Mark 11:11-12
* Matthew 08:28-29
* Psalms 068:28-29
* Revelation 14:14-16
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/bury')">bury</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/death')">death</a>)
* Acts 02:29-31
* Genesis 23:5-6
* Genesis 50:4-6
* John 19:40-42
* Luke 23:52-53
* Mark 05:1-2
* Matthew 27:51-53
* Romans 03:13-14
* __Open Bible Stories - 32:04__ The man lived among the __tombs__  in the area.
* __Open Bible Stories - 37:06__ Jesus asked them, "Where have you put Lazarus?" They told him, "In the __tomb__. Come and see."
* __Open Bible Stories - 37:07__ The __tomb__  was a cave with a stone rolled in front of its opening.
* __Open Bible Stories - 40:09__ Then Joseph and Nicodemus, two Jewish leaders who believed Jesus was the Messiah, asked Pilate for Jesus' body. They wrapped his body in cloth and placed it in a __tomb__  cut out of rock. Then they rolled a large stone in front the __tomb__  to block the opening.
* __Open Bible Stories - 41:04__ He (the angel) rolled away the stone that was covering the entrance to the __tomb__  and sat on it. The soldiers guarding the __tomb__  were terrified and fell to the ground like dead men.
* __Open Bible Stories - 41:05__ When the women arrived at the __tomb__, the angel told them, "Do not be afraid. Jesus is not here. He has risen from the dead, just like he said he would! Look in the __tomb__  and see." The women looked into the __tomb__  and saw where Jesus' body had been laid. His body was not there!
* In the expression "my tongue rejoices," the term "tongue" refers to the whole person. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
* The phrase "lying tongue" refers to a person's voice or speech. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metonymy')">metonymy</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/gift')">gift</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/joy')">joy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/praise')">praise</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/joy')">rejoice</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>)
* 1 Corinthians 12:9-11
* 1 John 03:16-18
* 2 Samuel 23:1-2
* Acts 02:25-26
* Ezekiel 36:1-3
* Philippians 02:9-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/beast')">beast</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/eternity')">everlasting</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/job')">Job</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/savior')">Savior</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/suffer')">suffer</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* 2 Peter 02:7-9
* Jeremiah 30:20-22
* Lamentations 01:11-12
* Luke 08:28-29
* Revelation 11:10-12
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/apostle')">apostle</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christian')">Christian</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/father')">ancestor</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/generation')">generation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jew')">Jew</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>)
* 2 Thessalonians 03:6-9
* Colossians 02:8-9
* Galatians 01:13-14
* Mark 07:2-4
* Matthew 15:1-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grape')">grape</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/humiliate')">humiliate</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/punish')">punish</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/rebel')">rebel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/thresh')">thresh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/wine')">wine</a>)
* Hebrews 10:28-29
* Psalms 007:5
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/earth')">earth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/fear')">fear</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lord')">Lord</a>)
* 2 Corinthians 07:15-16
* 2 Samuel 22:44-46
* Acts 16:29-31
* Jeremiah 05:20-22
* Luke 08:47-48
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/tempt')">tempt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/test')">test</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/innocent')">innocent</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/guilt')">guilt</a>)
* Deuteronomy 04:34
* Ezekiel 21:12-13
* Lamentations 03:58-61
* Proverbs 25:7-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/clan')">clan</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/nation')">nation</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/peoplegroup')">people group</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/12tribesofisrael')">twelve tribes of Israel</a>)
* 1 Samuel 10:17-19
* 2 Kings 17:16-18
* Genesis 25:13-16
* Genesis 49:16-18
* Luke 02:36-38
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/earth')">earth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/teach')">teach</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wrath')">wrath</a>)
* Mark 04:16-17
* Mark 13:17-20
* Matthew 13:20-21
* Matthew 24:9-11
* Matthew 24:29
* Romans 02:8-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/gold')">gold</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/king')">king</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tax')">tax</a>)
* 1 Chronicles 18:1-2
* 2 Chronicles 09:22-24
* 2 Kings 17:1-3
* Luke 23:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/afflict')">afflict</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/persecute')">persecute</a>)
* 1 Kings 18:18-19
* 2 Chronicles 25:18-19
* Luke 24:38-40
* Matthew 24:6-8
* Matthew 26:36-38
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/angel')">angel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/assembly')">assembly</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/earth')">earth</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/horn')">horn</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wrath')">wrath</a>)
* 1 Chronicles 13:7-8
* 2 Kings 09:11-13
* Exodus 19:12-13
* Hebrews 12:18-21
* Matthew 06:1-2
* Matthew 24:30-31
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See Also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/robe')">robe</a>)
* Daniel 03:21-23
* Isaiah 22:20-22
* Leviticus 08:12-13
* Luke 03:10-11
* Mark 06:7-9
* Matthew 10:8-10
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/leprosy')">leprosy</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worship')">worship</a>)
* 1 Kings 11:1-2
* Acts 07:41-42
* Acts 11:19-21
* Jeremiah 36:1-3
* Luke 01:16-17
* Malachi 04:4-6
* Revelation 11:6-7
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/believe')">believe</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/know')">know</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wise')">wise</a>)
* Job 34:16-17
* Luke 02:45-47
* Luke 08:9-10
* Matthew 13:10-12
* Matthew 13:13-14
* Proverbs 03:5-6
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/falsegod')">false god</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/worthy')">worthy</a>)
* 1 Corinthians 15:1-2
* 1 Samuel 25:21-22
* 2 Peter 02:17-19
* Isaiah 45:19
* Jeremiah 02:29-31
* Matthew 15:7-9
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/moses')">Moses</a>)
* 2 Corinthians 03:12-13
* 2 Corinthians 03:14-16
* Ezekiel 13:17-18
* Isaiah 47:1-2
* Song of Solomon 04:3
* Jesus called himself the "vine" and called his people the "branches." In this context, the word "vine" could also be translated as "grapevine stem" or "grape plant stem." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grape')">grape</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vineyard')">vineyard</a>)
* Genesis 40:9-11
* Genesis 49:11-12
* John 15:1-2
* Luke 22:17-18
* Mark 12:1-3
* Matthew 21:35-37
* God compared the people of Israel to a vineyard that did not bear good fruit. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grape')">grape</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/israel')">Israel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vine')">vine</a>)
* Genesis 09:20-21
* Luke 13:6-7
* Luke 20:15-16
* Matthew 20:1-2
* Matthew 21:40-41
* Some languages may have a term that is a polite way of referring to a virgin. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">Euphemism</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/christ')">Christ</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/isaiah')">Isaiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/jesus')">Jesus</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/mary')">Mary</a>)
* Genesis 24:15-16
* Luke 01:26-29
* Luke 01:34-35
* Matthew 01:22-23
* Matthew 25:1-4
* __Open Bible Stories - 21:09__ The prophet Isaiah prophesied that the Messiah would be born from a __virgin__.
* __Open Bible Stories - 22:04__ She (Mary) was a __virgin__ and was engaged to be married to a man named Joseph.
* __Open Bible Stories - 22:05__ Mary replied, "How can this be, since I am a __virgin__?"
* __Open Bible Stories - 49:01__ An angel told a __virgin__ named Mary that she would give birth to God's Son. So while she was still a __virgin__, she gave birth to a son and named him Jesus.
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/dream')">dream</a>)
* Acts 09:10-12
* Acts 10:3-6
* Acts 10:9-12
* Acts 12:9-10
* Luke 01:21-23
* Luke 24:22-24
* Matthew 17:9-10
* This term can be used to refer to the whole person, as in the statement "A voice is heard in the desert saying, 'Prepare the way of the Lord.'" This could be translated as "A person is heard calling out in the desert…." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-synecdoche')">synecdoche</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/call')">call</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/preach')">proclaim</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/splendor')">splendor</a>)
* John 05:36-38
* Luke 01:42-45
* Luke 09:34-36
* Matthew 03:16-17
* Matthew 12:19-21
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/honor')">honor</a>)
* 1 John 01:5-7
* 1 Kings 02:1-4
* Colossians 02:6-7
* Galatians 05:25-26
* Genesis 17:1-2
* Isaiah 02:5-6
* Jeremiah 13:8-11
* Micah 04:2-3
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/courage')">courage</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/crucify')">crucify</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/rome')">Rome</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/tomb')">tomb</a>)
* 1 Chronicles 21:4-5
* Acts 21:32-33
* Luke 03:14
* Luke 23:11-12
* Matthew 08:8-10
* Ezekiel 06:6-7
* Leviticus 26:37-39
* Matthew 26:6-9
* Revelation 18:15-17
* Zechariah 07:13-14
* 1 Thessalonians 05:4-7
* Hebrews 13:15-17
* Jeremiah 31:4-6
* Mark 08:14-15
* Mark 13:33-34
* Matthew 25:10-13
* The term "watchtower" is also used as a symbol of protection from enemies. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/adversary')">adversary</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/watch')">watch</a>)
* 1 Chronicles 27:25-27
* Ezekiel 26:3-4
* Mark 12:1-3
* Matthew 21:33-34
* Psalm 062:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/life')">life</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/spirit')">spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/holyspirit')">Holy Spirit</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/power')">power</a>)
* Acts 08:36-38
* Exodus 14:21-22
* John 04:9-10
* John 04:13-14
* John 04:15-16
* Matthew 14:28-30
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/jeremiah')">Jeremiah</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/prison')">prison</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/strife')">strife</a>)
* 1 Chronicles 11:15-17
* 2 Samuel 17:17-18
* Genesis 16:13-14
* Luke 14:4-6
* Numbers 20:17
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/barley')">barley</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/chaff')">chaff</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/seed')">seed</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/thresh')">thresh</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/winnow')">winnow</a>)
* Acts 27:36-38
* Exodus 34:21-22
* John 12:23-24
* Luke 03:17
* Matthew 03:10-12
* Matthew 13:24-26
* If wine is unknown in your culture, it could be translated as "fermented grape juice" or "fermented drink made from a fruit called grapes" or "fermented fruit juice." (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grape')">grape</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vine')">vine</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/vineyard')">vineyard</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/winepress')">winepress</a>)
* 1 Timothy 05:23-25
* Genesis 09:20-21
* Genesis 49:11-12
* John 02:3-5
* John 02:9-10
* Matthew 09:17
* Matthew 11:18-19
* The term "winepress" is also used figuratively in the Bible as a picture of God's wrath being poured out on wicked people. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-metaphor')">Metaphor</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/grape')">grape</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wrath')">wrath</a>)
* Isaiah 63:1-2
* Mark 12:1-3
* Matthew 21:33-34
* Revelation 14:19-20
(See also: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/translate-unknown')">How to Translate Unknowns</a>)
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/other/chaff')">chaff</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/grain')">grain</a>)
* Isaiah 21:10
* Luke 22:31-32
* Matthew 03:10-12
* Proverbs 20:7-8
* Ruth 03:1-2
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/babylon')">Babylon</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/daniel')">Daniel</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/divination')">divination</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/magic')">magic</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/names/nebuchadnezzar')">Nebuchadnezzar</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/ruler')">ruler</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wise')">wise</a>)
* 1 Chronicles 27:32-34
* Daniel 02:1-2
* Daniel 02:10-11
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/evil')">evil</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/falseprophet')">false prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/sheep')">sheep</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/teach')">teach</a>)
* Acts 20:28-30
* Isaiah 11:6-7
* John 10:11-13
* Luke 10:3-4
* Matthew 07:15-17
* Zephaniah 03:3-4
* This is an older term that is sometimes used in order to be polite and less direct. (See: <a style="cursor: pointer" onclick="return followLink('en/ta/translate/figs-euphemism')">euphemism</a>)
* Genesis 25:23
* Genesis 25:24-26
* Genesis 38:27-28
* Genesis 49:25
* Luke 02:21
* Luke 11:27-28
* Luke 23:29-31
* Matthew 19:10-12
* A very special use of this term is when Jesus is called "the Word." For these last two meanings, see <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>)
* 2 Timothy 04:1-2
* Acts 08:4-5
* Colossians 04:2-4
* James 01:17-18
* Jeremiah 27:1-4
* John 01:1-3
* John 01:14-15
* Luke 08:14-15
* Matthew 02:7-8
* Matthew 07:26-27
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/command')">command</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/lawofmoses')">law</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/prophet')">prophet</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/wordofgod')">word of God</a>)
* 1 John 05:13-15
* Acts 13:28-29
* Exodus 32:15-16
* John 21:24-25
* Luke 03:4
* Mark 09:11-13
* Matthew 04:5-6
* Revelation 01:1-3
* Acts 07:26-28
* Exodus 22:20-21
* Genesis 16:5-6
* Luke 06:27-28
* Matthew 20:13-14
* Psalms 071:12-13
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/names/egypt')">Egypt</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/passover')">Passover</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/kt/unleavenedbread')">unleavened bread</a>)
* Exodus 12:5-8
* Galatians 05:9-10
* Luke 12:1
* Luke 13:20-21
* Matthew 13:33
* Matthew 16:5-8
(See also: <a style="cursor: pointer" onclick="return followLink('en/tw/kt/bond')">bind</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/burden')">burden</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/oppress')">oppress</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/persecute')">persecute</a>, <a style="cursor: pointer" onclick="return followLink('en/tw/other/servant')">servant</a>)
* Acts 15:10-11
* Galatians 05:1-2
* Genesis 27:39-40
* Isaiah 09:4-5
* Jeremiah 27:1-4
* Matthew 11:28-30
* Philippians 04:1-3
